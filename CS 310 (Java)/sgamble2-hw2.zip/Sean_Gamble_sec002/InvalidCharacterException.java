public class InvalidCharacterException extends RuntimeException {
  public InvalidCharacterException() {
      super();
    }
    public InvalidCharacterException(String s) {
      super(s);
    }
}