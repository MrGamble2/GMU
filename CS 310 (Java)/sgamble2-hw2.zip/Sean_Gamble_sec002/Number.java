public class Number{
  private Node low, high;
  private int digitCount = 0;
  private int decimalPlaces = 0;
  private boolean negative = false;
  
  public Number(){ // A constructor.  
  }
  public Number(String str){ // A constructor which takes a String representation of a number (e.g. "-21.507"). Calls accept.
    this.accept(str);
  }
  public void accept(String str){ //Builds a list representation of the number represented by the string.
    validate(str);
    for(int i=0; i<str.length(); i++){
      char nextChar= str.charAt(i);
      //catch negative
      if(nextChar=='-'){
        negative=true;
      }
      ///catch decimal location
      else if(nextChar=='.'){
        if(negative==true){
          decimalPlaces=((str.length()-1)-(i));
     
        }
        else{
          decimalPlaces=(str.length()-(i+1));
        }
      }
      //catch int values
      if(Character.isDigit(nextChar)){
        int nextInt=Character.getNumericValue(nextChar);
        Node newNode=new Node(nextInt);
        if(high==null){
          high=newNode;
          low=newNode;
          digitCount++;
        }
        else{
          digitCount++;
          low.setNext(newNode);
          newNode.setPrev(low);
          low=newNode;
        }
      }
    }
    return;
  }
  public Number add(Number n){ // Returns a Number which represents "this + n".
    Number added= new Number();
    int x= this.compareToAbsolute(n);
    //-this-n
    if(n.negative && this.negative){ 
      added= this.addAbsolute(n);
      added.negative=true;
    }
    //-this+n
    if(!n.negative && this.negative){
      added=n.subtractAbsolute(this);
      if(x==1){
        added.reverseSign();
      }
    }
    //this-n
    if(n.negative && !this.negative){
      //x=this.compareToAbsolute(n);
      added=this.subtractAbsolute(n);
      if(x==-1){
        added.reverseSign();
      }
    }
    //this+n
    if(!n.negative && !this.negative){
      added= this.addAbsolute(n);
    }
    return added;
  }
  public Number multiply(Number n){
    //create a new (empty) Number product;
    Number product= new Number();
    Node nPtr = n.high;
    int loop=0;
    while (nPtr != null){
      //create a new (empty) Number partialProduct
      Number partialProduct=new Number();
      int carry = 0;
      Node thisPtr = this.low;
      
      while (thisPtr != null){
        //multiply the digits pointed to and add carry to get newDigit

        int newDigit=carry+(thisPtr.getValue()*nPtr.getValue());
        carry = newDigit / 10;
        newDigit=newDigit % 10;
        //store newDigit in a new node inserted at the head of partialProduct
        partialProduct.appendHead(newDigit);
        //partialProduct.digitCount++
        thisPtr = thisPtr.getPrev();
      }
      if (carry != 0){
        //store carry in a new node inserted at the head of partialProduct
        //partialProduct.digitCount++
        partialProduct.appendHead(carry);
      }
      //insert a new node with 0 at the tail of product to multiply product by 10
      for(int y=0; y<n.digitCount-1-loop; y++){
        partialProduct.append(0);
      }
      loop++;
      product = product.addAbsolute(partialProduct);
      nPtr = nPtr.getNext();
    }
    product.decimalPlaces = this.decimalPlaces + n.decimalPlaces;
    //give an appropriate value to negative field for the sign
    if(!n.negative && this.negative){
      product.negative=true;
    }
    if(n.negative && !this.negative){
      product.negative=true;
    }
    return product;
  }
  
  public Number subtract(Number n){  //Returns a Number which represents "this - n".
    Number subbed= new Number();
    int x=this.compareToAbsolute(n);
    if(n.negative && this.negative){
      //-this-(-n) 
      subbed=this.addAbsolute(n);
      if(x==1){
        subbed.reverseSign();
      }
    }
    if(!n.negative && this.negative){
      //-this-n
      subbed=n.addAbsolute(this);
      subbed.reverseSign();
    }
    if(n.negative && !this.negative){
      //this+n
      subbed=this.addAbsolute(n);
    }
    if(!n.negative && !this.negative){
      //this-n
      subbed= this.subtractAbsolute(n);
      if(x==-1){
        subbed.reverseSign();
      }
    }
    return subbed;
  }
  
  public void reverseSign(){ //Reverses the value of negative.
    if(negative){
      this.negative=false;
    }
    else{
      this.negative=true;
    }
  }
  private Number addAbsolute(Number n){
    int longest;
    int longestDec= n.decimalPlaces;
    //make copy
    Number numberN=new Number(n.toString());
    Number numberThis=new Number(this.toString());
    
    //buffer the decimal
    if(n.decimalPlaces>decimalPlaces){
      numberThis=fillDecimal(numberThis, numberN);
      longestDec= n.decimalPlaces;
    }
    else if(n.decimalPlaces<decimalPlaces){
      numberN=fillDecimal(numberN, numberThis);
      longestDec=this.decimalPlaces;
    }
    
    //pointers
    Node shortPtr;
    Node longPtr;
    
    //get longest list and set pointers
    if(numberN.digitCount > numberThis.digitCount){
      longest=numberN.digitCount;
      shortPtr= numberThis.low;
      longPtr= numberN.low;
    }
    else if(numberN.digitCount < numberThis.digitCount){
      longest=numberThis.digitCount;
      shortPtr= numberN.low;
      longPtr= numberThis.low;
    }
    else{
      longest=numberThis.digitCount;
      shortPtr= numberThis.low;
      longPtr= numberN.low;
    }
    
    Number sum=new Number();
    int carry = 0;
    int temp1;
    int temp2;
    int added;
    
    //add
    while (longPtr != null){
      //add the values stored in the pointed to nodes plus the carry to get int newDigit
      temp1=longPtr.getValue();
      if(shortPtr==null){
        temp2=0;
      }
      else{
        temp2=shortPtr.getValue();
      }
      added=temp1+ temp2+ carry;
      //store newDigit % 10 in a new node inserted at the head of sum
      sum.appendHead(added % 10);
      carry=added / 10;
      //move pointers
      longPtr=longPtr.getPrev();
      if(shortPtr!=null){
        shortPtr = shortPtr.getPrev();
      }
      //end of addition
      if (carry != 0 && longPtr== null){
        //if(sum.digitCount==longestDec){
         // sum.decimalPlaces = longestDec;
        sum.appendHead(carry);
        //sum.decimalPlaces = longestDec;
      }
    }
    sum.decimalPlaces = longestDec;
    sum.trimEnd();
    return sum;
  }
  //subtract
  Number subtractAbsolute(Number n){
    //find larger
    int cmp=this.compareToAbsolute(n);
    if(cmp==0){
      return new Number("0");
    }
    //make copy
    Number numberN=new Number(n.toString());
    Number numberThis=new Number(this.toString());

    int longest;
    int longestDec= n.decimalPlaces;
    //buffer the decimal
    if(n.decimalPlaces>decimalPlaces){
      numberThis=fillDecimal(numberThis, numberN);
      
      longestDec= n.decimalPlaces;
    }
    else if(n.decimalPlaces<decimalPlaces){
      numberN=fillDecimal(numberN, numberThis);
      
      longestDec=this.decimalPlaces;
    }

    //pointers
    Node basePtr, subPtr;
    int temp1, temp2;
    //get longest list and set pointers
    if(cmp==1){
      subPtr= numberN.low;
      basePtr= numberThis.low;
    }
    else if(cmp==-1){
      subPtr= numberThis.low;
      basePtr= numberN.low;
    }
    else{
      return new Number("0");
    }
    //set everything up
    int carry=0;
    int subbed;
    Number sum=new Number();
    //loop
    while(basePtr!=null){
      temp1=basePtr.getValue();
      
      if(subPtr==null){
        temp2=0;
      }
      else{
        temp2=subPtr.getValue();
      }
      subbed=temp1- (temp2+ carry);
      if (subbed < 0){
        subbed += 10;
        carry = 1;
      }
      else{
        carry=0;
      }
      
      //move pointers
      basePtr=basePtr.getPrev();
      if(subPtr!=null){
        subPtr=subPtr.getPrev();
      }
      //store in a new node inserted at the head of sum,
      sum.appendHead(subbed);
    }
    
    sum.decimalPlaces=longestDec;
    sum.trimStart();
    return sum;
  }
  //returns lesser buffered with 0's to equalize decimal places
  private Number fillDecimal(Number lesser, Number greater){
    int temp=greater.decimalPlaces-lesser.decimalPlaces;
    for(int i=0; i<temp; i++){
      lesser.append(0);
    }
    return lesser;
  }
  //add number to the end of list
  private void append(int i){
    //may need to check if empty
    Node newNode= new Node(i);
    if(high==null){
      high=newNode;
      low=newNode;
      digitCount++;
    }
    else{
      digitCount++;
      low.setNext(newNode);
      newNode.setPrev(low);
      low=newNode;
    }
    if(decimalPlaces>0){
      decimalPlaces++;
    }
  }
  //add number to start of list
  private void appendHead(int i){
    Node newNode= new Node(i);
    if(high==null){
      high=newNode;
      low=newNode;
      digitCount++;
    }
    else{
      newNode.setNext(high);
      high.setPrev(newNode);
      high=newNode;
      digitCount++;
    }
  }
  //compare too another number, return 1 if >, -1 if <, and 0 if =
  private int compareToAbsolute(Number n){
    //check size left, if equal look at had and continue
    if((this.digitCount-this.decimalPlaces) > (n.digitCount-n.decimalPlaces)){
      return 1;
    }
    else if((this.digitCount-this.decimalPlaces) < (n.digitCount-n.decimalPlaces)){
      return -1;
    }
    else{
      Node nPtr = n.high;
      Node tPtr = this.high;
      while(true){
        if(nPtr.getValue() > tPtr.getValue()){
          return -1;
        }
        else if(nPtr.getValue() < tPtr.getValue()){
          return 1;
        }
        nPtr=nPtr.getNext();
        tPtr=tPtr.getNext();
        if(nPtr == null && tPtr == null){
          return 0;
        }
        if(nPtr == null){
          return 1;
        }
        else if(tPtr==null){
          return -1;
        }
      }
    }      
  }
  //remove extra zeros from start
  private void trimStart(){
    for(int i=0; i<digitCount-this.decimalPlaces; i++){
      if(this.high.getValue()==0){
        high= high.getNext();
        high.setPrev(null);
        this.digitCount--;
      }
      else{
        return;
      }
    }
  }
  //remove extra zeros from end
  private void trimEnd(){
    for(int i=0; i<this.decimalPlaces; i++){
      if(this.low.getValue()==0){
        low=low.getPrev();
        low.setNext(null);
        this.digitCount--;
        this.decimalPlaces--;
      }
      else{
        return;
      }
    }
  }
  public void validate(String str){
    //one negative at front, one decimal rest numbers
    int decF=0;
    for(int i=0; i<str.length();i++){
      if(str.charAt(i)=='-'){
        if(i!=0){
          throw new InvalidCharacterException("bad character");
        }
      }
      else if(str.charAt(i)=='.'){
        if(decF!=0){
          throw new InvalidCharacterException("double decimal");
        }
        else{
          decF++;
        }
      }
      else if(!Character.isDigit(str.charAt(i))){
        throw new InvalidCharacterException("bad character");
      }       
    }
  }
  public String toString(){ //Returns a String representation of the Number (so it can be displayed by System.out.()).
    String str="";
    if(negative){
      str=str+"-";
    }
    if(digitCount-decimalPlaces==0){
      str=str+".";
    }
    Node ptr=high;
    for(int i=0; i<digitCount; i++){
      str=str+ptr.getValue();
      if(digitCount-decimalPlaces==i+1){
        str=str+".";
      }
      ptr=ptr.getNext();
    }
    return str;
  }
}
