public class Node{
  //fields
  private int value;
  private Node prev=null;
  private Node next=null;
  
  //constructors
  public Node(int value){
    this.value=value;
  }
  public Node(int value, Node prev){
    this.value=value;
    this.prev=prev;
  }
  public Node(int value, Node prev, Node next){
    this.value=value;
    this.prev=prev;
    this.next=next;
  }
  
  //setters
  public void setValue(int value){
    this.value=value;
  }
  public void setPrev(Node prev){
    this.prev=prev;
  }
  public void setNext(Node next){
    this.next=next;
  }
  
  //getters
  public int getValue(){
    return this.value;
  }
  public Node getPrev(){
    return this.prev;
  }
  public Node getNext(){
    return this.next;
  }
}