import java.util.Scanner;
public class Calculator{
  public static void main(String [] args){
    //declarations
    Number curNum=null;
    Number newNum=null;
    Scanner input;
    String str;
    int z=0;
    //menu loop
    while(z==0){
      System.out.println("enter a value: e     add: a\nsubtract: s          multiply: m\nreverse sign: r      clear: c\nquit: q");
      input = new Scanner(System.in);
      switch(input.next().charAt(0)){
        //enter val
        case 'e':
          System.out.println("enter value");
          input = new Scanner(System.in);
          str=input.next();
          
          try{
            curNum=new Number(str);
          }
          catch (InvalidCharacterException e){
            System.out.println(e);   
            break;
          }
          System.out.println(curNum);
          break;
        //add val
        case 'a':
          //make sure theres a cur val
          if(curNum==null){
            System.out.println("No primary value");
            break;
          }
          System.out.println("enter value");
          input = new Scanner(System.in);
          str=input.next();
          try{
            newNum=new Number(str);
          }
          catch (InvalidCharacterException e){
            System.out.println(e);   
            break;
          }
          curNum=curNum.add(newNum);
          System.out.println(curNum);
          break;
        //subtract by value 
        case 's':
          //make sure theres a cur val
          if(curNum==null){
            System.out.println("No primary value");
            break;
          }
          System.out.println("enter value");
          input = new Scanner(System.in);
          str=input.next();
          try{
            newNum=new Number(str);
          }
          catch (InvalidCharacterException e){
            System.out.println(e);   
            break;
          }
          curNum=curNum.subtract(newNum);
          System.out.println(curNum);
          break; 
        //multiply by value
        case 'm':
          //make sure theres a cur val
          if(curNum==null){
            System.out.println("No primary value");
            break;
          }
          System.out.println("enter value");
          input = new Scanner(System.in);
          str=input.next();
          try{
            newNum=new Number(str);
          }
          catch (InvalidCharacterException e){
            System.out.println(e);  
            break;
          }
          curNum=curNum.multiply(newNum);
          System.out.println(curNum);
          break;
        //change sign on saved value
        case 'r':
          //make sure theres a cur val
          if(curNum==null){
            System.out.println("No primary value");
            break;
          }
          curNum.reverseSign();
          System.out.println(curNum);
          break;
        //remove the ssave value
        case 'c':
          curNum=null;
          break;
          
        case 'q':
          z++;
          break;
      }
    }
  }
}