import java.util.*;
class ArrayLinkedList<T> {
    protected final static int NULL = -1;      
    protected ArrayList<Node<T>> array;
    protected NodePool<T> pool;
    protected int head; // position of dummy node in array
    protected int tail; // position of tail node in array
    protected int firstEmpty; // head of the list of empty nodes
    protected int numberEmpty; // number of empty nodes
    protected int size; // number of non-empty nodes
    protected int modCount; // number of modifications made
    protected final static int NODEPOOLSIZE = 8;
 
    // Constructor to initialize the data members, increment modCount,
    // create the dummy header Node, and add it to array
    public ArrayLinkedList(){
      array= new ArrayList<Node<T>>();
      modCount=1;
      head=0;
      size=0;
      firstEmpty=-1;
      Node<T> nHead= new Node<T>();
      array.add(nHead); 
      pool=new NodePool<T>(10);
      tail=0;
      numberEmpty=0;
    }
    // Return number of non-empty nodes
    // Target Complexity: O(1)
    public int size(){
      return size;
    }
    // Return number of empty nodes
    // Target Complexity: O(1)
    public int numberEmpty(){
      return numberEmpty;
    }
    // convenience methods for debugging and testing
    protected int getFirstEmpty(){
      return firstEmpty;   // return firstEmpty
    }
    protected int getHead(){
      return head; // return head
    }
    protected int getTail(){
      return tail;// return tail
    }
    protected ArrayList<Node<T>> getArray(){ 
      // return array. 
      return array;
    }
    
    //Appends the specified element to the end of this list. 
    // Returns true. If no empty Nodes are available, then get a new Node from pool.
    // Throws IllegalArgumentException if e is null.
    // Checks assertions at the start and end of its execution.
    // Target Complexity: Amortized O(1)
      
    public boolean add(T e) {
        assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0  
         && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL)
          && (array.size() == size+numberEmpty+1);         
        if(e==null){
          throw new IllegalArgumentException("Cannot add nulltype to array");
        }
        //no empty node
        if(numberEmpty<1){
          Node<T> node = pool.allocate();
          array.get(tail).next = array.size(); 
          size+=1;
          node.previous=tail;
          node.data=e;
          array.add(node);
          tail=array.size()-1;
        }
        //empty node
        else{
          array.get(firstEmpty).data = e;
          array.get(firstEmpty).previous = tail;
          array.get(tail).next = firstEmpty;
          
          tail= firstEmpty;
          firstEmpty= array.get(firstEmpty).next;
          array.get(tail).next = NULL;
          size+=1;
          numberEmpty-=1;
        }
        modCount+=1;
        // check this assertion before each return statement
        assert size>0 && head==0 && numberEmpty >=0 
          && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
            && firstEmpty!=NULL)
            && (array.size() == size+numberEmpty+1);
        return true;
    }
    
    // Inserts the specified element at the specified index in this list.  
    // Shifts the element currently at that index (if any) and any 
    // subsequent elements to the right (adds one to their indices).    
    // Throws IndexOutOfBoundsException if the index is out of range 
    // (index < 0 || index > size()).
    // Throws IllegalArgumentException if e is null.
    // Can call add(T e) if index equals size, i.e., add at the end
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public void add(int index, T e) {
       assert size>=0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
           && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
 
       if(e==null){
          throw new IllegalArgumentException("Cannot add null to array");
       }
       if(index>size || index<0){  //check about size
         throw new IndexOutOfBoundsException("can not add to specified location");
       }
       //if added to empty or end
       if(index==size){
         this.add(e);
       }
       //no empty nodes, not being added to end
       else if(numberEmpty<1){
          Node<T> node = pool.allocate();
          int prevInd= this.indexToArray(index);
          node.data = e;
          node.previous=array.get(prevInd).previous;       
          if(index>0){
            node.next=this.getNode(index-1).next;
            this.getNode(index-1).next = array.size();
          }
          else{
            node.next=array.get(head).next;
            array.get(head).next=array.size();
          }
              
          array.get(prevInd).previous= array.size();    
          this.size+=1;
          this.array.add(node);
          
        }
       //if added not to end and empty node
        else{
          int location = firstEmpty;
          int arrayLocInd=this.indexToArray(index);
          array.get(firstEmpty).data = e;
          array.get(firstEmpty).previous = this.getNode(index).previous;
          //System.out.println("oldnode previous:" + this.getNode(index).previous); 
          firstEmpty= array.get(firstEmpty).next;
          if(index>0){
             array.get(location).next=this.getNode(index-1).next;
             this.getNode(index-1).next = location;
          }
          else{
            array.get(location).next = array.get(head).next;
            array.get(head).next=location;
          }
          array.get(arrayLocInd).previous = location;
          size+=1;
          numberEmpty-=1;
        }
        modCount+=1;
       // check this assertion before each return statement
       assert size>0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
             && firstEmpty!=NULL) && (array.size() == 
                 size+numberEmpty+1);
       return;
    }
 
    // Equivalent to add(0,e).
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(1)
    public void addFirst(T e){
      //complextiy 
      if(e==null){
          throw new IllegalArgumentException("Cannot add null to array");
      }
      //what if empty
      if(size==0){
        add(e);
        return;
      }
      int oldF= array.get(head).next;
      if(numberEmpty<1){
          Node<T> node = pool.allocate();
          node.previous=head;
          node.next=oldF;
          node.data=e;
          array.get(head).next=array.size();
          array.get(oldF).previous=array.size();
          array.add(node);
      }
      else{
        array.get(firstEmpty).data = e;
        array.get(firstEmpty).previous = head;
        array.get(head).next = firstEmpty;   
        int loc= firstEmpty;
        firstEmpty= array.get(firstEmpty).next;
        array.get(loc).next = array.size();
        array.get(oldF).previous=array.size();
          
        numberEmpty-=1;
      }
      modCount+=1;
      size+=1;
    }
    // Equivalent to add(e).
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(1)
    public void addLast(T e){
        this.add(e);
        modCount+=1;
    }
 
    // Add all of the elements (if any) in Collection c to the end 
    // of the list, one-by-one.
    // Returns true if this list changed as a result of the call.
    // Throws NullPointerException if the specified collection is null
    // Target Complexity: O(number of elements in c)
    @SuppressWarnings("unchecked")
    public boolean addAll(Collection<? extends T> c){
      if(c==null){
        throw new NullPointerException("nothing to add");
      }
      Iterator iter = c.iterator();
      for(int i=0; i< c.size(); i++){
        this.add((T) iter.next());
      }
      return true;
    }
 
    // Returns true if this list contains the specified element.
    // Throws IllegalArgumentException if e is null
    // May call indexOf(e)
    // Target Complexity: O(n)
    public boolean contains(T e){
      if(this.indexOf(e)==NULL){
        return false;
      }
      return true;
    }
       
    // Returns the index of the first occurrence of the 
    // specified element in this list,
    // or NULL if this list does not contain the element.
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(n)
    public int indexOf(T e){
      if(e==null){
        throw new IllegalArgumentException("Cant check for null");
      }
      int loc = array.get(head).next;
      for(int i=0; i<size; i++){
        if(array.get(loc).data.equals(e)){
          return i;
        }
        if(i!=size-1){
          loc=array.get(loc).next;
        }
      }
      return NULL;
   }
   //converts a list location to an array location
   private int indexToArray(int index){
     int loc = array.get(head).next;
     for(int i=0; i<index; i++){
       loc=array.get(loc).next;
     }
     return loc;
   }
   // Returns the array position of the first occurrence of 
   // the specified element in array
   // or NULL (-1) if this list does not contain the element. 
   // Note that the return value is a position in the array, 
   // not the index of an element in the list.
   // Called by remove(T e) to find the position of e in the array.
   // Throws IllegalArgumentException if e is null
   // Target Complexity: O(n)
   protected int positionOf(T e){
      if(e==null){
        throw new IllegalArgumentException("Cant check for null");
      }
      int loc = array.get(head).next;
      for(int i=0; i<size;i++){
        if(array.get(loc).data.equals(e)){
          return loc;
        }
        if(i!=size-1){
          loc=array.get(loc).next;
        }
      }
      return NULL;
    }
   //added in method, returns the node instead of the data element 
   private Node<T> getNode(int index){
     if(index < 0 || index >= size){
       throw new IndexOutOfBoundsException("outta range");
     }
     int loc = this.indexToArray(index);
     return array.get(loc);
   }
   // Returns the element at the specified index in this list.
    // Throws IndexOutOfBoundsException if the index is out 
    // of range (index < 0 || index >= size())
    // Target Complexity: O(n)
   public T get(int index){
     if(index < 0 || index >= size){
       throw new IndexOutOfBoundsException("outta range");
     }
     int loc = array.get(this.getHead()).next;
     for(int i=0; i<index; i++){
       loc=array.get(loc).next;
     }
     return array.get(loc).data;
   }
    // Returns the first element in the list.
    // Throws NoSuchElementException if the list is empty
    // Target Complexity: O(1)
   public T getFirst(){
     if(this.size==0){
       throw new NoSuchElementException("list is empty");
     }
     int hedN= array.get(this.head).next;
     return array.get(hedN).data;
   }
    // Returns the last element in the list
    // Throws NoSuchElementException if the list is empty
    // Target Complexity: O(1)
   public T getLast(){
     if(this.size==0){
       throw new NoSuchElementException("list is empty");
     }
     return array.get(this.tail).data;
   }
 
    // Remove the node at position current in the array.
    // Note that current is a position in the array, not the 
    // index of an element in the list.
    // The removed node is made empty and added to the front 
    // of the list of empty Nodes.
    // Called by remove(T e) and remove(int index) to 
    // remove the target Node.
    // Target Complexity: O(1)
    protected void removeNode(int current) {
       assert current > 0 && current <= array.size();
       //fix nodes
       int prevN=array.get(current).previous;
       int nextN=array.get(current).next;
       //last object has no next so different 
       if(current==tail){
         array.get(prevN).next=NULL;
         tail=prevN;
       }
       //if not last object
       else{
         array.get(prevN).next=nextN;
         array.get(nextN).previous=prevN;   
       }
       //rest of method, initilizes node and sets fields
       array.get(current).init();
       array.get(current).next = firstEmpty;
       firstEmpty=current;  
       size-=1;
       numberEmpty+=1;
       modCount+=1;
    }

    // Removes the first occurrence of the specified element from 
    // this list, if it is present. Returns true if this
    // list contained the specified element.
    // Throws IllegalArgumentException if e is null.
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public boolean remove(T e){
 
       assert size>=0 && head==0 && numberEmpty >=0
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
       if(e==null){
         throw new IllegalArgumentException("can't add null");
       }
       int index=this.positionOf(e);
       
       if(index==-1){
         return false;
       }
       else{
         removeNode(index);
       }
       modCount+=1;
       // check this assertion before each return statement
       assert size>=0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
       return true;
    }
 
    // Removes the element at the specified index in this list.
    // Shifts any subsequent elements to the left (subtracts one from
    // their indices). Returns the element that was removed from the 
    // list. Throws IndexOutOfBoundsException if the index is 
    // out of range (index < 0 || index >= size)
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public T remove(int index) {
      assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
 
      if(index>=size || index<0){
        throw new IndexOutOfBoundsException("index out of range");
      }
      int arrayloc=indexToArray(index);
      T dta = array.get(arrayloc).data;
      removeNode(arrayloc);
 
        // check this assertion before each return statement
       assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0 
        && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL) 
        && (array.size() == size+numberEmpty+1);
       modCount+=1;
       return dta;
    }
 
    // Returns the first element in the list.
    // Throws NoSuchElementException if the list is empty.
    // Equivalent to remove(0), for index 0
    // Target Complexity: O(1)
    public T removeFirst(){
      if(size==0){
        throw new NoSuchElementException("list empty");
      }
      int index=array.get(this.head).next;
      T dta = array.get(index).data;
      removeNode(index);
      modCount+=1;
      return dta;
    }
    // Returns the last element in the list
    // Throws NoSuchElementException if the list is empty
    // Equivalent to remove(size-1), for index size-1
    // Target Complexity: O(1)
    public T removeLast(){
      if(size==0){
        throw new NoSuchElementException("list empty");
      }
      T dta = array.get(tail).data;
      removeNode(tail);
      modCount+=1;
      return dta;
    }
 
    // Returns true if the Node at the specified position in the 
    // array is an empty node.
    // Target Complexity: O(1)
    protected boolean positionIsEmpty(int position) {
      assert position >= 0 && position < array.size();
      if(array.get(position).data==null&&position!=0){
        return true;
      }
      return false;
    }
 
    // Returns number of empty nodes.
    // Target Complexity: O(1)
    protected int numEmpty(){
      return numberEmpty;
    }
    // Replaces the element at the specified position in this 
    // list with the specified element. Returns the element 
    // previously at the specified position.    
    // Throws IllegalArgumentException if e is null.
    // Throws IndexOutOfBoundsException if index is out of 
    // range (index < 0 || index >= size)
    // Target Complexity: O(n)
    public T set(int index, T e){
      if(e==null){
        throw new IllegalArgumentException("cant add a null");
      }
      if(index<0 || index>=size){
        throw new IndexOutOfBoundsException("index out of bounds");
      } 
      int aInd= this.indexToArray(index);
      T dta=array.get(aInd).data;
      array.get(aInd).data=e;
      return dta;
      
    }
 
    // Removes all of the elements from this list. 
    // The list will be empty after this call returns.
    // The array will only contain the dummy head node.
    // Some data members are reinitialized and all Nodes
    // are released to the node pool. modCount is incremented.
    // Target Complexity: O(n)
    public void clear() {
       assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
        && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
       //start at end and remove to front.
       for(int i=array.size()-1; i>=0; i--){
         if(i!=head){
           pool.release(array.get(i));
           array.remove(i);
         }
       }
       head=0;
       array.get(head).next=-1;
       size=0;
       tail=0;
       numberEmpty=0;
       firstEmpty=-1;
       modCount+=1;
       // check this assertion before each return statement
       assert size==0 && head==0 && numberEmpty==0 && firstEmpty==NULL
       && (array.size() == size+numberEmpty+1);
       return;
    }
 
    // Returns an Iterator of the elements in this list, 
    // starting at the front of the list
    // Target Complexity: O(1)
    Iterator<T> iterator(){
      return new ArrayLinkedListIterator();
    }
 
    // Convenience debugging method to display the internal 
    // values of the list, including ArrayList array
    protected void dump() {
      System.out.println();
      System.out.println("**** dump start ****");
      System.out.println("size:" + size);
      System.out.println("number empty:" + numberEmpty);
      System.out.println("first empty:"+firstEmpty);
      System.out.println("head:" + head);
      System.out.println("tail:" + tail); 
      System.out.println("list:");
      System.out.println("array:");
      for (int i=0; i<array.size(); i++) // show all elements of array
         System.out.println(i + ": " + array.get(i));
      System.out.println("**** dump end ****");
      System.out.println();
    }
 
    // Returns a textual representation of the list, i.e., the 
    // data values of the non-empty nodes in list order.
    public String toString(){
      String ps="";
      Iterator iter=this.iterator();
      while(iter.hasNext()){
        ps=ps+iter.next().toString();
      }
      return ps;
    }
   
    // Compress the array by releasing all of the empty nodes to the 
    // node pool.  A new array is created in which the order of the 
    // Nodes in the new array matches the order of the elements in the 
    // list. When compress completes, there are no empty nodes. Resets 
    // tail accordingly.
    // Target Complexity: O(n)
    public void compress(){
   
      ArrayList<Node<T>> arrayTemp= new ArrayList<Node<T>>();
      int tailtemp=0;
      int firstTemp;
      int nxt;
      int prev;
      
      //remove empty nodes
      for(int i=0; i<numberEmpty;i++){
        firstTemp=array.get(firstEmpty).next;
        pool.release(array.get(firstEmpty));
      }
      firstTemp=head;
      arrayTemp.add(array.get(firstTemp));
      nxt=array.get(head).next;
      if(size>0){
        arrayTemp.get(0).next=1;
      }
      //transfer to new list
      for(int j=1; j<=size; j++){
        firstTemp=nxt;
        arrayTemp.add(array.get(firstTemp));      
        arrayTemp.get(j).previous=j-1;
        nxt=array.get(firstTemp).next;
        if(j!=size){
          arrayTemp.get(j).next=j+1;
        }
        //tails.next stays the same
      }
      array=arrayTemp;
      tail=array.size()-1;
      numberEmpty=0;
      firstEmpty=-1;
      modCount+=1;
    }
    // Iterator for ArrayLinkedList. (See the description below.)
    private class ArrayLinkedListIterator implements Iterator<T> {
      // Constructor
      // Target Complexity: O(1)
      private int index;
      private int modOrig;
      public ArrayLinkedListIterator (){
        super();
        modOrig=modCount;
        index=head;
      }
 
      // Returns true if the iterator can be moved to the next() element.
      public boolean hasNext(){
        assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
        //if something added removed or cleared or compressed
        if(modCount!=modOrig){
          throw new ConcurrentModificationException("List was changed");
        }
        return (index!=tail);   
      }
 
      // Move the iterator forward and return the passed-over element
      public T next(){
        assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
        //if something added removed or cleared or compressed
        if(modCount!=modOrig){
          throw new ConcurrentModificationException("List was changed");
        }
        index=array.get(index).next;
        return array.get(index).data;
      }
 
      // The following operation is part of the Iterator interface 
      // but is not supported by the iterator. 
      // Throws an UnsupportedOperationException if invoked.
      public void remove(){
        throw new UnsupportedOperationException("Bad");
      }
    }
}