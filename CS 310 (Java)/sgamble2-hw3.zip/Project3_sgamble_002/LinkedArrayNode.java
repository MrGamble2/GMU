import java.util.*;
public class LinkedArrayNode<T, K extends Comparable<K>> {
  protected LinkedArrayNode<T,K> prev;
  protected LinkedArrayNode<T,K> next;
  protected K key;
  protected Object[] array;          // array holds T objects
  protected static final int DEFAULTLENGTHOFARRAY = 16;
  protected int arraySize;    // number of elements in the array.
 
 
  // Workhorse constructor. Initialize prev and next and the size of the
  // array, and create an array of Objects of the specified length.
  // Parameter lengthOfArray is used to create array. The value of 
  // lengthOfArray need not be saved since it is essentially array.length.
  // Throws IllegalArgumentException if lengthOfArray < 0.
  public LinkedArrayNode(LinkedArrayNode<T, K> prev, LinkedArrayNode<T, K> next, K key, int lengthOfArray){
    this.prev=prev;
    this.next=next;
    this.array=new Object[lengthOfArray];
    this.arraySize=0;
    this.key=key;
  }
 
  // Convenience constructor. Calls the workhorse constructor with 
  // DEFAULTLENGTHOFARRAY as the argument.
  public LinkedArrayNode(LinkedArrayNode<T, K> prev, LinkedArrayNode<T, K> next, K key){
    this.prev=prev;
    this.next=next;
    this.array=new Object[DEFAULTLENGTHOFARRAY];
    this.arraySize=0;
    this.key=key;
  }

  // Add element x to the end of the array.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(1)
  public void add(T x){
    
    if(x==null){
      System.out.println("null");
      throw new IllegalArgumentException();
    }
    if(array.length==arraySize){
      throw new IllegalArgumentException();
    }
    array[arraySize]=x;
    arraySize++;
  }
 
  // Locate and remove the first element that equals x. This may require 
  // elements to be shifted (left). Returns a reference to the removed 
  // element, or null if the element was not removed.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(n)
  @SuppressWarnings("unchecked")
  public T remove(T x){
    int found=0;
    T obj=null;
    for(int i=0; i<array.length; i++){
      if(x.equals(array[i]) && found==0){
        //@SuppressWarnings("unchecked")
        obj=(T) array[i];
        if(i == array.length-1){
          array[i]=null;
        }
        found=1;
      }
      if(found==1 && i != array.length-1){
        array[i]=array[i+1];
      }
    }
    return obj;
  }
  // Returns a reference to the first element in the array that equals x, or 
  // null if there is no matching element. 
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(N)
  @SuppressWarnings("unchecked")
  public T getMatch(T x){
    T obj=null;
    for(int i=0; i<array.length; i++){
      if(x.equals(array[i])){
        //@SuppressWarnings("unchecked")
        obj=(T) array[i];
        return obj;
      }
    }
    return obj;
  }
    
  // toString() - create a pretty representation of the node by
  // showing all of the elements in the array.
  // Target Complexity: O(n)
  // Example: an array with size four and length five: 1, 2, 4, 6
  public String toString(){
    String str=key.toString();
    str=str+": ";
    for(int i=0;i<arraySize;i++){
      str=str+array[i].toString();
      if(i!=arraySize-1){
       str+=", ";
      }
    }
    return str;
  }
}