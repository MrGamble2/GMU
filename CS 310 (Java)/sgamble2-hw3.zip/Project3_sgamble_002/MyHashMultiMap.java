import java.util.*;
public class MyHashMultiMap<ValueType, KeyType extends Comparable<KeyType>> {
  protected static final int DEFAULTTABLESIZE = 101; 
  protected int size;
  protected int tableSize;
  protected Object[] table;
  // Hash table to hold key/value pairs 
  //protected MyHashTable<KeyType,ValueType> items;  
 
  // Constructor
  public MyHashMultiMap(){
    size=0;
    tableSize=DEFAULTTABLESIZE;
    table=new Object[DEFAULTTABLESIZE];
    for(int i=0; i<DEFAULTTABLESIZE; i++){
      table[i]=new LinkedArrays<ValueType,KeyType>();
    }
  }
 
  // Associates the specified key with the specified value in this map.
  // If key is already associated with a List of values, then value
  // is added to this list; otherwise, a new List is created, value is 
  // added to this List, and key is associated with this new List.
  // Throws IllegalArgumentException if key or value is null.
  @SuppressWarnings("unchecked")
  public void put(KeyType key, ValueType value){
    //checks  
    if(key==null){
      throw new IllegalArgumentException();
    }
    if(value==null){
      throw new IllegalArgumentException();
    }
    //get hash value of key
    int loc=myhash(key);
    //insert it by getting the linkedarray and using its function
    LinkedArrays<ValueType,KeyType> nLoc=(LinkedArrays<ValueType,KeyType>)table[loc];
    nLoc.insert(value, key);
    nLoc.size++;  
  }
  // Returns the List of values that key is associated with, or null if 
  // there is no mapping for key.
  // Throws IllegalArgumentException if key is null.
  @SuppressWarnings("unchecked")
  public List<ValueType> get(KeyType key){
    if(key==null){
      throw new IllegalArgumentException();
    }
    int loc=myhash(key);
    LinkedArrays<ValueType,KeyType> nLoc=(LinkedArrays<ValueType,KeyType>)table[loc];
    LinkedArrayNode<ValueType,KeyType> node=nLoc.getNode(key);
    if(node==null){
      throw new IllegalArgumentException();
    }
    else{
      List t=Arrays.asList(node.array);
      List<ValueType> y= (List<ValueType>)(Object)t;
      return y;
    }
  }
  // Returns the number of elements
  // Target Complexity: O(1)
  public int size(){
    return size;
  }
 
  // Returns true if there are no elements.
  // Target Complexity: O(1)
  public boolean isEmpty(){
    if(size==0){
      return true;
    }
    return false;
  }
  @SuppressWarnings("unchecked")
  public String toString(){
    String str="";
    for(int i=0; i<table.length; i++){
      str=str+Integer.toString(i);
      str=str+": ";
      LinkedArrays<ValueType,KeyType> nLoc=(LinkedArrays<ValueType,KeyType>)table[i];
      str=str+nLoc.toString()+"\n";
    }
    //LinkedArrays<ValueType,KeyType> nLoc=(LinkedArrays<ValueType,KeyType>)table[loc];
    //System.out.println(nLoc.toString());
    return str;
  }
  protected int myhash(KeyType x) {
    int hashVal = x.hashCode( );
    hashVal %= tableSize;
    if( hashVal < 0 )
      hashVal += tableSize;
    return hashVal;
  }
  /*public static void main(String[] args){
    MyHashMultiMap<Integer, String> t= new MyHashMultiMap<Integer, String>();
    t.put("Cat",2);
    t.put("Cat",3);
    t.put("dog",6);
    t.put("dog",4);
    t.put("dog",8);
    t.put("bird",3);
    t.put("a",3);
    t.put("b",3);
    t.put("c",3);
    t.put("d",3);
    t.put("e",3);
    t.put("f",3);
    t.put("g",3);
    t.put("e",4);
    t.put("h",3);
    t.put("i",3);
    t.put("j",3);
    t.put("k",3);
    t.put("l",3);
    t.put("m",3);
    t.put("n",3);
    t.put("o",3);
    t.put("p",3);
    t.put("q",3);
    t.put("r",3);
    t.put("s",3);
    t.put("t",3);
    t.put("u",3);
    t.put("v",3);
    t.put("v",35);
    //LinkedArrays<Integer,String> nLoc=(LinkedArrays<Integer,String>)table[47];
    //System.out.println(nLoc.getNode());
    System.out.println(t.toString());
    System.out.println(t.get("v").toString());
  }*/
}

