public class TreeNode<T> {
  protected TreeNode<T> left;
  protected TreeNode<T> right;
  protected TreeNode<T> parent;
  protected T data;
 
  // Constructor initializes data members.
  // Target Complexity: O(1)
  public TreeNode(T data,TreeNode<T> left,TreeNode<T> right,TreeNode<T> parent){
    this.data=data;
    this.left=left;
    this.right=right;
    this.parent=parent;
  }
 
  // Returns a pretty representation of the node.
  // Format: [data]. Example: [3]
  // Target Complexity: O(1)
  public String toString(){
    String str="["+data.toString()+"]";
    return str;
  }
 
  // Returns a pretty representation of the node for debugging.
  // Shows the data values of this node and its left, right, and parent 
  // nodes. Format:[D:data,L:left,R:right,P:parent]. 
  // Example:[D:3, L:1, R:2, P:0]
  // Target Complexity: O(1)
  public String debugToString(){
    String str="[D:"+data.toString()+", L:"+left.toString()+", R:"+right.toString()+", R:"+parent.toString()+"]";
    return str;
  }
}