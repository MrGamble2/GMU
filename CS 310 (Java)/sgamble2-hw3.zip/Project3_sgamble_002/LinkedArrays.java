public class LinkedArrays<T,K extends Comparable<K>> {
  protected int size;                 // number of elements
  protected int nodeCount;            // number of LinkedArrayNodes
  protected final int lengthOfArrays; // value initialized in constructor
  protected static final int DEFAULTLENGTHOFARRAYS = 16;
  protected LinkedArrayNode<T,K> head;        // dummy nodes head and tail
  protected LinkedArrayNode<T,K> tail;
 
  // Workhorse constructor that initializes variables.
  // Throws IllegalArgumentException if lengthOfArray < 0.
  LinkedArrays (int lengthOfArrays){
    if(lengthOfArrays < 0){
      throw new IllegalArgumentException();
    }
    this.lengthOfArrays=lengthOfArrays;
    head=tail=new LinkedArrayNode<T,K>(null, null, null);
  }
  // Convenience constructor. Calls the workhorse constructor with 
  // DEFAULTLENGTHOFARRAYS as the argument.
  LinkedArrays(){
     this(DEFAULTLENGTHOFARRAYS);
  }
 
  // Make this LinkedArrays logically empty.
  // Target Complexity: O(1)
  // Implementation note: It is not necessary to remove() all of the 
  // elements; instead, some data members can be reinitialized.
  // Target Complexity: O(1)
  public void clear(){
    head=tail=new LinkedArrayNode<T,K>(null, null, null);
  }
 
  // Returns the number of elements
  // Target Complexity: O(1)
  public int size(){
    return this.size;
  }
 
  // Returns the number of LinkedArrayNodes.
  // Target Complexity: O(1)
  public int nodeCount(){
    return this.nodeCount;
  }
 
  // Returns true if there are no elements in this LinkedArrays
  // Target Complexity: O(1)
  public boolean isEmpty( ){
    if(head.next==null){
      return true;
    }
    return false;
  }
 
  // Returns the first element that equals x, or null 
  // if there is no such element.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(n) for n elements
  //get match
  public boolean insert(T y, K x){
    if(x==null|| y==null){
      throw new IllegalArgumentException();
    }
    int test;
    int test2=0;
    LinkedArrayNode<T,K> node=null;
    LinkedArrayNode<T,K> ptr=head.next;
    while(ptr!=null){
      test=ptr.key.compareTo(x);
      if(test==0){
        ptr.add(y);
        test2=1;
      }
      ptr=ptr.next;
    }
    if(test2==0){
      //new node
      LinkedArrayNode<T,K> newN=new LinkedArrayNode<T,K>(tail, null, x);
      tail.next=newN;
      tail=newN;
      tail.add(y);
      nodeCount++;
    }
    size++;
    return true;
  }
  
  public LinkedArrayNode<T,K> getNode(K key){
    if(key==null){
      throw new IllegalArgumentException();
    }
    int test;
    
    LinkedArrayNode<T,K> node=null;
    LinkedArrayNode<T,K> ptr=head.next;
    while(ptr!=null){
      test=ptr.key.compareTo(key);
      if(test==0){
        return ptr;
      }
      ptr=ptr.next;
    }
    return ptr;
  }
  
  /*public LinkedArrayNode<T,K> addNode(K x){
    LinkedArrayNode<T,K> node=new LinkedArrayNode<T,K>(tail, null, x);
    tail=node;
    nodeCount++;
    return tail;
  }*/
 
  // Returns true if this LinkedArrays contains the specified element.
  // Throws IllegalArgumentException if x is null. May call getMatch.
  // Target Complexity: O(n)
  //public boolean contains (T x);
 
  // Insert x into the first LinkedArrayNode with an available space in 
  // its array. 
  // Returns true if x was added.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(number of nodes)
  //public boolean add(T x);
 
  // Remove the first occurrence of x if x is present. 
  // Returns a reference to the removed element if it is removed. 
  // When the last data element is removed from (the array in) a
  // LinkedArrayNode, the LinkedArrayNode is removed from the 
  // LinkedArrays.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(n)
  //protected T remove(T x);
    
  // Returns a pretty representation of the LinkedArrays.
  // Example: A LinkedArrays with two LinkedArrayNodes that have arrays 
  // of length two. The size of the first array is two and the size of
  // the second array is one: | 4, 2 | 3 |
 public String toString(){
   //String t="| ";
   LinkedArrayNode<T,K> ptr=head.next;
   String t="";
   if(ptr!=null){
     t="| ";
   }
   while(ptr!=null){
     //System.out.println("Y");
     //t=t+" | ";
     t=t+ptr.toString();
     t=t+" | ";
     ptr=ptr.next;
   }
   //t=t+" |";
   return t;
 }
}