import java.util.*;
public class BinarySearchTree<T extends Comparable<? super T>> {
 protected TreeNode<T> root;        // root of tree
 protected int size;                // size of tree
 protected enum PrePostIn {PREORDER, POSTORDER, INORDER};
 
 // Constructor
 // Initialize variables � root is null and size is 0.
 public BinarySearchTree( ){
   root=null;
   size=0;
 }
 // Constructor that builds a tree from the values in sorted List L.
 // Initialize variables � root is null and size is L.size() - and call 
 // recursive method buildTree() if L.size() > 0.
 // Throws IllegalArgumentException if L is null or any element in L is 
 // null.
 // Assume there are no duplicate elements in L.
 public BinarySearchTree(List<T> L){
   if(L == null){
     throw new IllegalArgumentException();
   }
   if(L.size() > 0){
     root=buildTree(0,L.size()-1,L);
   }
 }
   
    
 // Builds a balanced tree from the values in sorted List L.
 // Start and end are the start and end positions of a sub-list of L.
 // Returns the root of the subtree containing the elements in the 
 // sub-list of L.
 // Throws IllegalArgumentException if L or any element in L is null.
 // Called by BinarySearchTree(List<T> L) and balance().
 // This is a recursive method.
 protected TreeNode<T> buildTree(int start, int end, List<T> L){
   //get mid
   //make nod of it
   //call left or right and set as sides
   //how to do heads, add after creation using null as place
   if(start>end){
     return null;
   }
   
   size++;
   int middle=(end+start)/2;
   //System.out.println(middle);
   TreeNode<T> n;
   TreeNode<T> nL=buildTree(start, middle-1, L);
   TreeNode<T> nR=buildTree(middle+1,end, L);
   
   //to get head it will be if start-1 or end+1
   n=new TreeNode<T>(L.get(middle), nL, nR, null);
   if(nL!=null){
     nL.parent=n;
   }
   if(nL!=null){
     nR.parent=n;
   }
   return n;
   
 }
 
/*public static void main(String [] args){
   List<Integer> myList = new ArrayList<Integer>();
   //System.out.println(3/2);
   //System.out.println(4/2);
   //System.out.println(2/2);
   
   myList.add(1);
   myList.add(2);
   myList.add(3);
   myList.add(4);
   myList.add(5);
   myList.add(6);
   BinarySearchTree<Integer> t=new BinarySearchTree<Integer>(myList);
   System.out.println(t.root.toString());
   System.out.println(t.root.left.toString());
   System.out.println(t.root.left.right.toString());
   System.out.println(t.root.right.toString());
   System.out.println(t.root.right.left.toString());
   System.out.println(t.root.right.right.toString());
 }*/
}
//123456
