//parent class for ciphers has a standard call the cipher method on every char in the msg
public abstract class SymmetricCipher extends Cipher{
  //alphabet being encoded or decoded
  protected Alphabet alphabet;
  //constructor
  public SymmetricCipher(Alphabet alphabet){
    this.alphabet=alphabet;
  }
  //wraps the int around so if the index is over is starts back at 0 and goes from there
  public int wrapInt(int i){
    while(i>=this.alphabet.length()){
      i-=this.alphabet.length();
    }
    while(i<0){
      i+=this.alphabet.length();
    }
    return i;
    }
  //rotates the character to the by a certain amount
  public int rotate(int index, int shift){
    int x=index+shift;
    int fog=this.wrapInt(x);
    return fog;
    }
  //returns the alphabet
  public Alphabet getAlphabet(){ 
    return this.alphabet;
  }
  //calls encrypt deffinition in the lower classes untill its fully encoded
  @Override public String encrypt(String s){
    char x;
    String g="";
    for(int i=0; i<s.length(); i++){
      int dog=this.alphabet.indexOf(s.charAt(i));
      x=this.encrypt1(s.charAt(i));
      g+=x;
    }
    return g;
    }
  //calls encrypt deffinition in the lower classes untill its fully decoded    
   @Override public String decrypt(String s){
    char x;
    String g="";
    for(int i=0; i<s.length(); i++){
      int dog=this.alphabet.indexOf(s.charAt(i));
        x=this.decrypt1(s.charAt(i));
        g+=x;
      }
    return g;
    }
    //Implement this method based upon the decrypt1 definition, which decrypts a single character (think of the Caesar Cipher for an understanding). Throws NotInAlphabetException if any character is found that isn't in the alphabet.
    protected abstract char encrypt1(char c);
    //Child classes must provide a way to encrypt a single character. Child class implementations will throw NotInAlphabetException if any character is found that isn't in the alphabet.
    protected abstract char decrypt1(char c);
}