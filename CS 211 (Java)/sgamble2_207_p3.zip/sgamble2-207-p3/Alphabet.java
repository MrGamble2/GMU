//the alphabet class which holds the symbols rotated over 
public class Alphabet {
  //default alphabet that is used if a new one is not given in later classes.
  public static final Alphabet DEFAULT = new Alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz 1234567890!@#$%^&*()_+-=[]{}\\|;:'\",./?<>");
  //all the symbols in the given Alphabet
  private String symbols;
  //constructor
  public Alphabet(String symbols){
    this.symbols=symbols;
  }
  //returns where a char is in the alphabet
  public int indexOf(char c){
    int i;
    for(i=0;i<this.symbols.length(); i++){
      char current=this.symbols.charAt(i);
      if(c==current){
        return i;
      }
    }
    throw new NotInAlphabetException(c, this);
  }
  //returns the char at a certain index in the alphabet
  public char get(int i){
    if(i>=this.symbols.length()){
      throw new NotInAlphabetException("This index is not within the bounds of Alphabet",'d', this);
    }
     return (this.symbols.charAt(i));
  }
  //returns the length of the alphabet
  public int length(){
    return this.symbols.length();
  }
  //returns the full string of symbols
  public String getSymbols(){
    return this.symbols;
  }
  //returns a s string of the alphabet
  public String toString(){
    return(String.format("Alphabet(%s)",this.symbols));
  }
  //test if an object is an alphabet, then casts it and returns if they are the same
  public boolean equals(Object other){
    if(other instanceof Alphabet){
      Alphabet other2= (Alphabet) other;
      if(this.symbols.equals(other2.symbols)){
        return true;
    }
      else return false;
    }
    else return false;
       }
}