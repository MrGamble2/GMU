//Shifts the characters based on an alphabet by adding the index of the character in the password 
//and the index of the character int the message
public class VigenereCipher extends SymmetricCipher{
  //password that encryption is based off of, each char index is added to another
  protected String password;
  //the current index around the password
  protected int passwordPos;
  //constructor
  public VigenereCipher(String password,Alphabet alphabet){
   super(alphabet);
   this.password=password;
  }
  //constructor if alphabet is not given
  public VigenereCipher(String password){
    super(Alphabet.DEFAULT);
    this.password=password;
  }
  //returns the password
  public String getPassword(){
      return this.password;
  }
  //the encrypt, shifts the word based on the passwords position
  @Override protected char encrypt1(char c){
    char dog=this.password.charAt(this.passwordPos);
    int passint=this.alphabet.indexOf(dog);
    int charint=this.alphabet.indexOf(c);
    int total=passint+charint;
    int xcd=wrapInt(total);
    char finall=this.alphabet.get(xcd);
    passwordPos+=1;
    if(this.password.length()<=this.passwordPos){
      this.passwordPos=0;
    }
    return finall;
  }
  //exact same as decrypt but shits opposite way
  @Override protected char decrypt1(char c){
    char dog=this.password.charAt(this.passwordPos);
    int passint=this.alphabet.indexOf(dog);
    int charint=this.alphabet.indexOf(c);
    int total=charint-passint;
    int xcd=wrapInt(total);
    char finall=this.alphabet.get(xcd);
    passwordPos+=1;
    if(this.password.length()<=this.passwordPos){
      this.passwordPos=0;
    }
    return finall;
  }
  //Relies upon password and passwordPos to decrypt a single char. increment passwordPos. Will throw NotInAlphabetException if any character is found that isn't in the alphabet.
  @Override public String encrypt(String s){
    this.passwordPos=0;
    String x=super.encrypt(s);
    return x;
  }
  //decrypts based on password possetion and 
  @Override public String decrypt(String s){
    this.passwordPos=0;
    String x=super.decrypt(s);
    return x;
  }
  //returns the string to print
  public String toString(){
    return String.format("Vigenere Cipher (password='%s')",this.password);
  }
}
  
  
  