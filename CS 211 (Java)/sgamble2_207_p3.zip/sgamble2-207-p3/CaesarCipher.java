//the ceasar cipher which rotates the characters in a message based on an alphabet and range
public class CaesarCipher extends SymmetricCipher{
  //The number that is used in rotate, tells how far it rotates
  protected int shift;
  //constructor
  public CaesarCipher(int shift, Alphabet alphabet){
    super(alphabet);
    this.shift=shift;
  }
  //constructor
  public CaesarCipher(int shift){
    super(Alphabet.DEFAULT);
    this.shift=shift;
  }
  //definition of how to encrypt one character, rotates by given amount and the switches the char
  @Override public char encrypt1(char c){
   int place=this.alphabet.indexOf(c);
   int holder=this.rotate(place, this.shift);
   char dfh= this.alphabet.get(holder);
   return dfh;
  }
  //definition of how to decrypt one character by reversing encryption
  @Override public char decrypt1(char c){
   int place=this.alphabet.indexOf(c);
   int holder=this.rotate(place, (0-this.shift));
   char dfh= this.alphabet.get(holder);
   return dfh;
  }
  //returns a string of the cipher
  public String toString(){
    return String.format("Caesar Cipher (shift=%d)",this.shift);
  }
}