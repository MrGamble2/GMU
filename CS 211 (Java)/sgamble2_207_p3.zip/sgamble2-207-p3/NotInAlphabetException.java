//exception when range is out of the alphabet range or char is not in alphabet
public class NotInAlphabetException extends RuntimeException{
  //the message the error returns
  public final String msg;
  //the char thats not right
  public final char offender;
  //the alphabet curently being checked
  public final Alphabet a;
  //constructor when a message is given
  public NotInAlphabetException(String msg, char offender, Alphabet a){
    this.msg=msg;
    this.offender=offender;
    this.a=a;
  }
  //when there is no message given it auto generates one
  public NotInAlphabetException(char offender, Alphabet a){
    this.msg=String.format("Not in alphabet: '%c' not found in %s.",offender,a.getSymbols());
    this.offender=offender;
    this.a=a;
    //The constructor initializes the data members.
    //The value of the message is created by calling String.format() to create a string whose format is illustrated by the following example:
  }
  //the to string of the error
  public String toString(){
    return this.msg;
  }
}