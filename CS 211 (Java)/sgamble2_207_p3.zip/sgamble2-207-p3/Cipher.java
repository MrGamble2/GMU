//abstract class for cipher
public abstract class Cipher{
  //place holder
  public abstract String encrypt(String s);
  //place holder
  public abstract String decrypt(String s);
}