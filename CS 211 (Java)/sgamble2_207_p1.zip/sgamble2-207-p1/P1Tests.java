/** Example of using unit tests for programming assignment 1.  This is
 * partially how your code will be graded.  Later in the class we will
 * write our own unit tests.  To run them on the command line, make
 * sure that the junit-4.12.jar is in the project directory.
 * 
 *  demo$ javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar *.java     # compile everything
 *  demo$ java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar P1Tests     # run tests
 * 
 * On windows replace : with ; (colon with semicolon)
 *  demo$ javac -cp .;junit-4.12.jar;hamcrest-core-1.3.jar *.java     # compile everything
 *  demo$ java -cp .;junit-4.12.jar;hamcrest-core-1.3.jar P1Tests     # run tests
 */

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
  
public class P1Tests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("P1Tests");
  }
  
  @Test public void test_A1 (){ assertEquals(  12, TaskA.mostDivisible( 10,   20)); }
  @Test public void test_A2 (){ assertEquals(  30, TaskA.mostDivisible( 29,   31)); }
  @Test public void test_A3 (){ assertEquals(   6, TaskA.mostDivisible(  6,    8)); }
  @Test public void test_A4 (){ assertEquals(  60, TaskA.mostDivisible(  1,  100)); }
  @Test public void test_A5 (){ assertEquals(  12, TaskA.mostDivisible(  5,   12)); }
  @Test public void test_A6 (){ assertEquals(  12, TaskA.mostDivisible(  5,   13)); }
  @Test public void test_A7 (){ assertEquals(  12, TaskA.mostDivisible( 12,   14)); }
  @Test public void test_A8 (){ assertEquals(   6, TaskA.mostDivisible(  5,   10)); }
  @Test public void test_A9 (){ assertEquals(   6, TaskA.mostDivisible(  6,   10)); }
  @Test public void test_A10(){ assertEquals(   6, TaskA.mostDivisible(  6,   11)); }
  @Test public void test_A11(){ assertEquals(  12, TaskA.mostDivisible(  6,   12)); }
  @Test public void test_A12(){ assertEquals(   1, TaskA.mostDivisible(  1,    1)); }
  @Test public void test_A13(){ assertEquals(  10, TaskA.mostDivisible( 10,   10)); }
  @Test public void test_A14(){ assertEquals( 100, TaskA.mostDivisible(100,  100)); }
  @Test public void test_A15(){ assertEquals(   5, TaskA.mostDivisible(  5,    4)); }
  @Test public void test_A16(){ assertEquals(  13, TaskA.mostDivisible( 13,   12)); }
  @Test public void test_A17(){ assertEquals( 100, TaskA.mostDivisible(100,    1)); }
  @Test public void test_A18(){ assertEquals( 840, TaskA.mostDivisible(  1, 1000)); }
  @Test public void test_A19(){ assertEquals(  60, TaskA.mostDivisible( 29,  111)); }
  @Test public void test_A20(){ assertEquals(  40, TaskA.mostDivisible( 40,   45)); }
  
  
  @Test public void test_B_sumRange_1() { assertEquals(  35,TaskB.sumRange( 5,   9)); }
  @Test public void test_B_sumRange_2() { assertEquals(   0,TaskB.sumRange( 9,   5)); }
  @Test public void test_B_sumRange_3() { assertEquals(  45,TaskB.sumRange(-4,  10)); }
  @Test public void test_B_sumRange_4() { assertEquals(   0,TaskB.sumRange(-4,   4)); }
  @Test public void test_B_sumRange_5() { assertEquals(  13,TaskB.sumRange( 6,   7)); }
  @Test public void test_B_sumRange_6() { assertEquals(   7,TaskB.sumRange( 7,   7)); }
  @Test public void test_B_sumRange_7() { assertEquals(5050,TaskB.sumRange( 1, 100)); }
  @Test public void test_B_sumRange_8() { assertEquals(1830,TaskB.sumRange( 0,  60)); }
  @Test public void test_B_sumRange_9() { assertEquals( -45,TaskB.sumRange(-9,  -1)); }
  @Test public void test_B_sumRange_10(){ assertEquals(   5,TaskB.sumRange(-1,   3)); }

  @Test public void test_B_lcm_1() { assertEquals(  60,TaskB.lcm( 20, 30)); }
  @Test public void test_B_lcm_2() { assertEquals(  30,TaskB.lcm( 10, 30)); }
  @Test public void test_B_lcm_3() { assertEquals(4290,TaskB.lcm( 65,330)); }
  @Test public void test_B_lcm_4() { assertEquals(4290,TaskB.lcm(330, 65)); }
  @Test public void test_B_lcm_5() { assertEquals( 323,TaskB.lcm( 17, 19)); }
  @Test public void test_B_lcm_6() { assertEquals( 210,TaskB.lcm( 10, 21)); }
  @Test public void test_B_lcm_7() { assertEquals(  75,TaskB.lcm( 25, 15)); }
  @Test public void test_B_lcm_8() { assertEquals(   4,TaskB.lcm(  1,  4)); }
  @Test public void test_B_lcm_9() { assertEquals( 342,TaskB.lcm( 18, 19)); }
  @Test public void test_B_lcm_10(){ assertEquals(1332,TaskB.lcm(333, 444)); }

  @Test public void test_B_onEdge_1() { assertEquals(true, TaskB.onEdge( 0,  3,  3)); }
  @Test public void test_B_onEdge_2() { assertEquals(false,TaskB.onEdge( 4,  3,  3)); }
  @Test public void test_B_onEdge_3() { assertEquals(true, TaskB.onEdge(94, 10, 10)); }
  @Test public void test_B_onEdge_4() { assertEquals(true, TaskB.onEdge(79, 10, 10)); }
  @Test public void test_B_onEdge_5() { assertEquals(false,TaskB.onEdge(75, 13, 10)); }
  @Test public void test_B_onEdge_6() { assertEquals(true, TaskB.onEdge( 5,  3,  5)); }
  @Test public void test_B_onEdge_7() { assertEquals(false,TaskB.onEdge(20,  5,  3)); }
  @Test public void test_B_onEdge_8() { assertEquals(false,TaskB.onEdge( 3,  5, -5)); }
  @Test public void test_B_onEdge_9() { assertEquals(false,TaskB.onEdge( 3, -5,  5)); }
  @Test public void test_B_onEdge_10(){ assertEquals(false,TaskB.onEdge(-4, 10, 10)); }
  
  @Test public void test_B_allUnique_1() { assertEquals(true,TaskB.allUnique(new int[]{1,2,3})); }
  @Test public void test_B_allUnique_2() { assertEquals(true,TaskB.allUnique(new int[]{})); }
  @Test public void test_B_allUnique_3() { assertEquals(true,TaskB.allUnique(new int[]{2,4,6,1,3,5})); }
  @Test public void test_B_allUnique_4() { assertEquals(false,TaskB.allUnique(new int[]{1,1,2,3,4,5})); }
  @Test public void test_B_allUnique_5() { assertEquals(true,TaskB.allUnique(new int[]{1,2})); }
  @Test public void test_B_allUnique_6() { assertEquals(false,TaskB.allUnique(new int[]{1,2,3,4,5,6,6})); }
  @Test public void test_B_allUnique_7() { assertEquals(false,TaskB.allUnique(new int[]{5,5,5,5,5})); }
  @Test public void test_B_allUnique_8() { assertEquals(false,TaskB.allUnique(new int[]{1,2,3,4,5,4,3,2,1})); }
  @Test public void test_B_allUnique_9() { assertEquals(false,TaskB.allUnique(new int[]{1,2,3,4,5,5,6,7,8})); }
  @Test public void test_B_allUnique_10(){ assertEquals(true,TaskB.allUnique(new int[]{1})); }
  
  @Test public void test_B_firstWithNDivisors_1() { assertEquals(   6, TaskB.firstWithNDivisors( 4)); }
  @Test public void test_B_firstWithNDivisors_2() { assertEquals(  24, TaskB.firstWithNDivisors( 8)); }
  @Test public void test_B_firstWithNDivisors_3() { assertEquals(  12, TaskB.firstWithNDivisors( 6)); }
  @Test public void test_B_firstWithNDivisors_4() { assertEquals( 240, TaskB.firstWithNDivisors(20)); }
  @Test public void test_B_firstWithNDivisors_5() { assertEquals( 360, TaskB.firstWithNDivisors(24)); }
  @Test public void test_B_firstWithNDivisors_6() { assertEquals(   1, TaskB.firstWithNDivisors( 1)); }
  @Test public void test_B_firstWithNDivisors_7() { assertEquals(  16, TaskB.firstWithNDivisors( 5)); }
  @Test public void test_B_firstWithNDivisors_8() { assertEquals(  64, TaskB.firstWithNDivisors( 7)); }
  @Test public void test_B_firstWithNDivisors_9() { assertEquals(  48, TaskB.firstWithNDivisors(10)); }
  @Test public void test_B_firstWithNDivisors_10(){ assertEquals(1024, TaskB.firstWithNDivisors(11)); }
  
  @Test public void test_B_steps_1() {assertEquals(  4, TaskB.steps(  12,   3)); }
  @Test public void test_B_steps_2() {assertEquals( 12, TaskB.steps(  12,   5)); }
  @Test public void test_B_steps_3() {assertEquals(  2, TaskB.steps(  10,   5)); }
  @Test public void test_B_steps_4() {assertEquals(  1, TaskB.steps(  10,  10)); }
  @Test public void test_B_steps_5() {assertEquals(  5, TaskB.steps(   5,   7)); }
  @Test public void test_B_steps_6() {assertEquals( 20, TaskB.steps( 100,   5)); }
  @Test public void test_B_steps_7() {assertEquals(  3, TaskB.steps(   3, 100)); }
  @Test public void test_B_steps_8() {assertEquals(  3, TaskB.steps(  30,  20)); }
  @Test public void test_B_steps_9() {assertEquals(  3, TaskB.steps(   9,  30)); }
  @Test public void test_B_steps_10(){assertEquals( 10, TaskB.steps(  30,   9)); }
  
  @Test public void test_B_countDescents_1() { assertEquals(0, TaskB.countDescents(new int[]{})); }
  @Test public void test_B_countDescents_2() { assertEquals(3, TaskB.countDescents(new int[]{3,2,1,5,4,3,2,1,8,7,6})); }
  @Test public void test_B_countDescents_3() { assertEquals(1, TaskB.countDescents(new int[]{10,8,3,2})); }
  @Test public void test_B_countDescents_4() { assertEquals(2, TaskB.countDescents(new int[]{5,4,4,3,3,2,1,8,7,6,5,4})); }
  @Test public void test_B_countDescents_5() { assertEquals(2, TaskB.countDescents(new int[]{3,2,1,4})); }
  @Test public void test_B_countDescents_6() { assertEquals(5, TaskB.countDescents(new int[]{1,2,3,4,5})); }
  @Test public void test_B_countDescents_7() { assertEquals(6, TaskB.countDescents(new int[]{3,2,1,4,3,2,5,4,3,4,5,6})); }
  @Test public void test_B_countDescents_8() { assertEquals(1, TaskB.countDescents(new int[]{3,3,3})); }
  @Test public void test_B_countDescents_9() { assertEquals(1, TaskB.countDescents(new int[]{6,6,6,5,4})); }
  @Test public void test_B_countDescents_10(){ assertEquals(2, TaskB.countDescents(new int[]{7,6,6,4,2,2,3,1,1,1,-5,-8})); }
  
  /* 
  HONORS SECTION STUDENTS:
  Uncomment this block of tests. They are needed for your extra tasks.
  */
  
  /*
  @Test public void test_Honor_merge_1() { assertArrayEquals(new int[]{1,2,3,4,5,6}, TaskHonor.merge(new int[]{1,2,3}, new int[]{4,5,6})); }
  @Test public void test_Honor_merge_2() { assertArrayEquals(new int[]{1,2,3,4,5,6}, TaskHonor.merge(new int[]{2,4,6}, new int[]{1,3,5})); }
  @Test public void test_Honor_merge_3() { assertArrayEquals(new int[]{1,2,3,4,5,6,7}, TaskHonor.merge(new int[]{1,5,6}, new int[]{2,3,4,7})); }
  @Test public void test_Honor_merge_4() { assertArrayEquals(new int[]{2,5,8}, TaskHonor.merge(new int[]{}, new int[]{2,5,8})); }
  @Test public void test_Honor_merge_5() { assertArrayEquals(new int[]{1,1,2,3,3,3,4,4,4,5,5,6,6}, TaskHonor.merge(new int[]{1,2,3,4,4,5}, new int[]{1,3,3,4,5,6,6})); }
  
  @Test public void test_Honor_split_1() { assertArrayEquals(new int[]{1,2,3}, TaskHonor.split(new int[]{1,2,3,4,5,6},true)); }
  @Test public void test_Honor_split_2() { assertArrayEquals(new int[]{4,5,6}, TaskHonor.split(new int[]{1,2,3,4,5,6},false)); }
  @Test public void test_Honor_split_3() { assertArrayEquals(new int[]{1,2,3}, TaskHonor.split(new int[]{1,2,3,4,5},true)); }
  @Test public void test_Honor_split_4() { assertArrayEquals(new int[]{4,5}, TaskHonor.split(new int[]{1,2,3,4,5},false)); }
  @Test public void test_Honor_split_5() { assertArrayEquals(new int[]{1}, TaskHonor.split(new int[]{1},true)); }
  
  @Test public void test_Honor_mergeSort_1() { assertArrayEquals(new int[]{1,2,3,4,5,6}, TaskHonor.mergeSort(new int[]{1,2,3,4,5,6})); }
  @Test public void test_Honor_mergeSort_2() { assertArrayEquals(new int[]{1,2,3,4,5,6}, TaskHonor.mergeSort(new int[]{5,2,6,3,1,4})); }
  @Test public void test_Honor_mergeSort_3() { assertArrayEquals(new int[]{1,2,3,4,4,5,6}, TaskHonor.mergeSort(new int[]{6,5,2,4,4,1,3})); }
  @Test public void test_Honor_mergeSort_4() { assertArrayEquals(new int[]{1,1,3}, TaskHonor.mergeSort(new int[]{1,3,1})); }
  @Test public void test_Honor_mergeSort_5() { assertArrayEquals(new int[]{}, TaskHonor.mergeSort(new int[]{})); }
  
  */
}
