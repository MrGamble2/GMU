/**
 * Complete each method so that it calculates and returns
 * the indicated value. Each method currently returns a
 * default value in order to compile; these return statements
 * should be deleted once you have your own implementation. 
 * 
 * Don't forget to test your code! Find the given tests and
 * learn how to run them - running (and later, writing) JUnit
 * test cases will be a recurring activity in this class. Part
 * of this project's grade is exactly calculated by what number
 * of test cases pass or fail. Wouldn't you like to know you
 * are failing a test case *before* it gets graded?
 */

class TaskB {
  
  /**
   * from a start to stop value inclusive, add up
   * all the integers in that range. When stop<start, 
   * return zero. When stop==start, include it once.
   * 
   * @param start    first value to add
   * @param stop     last value to add (included)
   * 
   * @return         sum of all integres from start to stop inclusive
   */
  public static int sumRange(int start, int stop){
    if(stop<start){
      return 0;
    }
    int finalval=0;
    for(int x=start; x<=stop; x++){
      finalval=x+finalval;
    }
    return finalval;
  }
  
 /**
   * Calculate the least common multiple of a and b.
   * Assume both are positive integers.
   * 
   * @param a    first integer
   * @param b    other integer
   * 
   * @return     least common multiple of a and b
   */
  public static int lcm(int a, int b){
    //find gcd
    int gcd=0;
    for (int x=1;x<=a;x++){
      if (a%x==0){
        if(b%x==0){
          gcd=x;}
      }
    }
    return ((a*b)/gcd);
}
  
  // given zero-based and row-by-row numbering of cells in a grid, is this an edge cell? (corners included)
  /**
   * - Consider a rectangular grid, of size numRows x numCols.
   * - The top row is row zero, below it row one, and so on.
   * - The leftmost column is column zero, to its right column one, and so on.
   * - We number the cells inside of it from left to right,
   *   top to bottom (like reading an English book).
   * - We start numbering with zero and increase them sequentially.
   * 
   * Given a cell number and the number of rows and columns,
   * return true if this is on an edge (including corners) 
   * or not. Return false for interior cells (and also negative numbers).
   * 
   * @param n          cell number
   * @param numRows    number of rows in the grid
   * @param numCols    number of columns in the grid
   * 
   * @return           boolean, is cell n on the edge of the grid?
   */
  public static boolean onEdge(int n, int numRows, int numCols) {
    if (n<0||numCols<0||numRows<0||n>(numRows*numCols)){
      return false;}
    if ((n+1)<=numCols){
      return true;
    }
    if( (n+1)%numCols==0){
      return true;}
    if ((n+1)%numCols==1){
      return true;}
    if ((n+1)>=((numRows*numCols)-numCols))
          return true;
     return false;
  }
      
 
  
  
  /**
   * Given an array of integers, are they all different values?
   * 
   * @param xs    array of integers to check for uniqueness
   * 
   * @param       boolean representing if all values in xs were unique
   * 
   */
  public static boolean allUnique(int[] xs){
      for(int i=0;i<xs.length-1;i++){
        for(int d=i+1;d<xs.length;d++){
        if (xs[i]==xs[d])
          return false;
        }
      }
      return true;
  }
  
  /*
   * Considering all positive integers, what is the smallest 
   * integer that has exactly n divisors? 1 and n are always
   * divisors (though n might be 1!).
   * 
   * @param n    number of divisors to seek
   * 
   * @return     lowest positive integer with exactly n divisors
   */
  public static int firstWithNDivisors(int n){
    //loops indefinatly from one
    for (int i=1;;i++){
      //resets counter
      int count=0;
      //for currernt number in first loop, loop through values to find how many divisors it has
      for (int x=1;x<=i;x++){
        if (i%x==0){
          count=count+1;
        }
      }
      //if count reached the wanted number n, return current number
      if (count==n){
        return i;}
    } 
  }
  
  /**
   * 
   * given a circle with some # posts around it, if we hop by
   * stride posts at a time, how many hops does it take to get
   * back to the post on which we started? You can think of a
   * clock as such a circle with 12 posts. If we started at 
   * 12, and took strides of 3, it would take four steps. If we
   * started at 12, and took strides of 5, we would land on 5,
   * 10, 3, 8, 1, 6, 11, 4, 9, 2, 7, 12, for a total of 12 steps.
   * 
   * @param posts     number of locations on the circle.
   * @param stride    number of locations per jump.
   * 
   * @return          number of jumps needed to arrive back at the original post.
   */
  public static int steps(int posts, int stride){
    int curPost=0;
    int stepstak=0;
    while (curPost!=posts){
      curPost=curPost+stride;
      stepstak+=1;
      while (curPost>posts){
        curPost=curPost-posts;}   
      
  }
     return stepstak;
  }
  
  /*
   * This method will step through an array of ints and calculate how
   * many descending sequences are present, and return that number. Any
   * time the next int is larger than the previous, it's the beginning
   * of a new sequence. Sequences can be as short as one number long.
   * Equal consecutive values are in the same sequence.
   * 
   * @param xs   the array of ints to be inspected
   * @return     the number of descending sequences found in xs
   */
  public static int countDescents(int[] xs) {
    //checks for empty array
    if (xs.length==0){
      return 0;
    }
    //set up
    boolean newseq=true;
      int counter=0;
     //start of loop over array
    for(int i=0;i<(xs.length);i++){
      //if not on the first one
      if (i>0){
        //check if larger that previous, if so we are a new sequence
        if (xs[i]>xs[i-1]){
        newseq=true;
      }
      }
      //else we are not a new sequence
      if (i>0){
        if (xs[i]<=xs[i-1]){
        newseq=false;
        }
      }
      //if we are a new seq, add one to counter
      if ((newseq==true)){
        counter=counter+1;}
    }
    return counter;}
}
