
/* Fix me! All sorts of bugs in here... Make this class pass all its tests from P1Tests.java.
 */


// we make a class to hold our main method.
public class TaskA {
  
  /** we write a main method, describing what calculation to perform when the 
    * program runs. All it does is call mostDivisible() as an example usage.
    * (this method isn't broken; you can change the arguments to run other tests).
    */
  public static void main(String[] args){
    int lower = 10;
    int higher = 20;
    int best = mostDivisible(lower, higher);
    // Let's print out what the value is politely.
    System.out.println("the number from "+lower+" to "+higher
           + " inclusive with the most divisors is "
           + best);
  }
  

  /**
   * given the lower and upper bound on a range of numbers,
   * which one has the most divisors?
   * 
   * @param low   the lowest  number to consider (included)
   * @param high  the highest number to consider (included)
   * 
   * @return      the number in range that has the most divisors
   */
  public static int mostDivisible(int low, int high){
    // store the best answer candidate in ans, and its number of divisors in numDivs.
    int ans = low;
    int numDivs = 0;
    
    // check each possible answer candidate to see if it's better than any before it.
    for (int i=low; i <= high; i++){
      // calculate current number's divisors.
      int currentDivs=0;
      // look at each possible divisor and include it in the count if it counts.
      for (int d=1; d<=i; d++){
        if (i%d==0){
          currentDivs++;
        }
      }
      
      if (currentDivs>numDivs){
        ans = i;
        numDivs = currentDivs;}
      
    }
    return ans;
  }
}