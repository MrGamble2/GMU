import java.util.*;
public class MakeShape implements Shape{
  int height;
  int width;
  char display;
  Rotation rotate;
  List<List<Spot>> shape;
  public MakeShape(String stuffs, char display){
    this.display=display;
    Scanner dog=new Scanner(stuffs);
    int wid=0;
    int hei=0;
    Spot ghj;
    List<List<Spot>> full = new ArrayList<List<Spot>>();
    while(dog.hasNext()){
      List<Spot> l = new ArrayList<Spot>(); 
      hei++;
      String y=dog.next();
      wid=y.length();
      for(int i=0; i<y.length();i++){
        char f=y.charAt(i);
        if(f=='.'){
          ghj=new Spot(2,f,true);
        }
        else{
          ghj=new Spot(2,f,false);
        }
        l.add(ghj);
      }
      full.add(l);
    }
    boolean test=false;
    boolean test1=false;
    for(int i=0; i<full.size();i++){
     
      if(full.get(i).get(0).getDisplay()==display){
        test=true;
      }
    }
    if(test==false){
      throw new FitItException("not right shape");
    }
    test=false;
    for(int a=0;a<full.size();a++){
    
      if(full.get(a).get(full.get(0).size()-1).getDisplay()==display){
        test=true;
      }
    }
    if(test==false){
      throw new FitItException("not right shape");
    }
    test=false;
    test1=false;
    for(int c=0;c<full.get(0).size();c++){
      if(full.get(0).get(c).getDisplay()==display){
        test=true;
      }
      if(full.get(full.size()-1).get(c).getDisplay()==display){
        test1=true;
      }
    }
    if(test==false){
      throw new FitItException("not right shape");
    }
    if(test==false){
      throw new FitItException("not right shape");
    }
    
    this.shape=full;
    this.height=hei;
    this.width=wid;
    this.rotate=Rotation.CW0;  
  }
   // Return the number of rows of the shape
  public int getHeight(){
    return this.height;
  }

  // Return the number of columns of the shape
  public int getWidth(){
    return this.width;
  }
  public List<List<Spot>> getShape(){
    return this.shape;
  }
  // When drawing this shape in a text terminal, the character
  // returned by displayChar will be used
  public char getDisplayChar(){
    return this.display;
  }

  // Set how the shape will be displayed in text terminals
  public void setDisplayChar(char c){
    for(int i=0; i<this.shape.size();i++){
      for(int x=0; x<this.shape.get(0).size();x++){
        if(this.shape.get(i).get(x).getDisplay()==this.display){
          this.shape.get(i).set(x, new Spot(1, c, false));
        }
      }
    }
    this.display=c;
    
  }

  // Rotate this shape clockwise by 90 degrees. Adjust all internal
  // state required to achieve the rotation including height and width
  public void rotateCW(){
    this.rotate=this.rotate.next();
    int x=this.width;
    this.width=this.height;
    this.height=x;
    List<List<Spot>> full=new ArrayList<List<Spot>>();
    List<Spot> temp=new ArrayList<Spot>();
    Spot[] row = new Spot[this.shape.size()];
    Spot[][] finall = new Spot[this.shape.get(0).size()][this.shape.size()];
    for(int i=0; i<this.shape.get(0).size();i++){
      for(int v=0; v<this.shape.size();v++){
        finall[i][this.shape.size()-1-v]=this.shape.get(v).get(i);
      }
    }
    for(int r=0; r<finall.length;r++){
      for(int z=0; z<finall[0].length;z++){
        
        temp.add(finall[r][z]);
      }
      full.add(temp);
      temp=new ArrayList<Spot>();
    }
    this.shape=full;
    //get the max length of a row then for a postiotn subtract its current from the total
  }

  // Return a value from the Rotations enumeration indicating how
  // much the shape has been rotated from its original position.
  public Rotation getRotation(){
    return this.rotate;
  }

  // Return true if the shape has a filled block at the given row/col
  // position and false if the block is empty. If the position is out
  // of bounds, raise a FitItException with an informative message.
  public boolean isFilledAt(int row, int col){
    try{
      Spot y=this.shape.get(row).get(col);
    }
    catch(Exception x){
      throw new FitItException("Borders do not work");
    }
    Spot y=this.shape.get(row).get(col);
    if(y.getDisplay()=='.'){
      return false;
    }
    else{
      return true;
    }
 
  }

  // Create a string representation of the shape. The format must
  // follow this convention:
  //
  // SHAPE c
  // height: 2; width: 3; rotation: CW270
  // ..c
  // ccc
  public String toString(){
    String finall="";
    finall+="SHAPE "+Character.toString(this.display)+"\n";
    finall+="height: "+Integer.toString(this.height)+"; width: "+Integer.toString(this.width)+"; rotation: "+this.getRotation().toString()+"\n";
    for(int i=0; i<this.shape.size();i++){
      for(int x=0; x<this.shape.get(0).size();x++){
        finall=finall+this.shape.get(i).get(x).getDisplay();
      }
      finall=finall+"\n";
    }
    return finall;   
  }


}