public enum Rotation{
  CW0("0"), CW90("90"), CW180("180"), CW270("270");
  private String rotate;
  private Rotation(String it){
    this.rotate=it;
  }

  // Calling rot.next() will return the next enumeration element
  // representing the next 90 degree clock-wise rotation after rot.
  public Rotation next(){
    if(this.rotate.equals("0")){
      return Rotation.CW90;
    }
    if(this.rotate.equals("90")){
      return Rotation.CW180;
    }
    if(this.rotate.equals("180")){
      return Rotation.CW270;
    }
    if(this.rotate.equals("270")){
      return Rotation.CW0;
    }
    return Rotation.CW90;
        
  }
  public String toString(){
    if(this.rotate.equals("0")){
      return "CW0";
    }
    if(this.rotate.equals("90")){
      return "CW90";
    }
    if(this.rotate.equals("180")){
      return "CW180";
    }
    if(this.rotate.equals("270")){
      return "CW270";
    }
    return "CW90";
  }
}