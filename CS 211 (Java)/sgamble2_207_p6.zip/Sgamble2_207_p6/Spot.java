public class Spot{
  int shape;
  char display;
  boolean empty;
  public Spot(int shape, char display, boolean empty){
    this.shape=shape;
    this.display=display;
    this.empty=empty;
  }
  public boolean isEmpty(){
    return this.empty;
  }
  public int getShape(){
    return this.shape;
  }
  public char getDisplay(){
    return this.display;
  }
}