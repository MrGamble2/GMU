import java.util.*;
public class MakeSpace implements Space{
  int height;
  int width;
  List<List<Spot>> space;
  int numShapes;
  List<MakeShape> allShapes;
  public MakeSpace(String layout){
    this.numShapes=0;
    Scanner dog=new Scanner(layout);
    int wid=0;
    int hei=0;
    Spot fgh;
    this.allShapes=new ArrayList<MakeShape>();
    List<List<Spot>> full = new ArrayList<List<Spot>>();
    while(dog.hasNext()){
      List<Spot> l = new ArrayList<Spot>(); 
      hei++;
      String y=dog.next();
      wid=y.length();
      for(int i=0; i<y.length();i++){
        char dis=y.charAt(i);
        if(dis=='.'){
          fgh=new Spot(0, dis, true);
        }
        else{
          fgh=new Spot(0,dis,false);
        }
        l.add(fgh);
      }
      full.add(l);
    }
    this.space=full;
    this.height=hei;
    this.width=wid;
  }
  // Return the number of rows of the space
  public int getHeight(){
    return this.height;
  }
  // Return the number of columns of the space
  public int getWidth(){
    return this.width;
  }
  // Return true if the space has a filled block at the given row/col
  // position and false if the block is empty. A block may be filled
  // if it is permanently filled or if a shape has been placed in a
  // position such that the space's block is filled by the shape's block
  // If the position is out of bounds, return true as there is implicit
  // fill all around the space. DO NOT THROW EXCEPTIONS from this
  // method.
  public boolean isFilledAt(int row, int col){
    try{
      Spot y=this.space.get(row).get(col);
    }
    catch(Exception x){
      throw new FitItException("Borders do not work");
    }
    Spot y=this.space.get(row).get(col);
    if(y.isEmpty()){
      return false;
    }
    else{
      return true;
    }
  }

  // Determine if the given shape may be placed at the indicated
  // row/col position.  The row,col indicates where the upper left
  // corner [block (0,0)] of the shape would be placed.  A shape would
  // not fit if one of its filled blocks would conflict with an
  // existing filled block in the space or would be out of bounds in
  // the space.
  public boolean shapeFitsAt(int row, int col, Shape shape){
    MakeShape f=(MakeShape)shape;
    boolean works=true;
    for(int i=0; i<f.getShape().size();i++){
      for(int x=0; x<f.getShape().get(0).size();x++){
        if(f.isFilledAt(i,x)){
          if(!(this.isFilledAt(row+i,col+x))){
            int d=1;
          }
          else{
            works=false;
          }
        }
      }
    }
    return works;
  }
  // Place the given shape at the given row/col position.  The row,col
  // indicates where the upper left corner [block (0,0)] of the shape
  // would be placed.  The shape should be removable and when
  // displaying info on the placed shapes, they must be shown in order
  // of their display characters (shape A before B before C...).
  // There may be more than one shape in a space with the same display
  // character.  If the shape would not fit at the specified row/col
  // position, raise a FitItException with an informative message.
  public void placeShapeAt(int row, int col, Shape shape){
    MakeShape f=(MakeShape)shape;
    Spot fgh;
    if(!(this.shapeFitsAt(row,col,shape))){
      throw new FitItException("No fit hombre");
    }
    this.allShapes.add(f);
    for(int i=0; i<f.getShape().size();i++){
      for(int x=0; x<f.getShape().get(0).size();x++){
        fgh=f.getShape().get(i).get(x);
        if(this.space.get(row+i).get(col+x).getDisplay()=='.'){
          this.space.get(row+i).set(col+x,fgh);
        }
      }
    }
     this.numShapes++;
  }
  public List<Integer> findShapeLoc(char c){
    //find the left most one, that is col, find top most one, that is row
    int row=-1;
    int col=-1;
    List<Integer> l = new ArrayList<Integer>();
    for(int i=0;i<this.space.get(0).size();i++){
      for(int x=0;x<this.space.size();x++){
        if(this.space.get(x).get(i).getDisplay()==c){
          col=i;
          break;
        }
      }
      if(col>-1){
        break;
      }
    }
    for(int y=0;y<this.space.size();y++){
      for(int z=0;z<this.space.get(0).size();z++){
        if(this.space.get(y).get(z).getDisplay()==c){
          row=y;
          break;
        }
      }
      if(row>-1){
        break;
      }
    }
    l.add(row);
    l.add(col);
    return l;
  }
    

  // Remove the shape with the display character indicated by dc from this
  // space. Update all internal state so that blocks in the space that
  // were filled by the removed shape are emptied.
  public void removeShapeByDisplayChar(char c){
    Spot fgh;
    for(int b=0; b<this.allShapes.size();b++){
      if(allShapes.get(b).getDisplayChar()==c){
        allShapes.remove(b);
      }
    }
    for(int i=0; i<this.space.size();i++){
      for(int x=0; x<this.space.get(0).size();x++){
        fgh=this.space.get(i).get(x);
        if(fgh.getDisplay()==c){
          this.space.get(i).set(x, new Spot(0, '.', true));
        }
      }
    }
     this.numShapes= this.numShapes-1;
  }

  // Return how many shapes have been placed in this space.
  public int placedShapeCount(){
    return this.numShapes;
  }

  // Return a string representing the space and the shapes that have
  // been fit into it. The following character conventions must be
  // used.
  //  | : vertical bar for permanently filled blocks
  //  . : period for empty blocks
  // displaychar : any space filled by a shape uses its display char
  //
  // Example:
  // aa.....e
  // aacddd.|
  // cccdd|||
  public String fitString(){
    char spotDis;
    Spot spot;
    String finall="";
    for(int i=0; i<this.space.size();i++){
      for(int x=0; x<this.space.get(0).size();x++){
        spot=this.space.get(i).get(x);
        spotDis=spot.getDisplay();
        String temp=Character.toString(spotDis);
        finall+=temp;
      }
      finall+="\n";
    }
    return finall;
  }

  // Give a listing of all the placed shapes. This should start with
  // the number of placed shapes, show the position of each shape, and
  // use the toString() of each shape.  Shapes must be reported in
  // sorted order based on their display character (shape A before B
  // before C...).
  //
  // Example:
  //
  // 3 shapes placed
  // Shape at (0,0)
  // SHAPE a
  // height: 2 width: 2 rotation: CW90
  // aa
  // aa
  // 
  // Shape at (0,2)
  // SHAPE b
  // height: 1 width: 4 rotation: CW180
  // bbbb
  //
  // Shape at (1,0)
  // SHAPE c
  // height: 2 width: 3 rotation: CW270
  // ..c
  // ccc
  public String placedShapeInfo(){
    char temp1;
    char temp2;
    char tempChar;
    String finall="";
    finall+=Integer.toString(allShapes.size())+" shapes placed\n";
    String temp="";
    for(int i=0; i<this.allShapes.size();i++){
      for(int x=1; x<this.allShapes.size();x++){
        temp1=this.allShapes.get(x).getDisplayChar();
        temp2=this.allShapes.get(x-1).getDisplayChar();
        if(Character.toLowerCase(temp1)<=Character.toLowerCase(temp2)){
          MakeShape hold=this.allShapes.get(x);
          this.allShapes.set(x, this.allShapes.get(x-1));
          this.allShapes.set(x-1, hold);
        }
      }   
    }
    String ttt="";
    for(int ght=0; ght<this.allShapes.size();ght++){
      ttt+=Character.toString(allShapes.get(ght).getDisplayChar());
    }
    for(int i=0; i<this.allShapes.size();i++){
       tempChar=this.allShapes.get(i).getDisplayChar();
       List<Integer> fgt=this.findShapeLoc(tempChar);
       temp="Shape at ("+Integer.toString(fgt.get(0))+","+Integer.toString(fgt.get(1))+")";
       temp+="\n";
       finall+=temp;
       MakeShape shoop=allShapes.get(i);
       finall+=shoop.toString();
       finall+="\n";
    }
    return finall;
  }

  // Print a verbose string representation of the space. Start with
  // the string SPACE: then follow with the fitString() of the space
  // and finally the placedShapeInfo() string.
  //
  // Example:
  // 
  // SPACE:
  // height: 3 width: 8
  // aabbbbfe
  // aacdddf|
  // cccdd|||
  // 
  // 6 shapes placed
  // Shape at (0,0)
  // SHAPE a
  // height: 2 width: 2 rotation: CW90
  // aa
  // aa
  // 
  // Shape at (0,2)
  // SHAPE b
  // height: 1 width: 4 rotation: CW180
  // bbbb
  // ...
  public List<List<Spot>> getSpace(){
    return this.space;
  }
  public String toString(){
    String finall="";
    finall+="SPACE:\n";
    finall+="height: "+Integer.toString(this.getHeight())+" width: "+Integer.toString(this.getWidth())+"\n";
    finall+=this.fitString()+"\n";
    finall+=this.placedShapeInfo();
    return finall;
  }
}