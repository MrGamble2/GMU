import java.util.*;
import java.io.*;
public class FitIt{

  // Factory methd to produce shapes. Call a constructor for one of
  // your own classes here. The layout given is be in the format
  //
  // ..e
  // eee
  //
  // Newlines (\n) show breaks in the rows of the Shape.  The period
  // (.) is used to represent empty blocks. Any other character is a
  // filled block even if it does not match the given displayChar.
  // The Shape returned by this method should have the display
  // character displayChar even if that character does not appear in
  // the layout string.  If the shape contains any empty border sides,
  // throw a SpaceShapeException with an informative message.
  public static Shape makeShape(String layout,char displayChar){
    MakeShape x=new MakeShape(layout, displayChar);
    return x;
  }

  // Factory method to produce instances of space. Call a constructor
  // for one of your own classes here. The layout parameter will be in
  // the format
  //
  // |.......
  // ..|||..|
  // ..|.|...
  // ........
  //
  // where vertical bars are filled blocks and periods are empty blocks.
  public static Space makeSpace(String layout){
    MakeSpace x=new MakeSpace(layout);
    return x;
  }

  // Search for a fit of the given shapes in the given space. Return
  // null if no fit exists. If a fit is found, return a space with all
  // shapes placed in it. It is very useful for this method to be
  // recursive.
  public static Space searchForFit(Space space, List<Shape> unplaced){
    //check if at the end
    if(unplaced.size()==0){
      return space;
    }
    Shape temp=unplaced.get(0);
    MakeSpace fgt=(MakeSpace) space;
    List<List<Spot>> xy=fgt.getSpace();
    for(int i=0; i<xy.size();i++){
      for(int x=0; x<xy.get(0).size();x++){
        for(int y=0; y<4;y++){
          try{
            space.placeShapeAt(i,x,unplaced.get(0));
            //remove it
            temp=unplaced.get(0);
            unplaced.remove(0);
            FitIt.searchForFit(space, unplaced);
            if(unplaced.size()==0){
              return space;
            }
            MakeShape god=(MakeShape) temp;
            space.removeShapeByDisplayChar(god.getDisplayChar());
            unplaced.add(0, temp); 
          }
          catch(Exception r){
            MakeShape ho=(MakeShape) unplaced.get(0);
            ho.rotateCW();
            unplaced.set(0, ho);
          }
        }
      }
    }
    return null;
  }

  // Read an input file which contains a fitting problem in it. The
  // input file is the zeroth command line argument. The file format
  // contains records for SPACE and SHAPE. There should only be one
  // SPACE per file but potentially many SHAPEs.  SHAPE is followed by
  // a display character for the shape.  SPACE and SHAPE records
  // continue until a black line.  Any line that does not start with
  // SPACE or SHAPE should be ignored.  The main method should read
  // this file, initialize spaces and shapes using the methods
  // makeShape() and makeSpace().  It should then execute
  // searchforFit(space,shapes) and report the results as either
  // 
  // NO FIT FOUND
  // 
  // or
  // 
  // FIT FOUND
  //   then call the toString() method of space
  public static void main(String args[]) throws Exception{
    MakeSpace vf=new MakeSpace(".");
    List<Shape> unplaced=new ArrayList<Shape>();
    Scanner dog=new Scanner(new File(args[0]));
    boolean end=false;
    String whole="";
    while(dog.hasNextLine()){
      String x=dog.next();
      if(x.equals("SPACE")){
        while(!(end)){
          String y=dog.next();
          if(y.equals("")){
            vf=new MakeSpace(whole);
            break;
          }
          y+="\n";
          whole+=y;
        }
      }
      if(x.equals("SHAPE")){
        char dis=dog.next().charAt(0);
        String z="";
        while(dog.hasNext()){
          x=dog.nextLine();
        
          if(x.equals("")){
           
           MakeShape p=new MakeShape(z,dis);
           unplaced.add(p);
           break;
          }
          x+="\n";  
          z+=x;
        }
      }
    }
      Space z=FitIt.searchForFit(vf, unplaced);
      if(z==null){
        System.out.println("NO FIT FOUND");
      }
      else{
        System.out.println("FIT FOUND");
        System.out.println(z.toString());
      }
    }
}

