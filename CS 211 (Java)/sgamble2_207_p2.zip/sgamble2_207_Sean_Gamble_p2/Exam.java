import java.util.Scanner;
class Exam {
  private String firstName, lastName;
  private int ID, score;
  private char examType;

  public Exam(String firstName,String lastName,int ID, String examType, int score){
    this.firstName=firstName;
    this.lastName=lastName;
    this.ID=ID;
    if(examType.equals("midterm")){
      this.examType='M';
    }
    else if(examType.equals("final")){
         this.examType='F';
       }
    else{
    this.examType= 'E';
    }
    this.score=score;
  }
  public String getFirstName(){
    return this.firstName;
  }
  public String getLastName(){
    return this.lastName;
  }
  public int getID(){
    return this.ID;
  }
  public char getExamType(){
    return this.examType;
  }
  public int getScore(){
    return this.score;
  
  }
  public String toString(){
    String xsg;
    if(this.examType=='M'){
      xsg="midterm";
    }
    else{
      xsg="final";
    }
    String x= String.format("%s %s %d %s %d",this.firstName, this.lastName, this.ID, xsg, this.score);
    return x;
  }
  public boolean equals(Exam e){
   if(this.firstName.equals(e.firstName) && this.lastName.equals(e.lastName) && this.ID==e.ID && this.examType==e.examType &&this.score==e.score)
     return true;
   else return false;
  }
}
  