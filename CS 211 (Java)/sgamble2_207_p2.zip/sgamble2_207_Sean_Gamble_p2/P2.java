import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
class P2 {
  public static Exam readExam(Scanner s){
    String firstName=s.next();
    String lastName=s.next();
    int ID=s.nextInt();
    String exaType = s.next();
    int score = s.nextInt();
    Exam nxtexam= new Exam(firstName,lastName,ID, exaType, score);
    s.close();
    return nxtexam;
  }
  public static Exam[] readAllExams(Scanner s){
      int loop=Integer.parseInt(s.nextLine());
      Exam[] exams= new Exam[loop];
      for(int i=0;i<loop;i++){
        String test=s.nextLine();
        Scanner scr = new Scanner(test);
        exams[i]=readExam(scr);
        }

      return exams;
  }
  public static Exam[] collateExams(Exam[] exams){
    int len=exams.length;
    Exam[] exam2=new Exam[len];
    Exam[] examFinal=new Exam[len];
    Exam[] examMid=new Exam[len];
    int midcnt=0;
    int fincnt=0;
    int xy=1;
    int i=0;
    int loop=0;
    int curmid=0;
    int curfin=0;
    while(xy==1){
      if (i>=len){
        i=0;
        loop+=1;
      }
      if (exams[i].getExamType()=='M' && loop==0){
        examMid[midcnt]=exams[i];
        midcnt+=2;
      }
      else if(loop==0){
        examFinal[fincnt]=exams[i];
        fincnt+=1;
      }
      
      if(loop>=1){
        for(int h=0;h<loop;h++){
        }
        for(int h=0;h<loop;h++){
        }
        if (examMid[curmid].getFirstName().equals(examFinal[curfin].getFirstName())){
          examMid[curmid+1]=examFinal[curfin];
          curfin=0;
          curmid+=2;
        }
        else{
          curfin+=1;
        }
        }
      i++;
      if (examMid[len-1]!=null){
        xy+=1;
    
      }
    //if there is nothing in last slot then dont end
  }
    return examMid;
  }
  public static float getCollatedMidtermAverage(Exam[] collated){
    int count=0;
    int totalscore=0;
    for(int cnt=0; cnt<collated.length;cnt++){
      if(collated[cnt].getExamType()=='M'){
        totalscore+=collated[cnt].getScore();
        count+=1;
      }
    }
    int finall=totalscore/count;
    return finall;
    }
    
  public static float getCollatedFinalAverage(Exam[] collated){
    int count=0;
    int totalscore=0;
    for(int cnt=0; cnt<collated.length;cnt++){
      if(collated[cnt].getExamType()=='F'){
        totalscore+=collated[cnt].getScore();
        count+=1;
      }
    }
    int finall=totalscore/count;
    return finall;
  }
  public static void displayExams(Exam[] exams){
    for(int cnt=0; cnt<exams.length;cnt++){
      System.out.println(exams[cnt]);
  }
  }
  public static void main(String[] args){
    Scanner dog = new Scanner(System.in);
    try{
    dog = new Scanner(new File("exams.txt"));
    }
    catch(FileNotFoundException e){
    }
    Exam[]lst=readAllExams(dog);
    displayExams(lst);
    Exam[]collated=collateExams(lst);
    System.out.println(getCollatedMidtermAverage(collated));
    System.out.println(getCollatedFinalAverage(collated));
  }
    
  }
  

