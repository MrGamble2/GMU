// CHANGELOG
// 
// Thu Feb 5 10:59:54 EST 2015: Added tests to ensure deep equality of
// Exam string fields.
// Thu Feb 5 20:30:15 EST 2015: Added a timeout to each test. A test that
// is still running after 1 second will be terminated and will be considered
// to fail.

/** Example of using unit tests for programming assignment 2.  This is
 * partially how your code will be graded.  Later in the class we will
 * write our own unit tests.  To run them on the command line, make
 * sure that the junit-cs211.jar is in the project directory.
 * 
 *  demo$ javac -cp .:junit-cs211.jar *.java     # compile everything
 *  demo$ java  -cp .:junit-cs211.jar P2Tests    # run tests
 * 
 * On windows replace : with ; (colon with semicolon)
 *  demo$ javac -cp .;junit-cs211.jar *.java     # compile everything
 *  demo$ java  -cp .;junit-cs211.jar P2Tests    # run tests
 */

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
  
public class P2Tests {
 public static void main(String args[]){
  org.junit.runner.JUnitCore.main("P2Tests");
 }
 Scanner s1 = new Scanner("Richard Carver 1 midterm 100"); 
 Exam e1 = new Exam("Richard","Carver",1,"midterm",100); 

 public static boolean checkMatchingExams(Exam expected, Exam e){
  if (!(e.getFirstName().equals(expected.getFirstName())) ||
    !(e.getLastName().equals(expected.getLastName())) ||
    !(e.getID() == expected.getID()) ||
    !(e.getExamType() == expected.getExamType()) ||
    !(e.getScore() == expected.getScore()))
   return false;
  else
   return true;
 }

 public static void assertExamsEqual(Exam e1, Exam e2){
  if (!checkMatchingExams(e1,e2)){
   throw new AssertionError("not identical:\n\t"+e1+"\n\t"+e2); 
  }
 }

 public static Exam[] exams1 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90),
           new Exam ("C", "D", 2, "midterm", 98), new Exam ("C", "D", 2, "final", 88),
           new Exam ("E", "F", 3, "midterm", 96), new Exam ("E", "F", 3, "final", 86)};

 Scanner s2 = new Scanner("6\n" + "A B 1 midterm 100\n" + "A B 1 final 90\n" +  "C D 2 midterm 98\n" 
   + "C D 2 final 88\n" + "E F 3 midterm 96\n" + "E F 3 final 86\n");

 public static boolean checkMatchingExamArrays(Exam[] exams1, Exam[] exams2){
  if (exams1.length != exams2.length) {
   return false;
  }
  for (int i=0; i<exams1.length; i++){
   if ( ! exams1[i].getFirstName().equals(exams2[i].getFirstName())
    ||! exams1[i].getLastName().equals(exams2[i].getLastName())
    ||  exams1[i].getID() != exams2[i].getID()
    ||  exams1[i].getExamType() != exams2[i].getExamType()
    ||  exams1[i].getScore() != exams2[i].getScore()) {
    return false;
       }
  }
  return true;
 }

 public static void assertExamArraysEqual(Exam[] exams1, Exam[] exams2){
  if (!checkMatchingExamArrays(exams1,exams2)){
   throw new AssertionError("not identical:\n\t"+exams1+"\n\t"+exams2); 
  }
 }

 public static Exam[] input1 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90)};
 public static Exam[] input2 = {new Exam ("A", "B", 1, "final", 90), new Exam ("A", "B", 1, "midterm", 100)};
 public static Exam[] collated1 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90)};

 public static Exam[] input3 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90),
   new Exam ("C", "D", 2, "final", 100), new Exam ("C", "D", 2, "midterm", 90)};
 public static Exam[] collated3 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90),
   new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100)};
 public static Exam[] input4 = {new Exam ("A", "B", 1, "final", 90), new Exam ("A", "B", 1, "midterm", 100),
   new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100)};
 public static Exam[] collated4 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90),
   new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100)};

 public static Exam[] input5 = {new Exam ("A", "B", 1, "midterm", 100), 
   new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100),
   new Exam ("A", "B", 1, "final", 90)};
 public static Exam[] collated5 = {new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90),
   new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100)};

 public static Exam[] input6 = {new Exam ("A", "B", 1, "final", 90), 
   new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100),
   new Exam ("A", "B", 1, "midterm", 100)};
 public static Exam[] collated6 = {new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100),
   new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90)};

 public static Exam[] input7 = {new Exam ("A", "B", 1, "final", 90), 
   new Exam ("C", "D", 2, "final", 100), new Exam ("C", "D", 2, "midterm", 90), 
   new Exam ("A", "B", 1, "midterm", 100)};
 public static Exam[] collated7 = {new Exam ("C", "D", 2, "midterm", 90), new Exam ("C", "D", 2, "final", 100),
   new Exam ("A", "B", 1, "midterm", 100), new Exam ("A", "B", 1, "final", 90)};

 @Test (timeout=1000) public void test_Exam(){assertExamsEqual(e1, new Exam("Richard","Carver",1,"midterm",100)); }
 @Test (timeout=1000) public void test_getFirstName(){assertEquals("Richard", (new Exam("Richard","Carver",1,"midterm",100)).getFirstName());}
 @Test (timeout=1000) public void test_getLastName(){assertEquals("Carver", (new Exam("Richard","Carver",1,"midterm",100)).getLastName());}
 @Test (timeout=1000) public void test_getID(){assertEquals(1, (new Exam("Richard","Carver",1,"midterm",100)).getID());}
 @Test (timeout=1000) public void test_getExamTypeM(){assertEquals('M', (new Exam("Richard","Carver",1,"midterm",100)).getExamType());}
 @Test (timeout=1000) public void test_getExamTypeF(){assertEquals('F', (new Exam("Richard","Carver",1,"final",100)).getExamType());}
 @Test (timeout=1000) public void test_getScore(){assertEquals(100, (new Exam("Richard","Carver",1,"final",100)).getScore());}
 @Test (timeout=1000) public void test_toString1(){assertEquals("Richard Carver 1 midterm 100", (new Exam("Richard","Carver",1,"midterm",100)).toString());}
 @Test (timeout=1000) public void test_toString2(){assertEquals("Richard Carver 1 final 100", (new Exam("Richard","Carver",1,"final",100)).toString());}
 @Test (timeout=1000) public void test_equals1(){assertTrue(new Exam("Richard","Carver",1,"final",100).equals(new Exam("Richard","Carver",1,"final",100)));}
 @Test (timeout=1000) public void test_equals2(){assertFalse(new Exam("Richard","Carver",1,"final",100).equals(new Exam("X","Carver",1,"final",100)));}
 @Test (timeout=1000) public void test_equals3(){assertFalse(new Exam("Richard","Carver",1,"final",100).equals(new Exam("Richard","X",1,"final",100)));}
 @Test (timeout=1000) public void test_equals4(){assertFalse(new Exam("Richard","Carver",1,"final",100).equals(new Exam("Richard","Carver",0,"final",100)));}
 @Test (timeout=1000) public void test_equals5(){assertFalse(new Exam("Richard","Carver",1,"final",100).equals(new Exam("Richard","Carver",1,"midterm",100)));}
 @Test (timeout=1000) public void test_equals6(){assertFalse(new Exam("Richard","Carver",1,"final",100).equals(new Exam("Richard","Carver",1,"final",0)));}
 
 @Test (timeout=1000) public void test_ReadExam(){ assertExamsEqual(e1, P2.readExam(s1));}
 @Test (timeout=1000) public void test_ReadAllExams(){ assertExamArraysEqual(exams1, P2.readAllExams(s2));}
 @Test (timeout=1000) public void test_MidtermAverage(){assertEquals(98.0, P2.getCollatedMidtermAverage(exams1),0.1);}
 @Test (timeout=1000) public void test_FinalAverage(){assertEquals(88.0, P2.getCollatedFinalAverage(exams1),0.1);}

 @Test (timeout=1000) public void test_collate1(){ assertExamArraysEqual(collated1, P2.collateExams(input1));}
@Test (timeout=1000) public void test_collate2(){ assertExamArraysEqual(collated1, P2.collateExams(input2));}
 @Test (timeout=1000) public void test_collate3(){ assertExamArraysEqual(collated3, P2.collateExams(input3));}
 @Test (timeout=1000) public void test_collate4(){ assertExamArraysEqual(collated4, P2.collateExams(input4));}
 @Test (timeout=1000) public void test_collate5(){ assertExamArraysEqual(collated5, P2.collateExams(input5));}
 @Test (timeout=1000) public void test_collate6(){ assertExamArraysEqual(collated6, P2.collateExams(input6));}
 @Test (timeout=1000) public void test_collate7(){ assertExamArraysEqual(collated7, P2.collateExams(input7));}

  // Ensure deep equality comparison of string fields is done in Exam.equals(Object o)
 @Test (timeout=1000) public void test_deep_equals1(){
   Exam x = new Exam(new String("Richard"),new String("Carver"),1,new String("final"),100);
   Exam y = new Exam(new String("Richard"),new String("Carver"),1,new String("final"),100);
   assertTrue(x.equals(y));
 }
 @Test (timeout=1000) public void test_deep_equals2(){
   Exam x = new Exam(new String("Donald"),new String("Knuth"),8,new String("midterm"),98);
   Exam y = new Exam(new String("Donald"),new String("Knuth"),8,new String("midterm"),98);
   assertTrue(x.equals(y));
 }
  

 /*
 //HONORS SECTION TESTS 
 
 // items used in the Honors Section test cases.
 Exam h1 = new Exam("A",new String[]{"B","C","D"},"E",1,"final",100);
 Exam h2 = new Exam("W",new String[]{"X","Y"},"Z",2,"midterm",90);
 Exam h3 = new Exam("A",new String[]{"B","C","D"},"E",1,"midterm",95);
 Exam h4 = new Exam("W",new String[]{"X","Y"},"Z",2,"final",93);
 Exam hd = new Exam("Daenerys",new String[]{"Stormborn","of","House","Targaryen",
                                            "Queen","of","the","Andals","and","the","First","Men",
                                            "Khaleesi","of","the","Great","Grass","Sea",
                                            "Breaker","of","Chains",
                                            "and","Mother","of"},
                    "Dragons",9,"final",110);
 Exam[] hs = {h1, h2, h3, h4};
 
 // basic content comparison of two String arrays.
 public static boolean equivalentStringArrays(String[] a, String[] b){
   if (a.length != b.length) { return false; }
   for (int i=0; i<a.length; i++){
     if ( ! a[i].equals(b[i])) { return false; }
   }
   return true;
 }
 
 //check two Exam objects are equal when defined as the Honors students must write them.
 public static boolean checkHonorExamsEqual(Exam a, Exam b){
  return (equivalentStringArrays(a.middleNames, b.middleNames)) && checkMatchingExams(a,b);
 }
 
 public static void assertHonorExamArraysEqual(Exam[] as, Exam[] bs){
   if (as.length != bs.length) {
     throw new RuntimeException("honor exam arrays weren't even the same length.");
   }
   for (int i=0; i<as.length; i++){
     if ( ! checkHonorExamsEqual(as[i],bs[i]) ) {
      throw new RuntimeException("mismatched exams: \n\t"+as[i]+"\n\t"+bs[i]); 
     }
   }
 }
 
 @Test (timeout=1000) public void testH_1(){ assertTrue(equivalentStringArrays(h1.middleNames, new String[]{"B","C","D"})); }
 @Test (timeout=1000) public void testH_2(){ assertTrue(equivalentStringArrays(h2.middleNames, new String[]{"X","Y"})); }
 @Test (timeout=1000) public void testH_3(){ assertExamsEqual(h1, P2.readExam(new Scanner("A B C D E 1 final 100\n"))); }
 @Test (timeout=1000) public void testH_4(){ assertFalse(checkHonorExamsEqual(h1, P2.readExam(new Scanner("A E 1 final 100\n")))); }
 @Test (timeout=1000) public void testH_5(){ assertFalse( null == (P2.readExam(new Scanner("A E 1 final 100\n")).middleNames));}
 @Test (timeout=1000) public void testH_6(){ assertExamsEqual(h4, P2.readExam(new Scanner("W X Y Z 2 final 93\n"))); }
 @Test (timeout=1000) public void testH_7(){
   String input = "4\nA B C D E 1 final 100\nW X Y Z 2 midterm 90\nA B C D E 1 midterm 95\nW X Y Z 2 final 93\n";
   assertHonorExamArraysEqual(hs,P2.readAllExams(new Scanner(input)));
 }
 @Test (timeout=1000) public void testH_8(){ assertEquals("A B C D E 1 final 100", new Exam("A",new String[]{"B","C","D"},"E",1,"final",100).toString()); }
 @Test (timeout=1000) public void testH_9(){ assertEquals("W X Y Z 2 midterm 90", new Exam("W",new String[]{"X","Y"},"Z",2,"midterm",90).toString()); }
 @Test (timeout=1000) public void testH_10(){ assertTrue (checkHonorExamsEqual(hd,P2.readExam(new Scanner("Daenerys Stormborn of House Targaryen Queen of the Andals and the First Men Khaleesi of the Great Grass Sea Breaker of Chains and Mother of Dragons 9 final 110")))); }
 
 @Test (timeout=1000) public void testH_11() { assertTrue (P2.examPresent(h1,hs)); }
 @Test (timeout=1000) public void testH_12() { assertFalse(P2.examPresent(hd,hs)); }
 // test on already-collated for before/after.
 @Test (timeout=1000) public void testH_13() { assertTrue (P2.verifyCollated(collated7, P2.collateExams(input7))); }
 // test a correctly collated example.
 @Test (timeout=1000) public void testH_14() { assertTrue (P2.verifyCollated(input7,    P2.collateExams(input7))); }
 // test an incorrectly collated example. Same exams with different midterm ordering are used.
 @Test (timeout=1000) public void testH_15() { assertFalse (P2.verifyCollated(input5,   P2.collateExams(input7))); }
 */
}
