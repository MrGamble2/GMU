// A concrete list-based MiniMap which is optimized for fast get(key)
// operations. The key type must be either Comparable or a Comparator
// must be provided when creating instances. The key list is kept in
// sorted order (via comparable/comparator). Binary search is used on
// the key list to locate the index of the (key,value) pair.
import java.util.*;
public class FastGetListMM<K,V> extends AbstractListMM<K,V>{

  // Comparator used to sort elements; may be null if elements are
  // Comparable
  public final Comparator<K> cmp;    

  // Assume elements must be comparable
  public FastGetListMM(){
    super();
    this.cmp=null;
  }

  // Use the given comparator to sort the keys
  public FastGetListMM(Comparator<K> cmp){
    //Object[]temp=this.keys.toArray(new Object[keys.size()]);
    this.cmp=cmp;
    Collections.sort(this.keys,cmp);
  }
  // Ensure that the FastGetListMM is set up properly to work with the
  // given key; either
  //
  // 1. key must be an instance of Comparable OR
  // 2. The comparator field cmp must not be null.
  //
  // If both are false, throw a RuntimeException.
  public void ensureComparable(K key){
    if(!(key instanceof Comparable)){
      if(cmp==null){
        throw new RuntimeException("Fail");
      }
    }
  }

  // Use binary search to locate where the given key is located.  If
  // not present, return a negative number.  Check to make sure either
  // a comparator was used to initialize this instance of
  // FastGetListMM or that the keys are Comparable. During binary
  // search, use the comparator if present and otherwise rely on the
  // keys being comparable.
  // 
  // TARGET COMPLEXITY: O(log N)
  // N: Number of key/value associations
  public int indexOf(K key){
    this.ensureComparable(key);
    int index = Collections.binarySearch(this.keys, key, cmp);
    return index;
  }

  // Locate the given key and replace its binding with the given
  // value. If not present, add the key in sorted order into the list
  // of keys and add the value at the same location in the list of
  // values.  Binary search should be used to quickly locate where the
  // key should be and replace an existing association.  If the key is
  // not present, list elements will need to be shifted so this method
  // will take longer.
  // 
  // TARGET COMPLEXITY:
  //   O(log N) if key is already present (use binary search)
  //   O(N)     otherwise as a key may need to be inserted and elements shifted
  // N: Number of key/value associations
  public V put(K key, V value){
    int loc=this.indexOf(key);
    if(loc<0){
      this.keys.add(key);
      Collections.sort(this.keys,cmp);
      loc=this.indexOf(key);
      this.vals.add(loc, value);
      
      return null;
    }
    else{
      V temp=this.vals.get(loc);
      this.vals.set(loc, value);
      return temp;
    }
  }
}