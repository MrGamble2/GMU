import java.util.*;
import java.io.*;
// A 2D treasure map which stores locations of treasures in an array
// of coordinates
public class TreasureMap{
  // Prompt the user for info on the treasure map and then create it
  // COMPLETE THIS METHOD
  public TreasureMap(){
    Scanner dog = new Scanner(System.in);
    this.rows = dog.nextInt();
    this.cols = dog.nextInt();
    int treasurenum = dog.nextInt();
    Coord coordArray[] = new Coord[treasurenum];
    for(int i = 0; dog.hasNext(); i++){
      Coord x = new Coord(dog.nextInt(), dog.nextInt());
      coordArray[i] = x;
    }
    this.treasureLocations = coordArray;
  }
//
//   Read the string representation of a map from a file
//   COMPLETE THIS METHOD
  public TreasureMap(String fileName) throws Exception{
    int count = 0; 
    Scanner xScan = new Scanner(new File(fileName));
    while(xScan.hasNext()){
      String line = xScan.next();
      for(int xs = 0; xs < line.length(); xs++){
        if (line.charAt(xs) == 'X')
          count++;        
      }
    }
    xScan.close();   
    int curtres= 0;
    int hg = 0;  
    Scanner rowscan = new Scanner(new File(fileName));
    Coord coordArray[] = new Coord[count];
    while(rowscan.hasNextLine()){
      String line = rowscan.nextLine();
      this.cols = line.length();
      for(int ys = 0; ys< line.length(); ys++){
        if (line.charAt(ys) == 'X'){
          Coord xyz = new Coord(hg,ys);
          coordArray[curtres] = xyz;
          curtres++;
        }
      }
      hg++;
    }
    this.rows = hg;
    this.treasureLocations = coordArray;
    rowscan.close();
  }
  
  int rows, cols;  // How big is the treasure map
  Coord [] treasureLocations; // The locations of treasures
  
  // true if there is treasure at the given (r,c) coordinates, false
  // otherwise
  // This method does not require modification
  public boolean treasureAt(int r, int c){
    for(int i=0; i<treasureLocations.length; i++){
      Coord coord = treasureLocations[i];
      if(coord.row == r && coord.col == c){
        return true;
      }
    }
    return false;
  }
  
  // Create a string representation of the treasure map
  // This method does not require modification
  public String toString(){
    String [][] map = new String[this.rows][this.cols];
    for(int i=0; i<rows; i++){
      for(int j=0; j<cols; j++){
        map[i][j] = ".";
      }
    }
    for(int i=0; i<treasureLocations.length; i++){
      Coord c = treasureLocations[i];
      map[c.row][c.col] = "X";
    }
    StringBuilder sb = new StringBuilder();
    for(int i=0; i<rows; i++){
      for(int j=0; j<cols; j++){
        sb.append(map[i][j]);
      }
      sb.append("\n");
    }
    return sb.toString();
  }
  
}
