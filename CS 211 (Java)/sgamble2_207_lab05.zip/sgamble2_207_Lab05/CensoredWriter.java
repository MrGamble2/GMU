import java.io.*;
public class CensoredWriter extends PrintWriter{
  private String c;
  public CensoredWriter(OutputStream o, String c){
    super(o);
    this.c=c;
  }
  public CensoredWriter(File f,String c) throws Exception{
    super(f);
    this.c=c;
  }
  public CensoredWriter(String s,String c)throws Exception{
    super(s);
    this.c=c;
  }
  public String transform(String s){
    String finall="";
    finall=s.replaceAll(this.c,"%!^*#@");
    return finall;
  }
  public void println(String s){
    super.println(transform(s));
    super.flush();
  }
  public void print(String s){
    super.print(transform(s));
    super.flush();
}
}