// An enumeration which models the four quadrants of the 2D Cartesian
// plane.  It has exactly four elements: Q1, Q2, Q3, Q4.  It is likely
// that giving each some fields will make the implementation easier.
// A private constructor is also useful.
import java.util.*;
import java.io.*;
public enum Quadrant{
  Q1("Q1"),Q2("Q2"),Q3("Q3"),Q4("Q4");
  private String Quad;
  private Quadrant (String Quad){    
    this.Quad = Quad;
  }
    
  // true if x-coordinates are positive in the quadrant, false otherwise
  public boolean xPositive(){
    if(this.Quad=="Q1"){
      return true;
    }
    if(this.Quad=="Q2"){
      return false;
    }
    if(this.Quad=="Q3"){
      return false;
    }
    if(this.Quad=="Q4"){
      return true;
    }
    else return true;
    }

  // true if y-coordinates are positive in the quadrant, false otherwise
  public boolean yPositive(){
     if(this.Quad=="Q1"){
       return true;
    }
    if(this.Quad=="Q2"){
      return true;
    }
    if(this.Quad=="Q3"){
      return false;
    }
    if(this.Quad=="Q4"){
      return false;
    }
    else return true;
  }

  // Return a String which represents the signs of the coordinates in
  // the Quadrant as
  //   (+,+) for Q1
  //   (-,+) for Q2
  //   (-,-) for Q3
  //   (+,-) for Q4
  public String signPair(){
    if(this.Quad=="Q1"){
      return "(+,+)";
    }
    if(this.Quad=="Q2"){
      return "(-,+)";
    }
    if(this.Quad=="Q3"){
      return "(-,-)";
    }
    if(this.Quad=="Q4"){
      return "(+,-)";
    }
    else return "X";
  }
  // Return the Quadrant that would result from flipping the sign (pos
  // to neg or neg to pos) of the x-coordinate in this Quadrant..
  public Quadrant flipX(){
    if(this.Quad=="Q1"){
      return Quadrant.Q2;
    
    }
    if(this.Quad=="Q2"){
      return Quadrant.Q1;
    }
    if(this.Quad=="Q3"){
      return Quadrant.Q4;
    }
    if(this.Quad=="Q4"){
      return Quadrant.Q3;
    }
    else return Quadrant.Q1;
  }
  // Given two integers, determine return the quadrant in which they
  // reside. If either x or y is 0, return one of the valid quadrants
  // it might be assigned to (this case is not tested).
  
  public static Quadrant fromInts(int x, int y){
    if(x>=0){
      if(y>0){
        return Quadrant.Q1;
      }
      else if(y<=0){
        return Quadrant.Q4;
      }
    }
    else{
      if(y>=0){
       return Quadrant.Q2;
      }
      else if(y<0){
        return Quadrant.Q3;
      }
      else{
        return Quadrant.Q1;
      }
    }
    return Quadrant.Q1;
  }
    
      
  // Accept an arbitrary number of command line arguments. Adjacent
  // pairs of arguments are treated as (x,y) coordinates.  Print the
  // quadrant in which the pair resides along with the signPair(). If
  // an odd number of arguments is given, ignore the last
  // argument. Any argument that cannot be converted to an integer
  // should raise an exception on encountering it.
  public static void main(String [] args){
    if(args.length>0){
      try{
        for(int i=0;i<args.length;i++){
          Integer.parseInt(args[i]);
        }
        for(int i=0;i<args.length-1;i+=2){
          String newline = System.getProperty("line.separator");
          int a=Integer.parseInt(args[i]);
          int b=Integer.parseInt(args[i+1]);
          Quadrant x=Quadrant.fromInts(a,b);
          String y=x.signPair();
          System.out.println(String.format("(%d,%d) has signs %s and is in ",a,b,y)+x);
        }
      }
      catch(NumberFormatException d){
        int a=1;
      }
    }
  }
}