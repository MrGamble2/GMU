public class Pair<X,Y>{
  private X first;
  private Y second;

  public Pair(X x, Y y){
    this.first = x;
    this.second = y;
  }

  public X getFirst(){
    return this.first;
  }
  public Y getSecond(){
    return this.second;
  }

  public boolean equals(Object o){
    if(!(o instanceof Pair)){
      return false;
    }
    Pair p = (Pair) o;
    return
      this.first.equals(p.first) &&
      this.second.equals(p.second);
  }

  public String toString(){
    return String.format("(%s,%s)",first,second);
  }

}
