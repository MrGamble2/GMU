public class Mode{
  public static <T> Pair<T,Integer> mode(T items[]){
    int freq;
    int count=0;
    T obj=null;
    if(items.length<1){
      throw new RuntimeException("Empty array has no mode");
    }
    for(T item: items){
      freq=0;
      for(T item1:items){
        if(item.equals(item1)){
          freq++;
        }
      }
      if(freq>count){
        count=freq;
        obj=item;
      }
    }
    Pair<T,Integer> xy= new Pair<T, Integer>(obj, count);
    return xy;
}
}


  