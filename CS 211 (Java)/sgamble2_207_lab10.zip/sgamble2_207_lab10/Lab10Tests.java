// Public tests for Lab10 Mode calculation using ArrayLists

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
import java.io.*;


public class Lab10Tests {
  /*Main method runs tests in this file*/ 
  public static void main(String args[])
  {
    org.junit.runner.JUnitCore.main("Lab10Tests");
  } 

  // Test that mode with empty input throws the appropriate exception
  @Test(timeout=2000) public void mode_empty1(){
    String msg;
    String expect = "Empty array has no mode";
    try{
      Mode.mode(new String[]{});
    }
    catch(RuntimeException e){
      String actual = e.getMessage();
      msg = String.format("\nRuntimeException has wrong message\nExpect: %s\nActual: %s\n",
                          expect,actual);
      assertEquals(msg,expect,actual);
      return;
    }
    msg = String.format("\nEmpty input should yield a RuntimException with message '%s'\n",
                        expect);
    fail(msg);
  }
  @Test(timeout=2000) public void mode_empty2(){
    String msg;
    String expect = "Empty array has no mode";
    try{
      Mode.mode(new Pair[]{});
    }
    catch(RuntimeException e){
      String actual = e.getMessage();
      msg = String.format("\nRuntimeException has wrong message\nExpect: %s\nActual: %s\n",
                          expect,actual);
      assertEquals(msg,expect,actual);
      return;
    }
    msg = String.format("\nEmpty input should yield a RuntimException with message '%s'\n",
                        expect);
    fail(msg);
  }


  // Helper method to test whether mode is behaving
  public <T> void test_mode(T input[], T expectItem, int expectCount){
    Pair<T,Integer> expect = new Pair<T,Integer>(expectItem,expectCount);
    T inputCopy[] = Arrays.copyOf(input,input.length);
    Pair<T,Integer> actual = Mode.mode(inputCopy);
    String msg =
      String.format("\nInput: %s\nExpect: %s\nActual: %s\n",
                    Arrays.toString(input),expect,actual);
    assertEquals(msg,expect,actual);

    boolean arrayChanged = !Arrays.deepEquals(input,inputCopy);
    if(arrayChanged){
      msg = String.format("\nInput array changed:\nExpect: %s\nActual: %s\n",
                          Arrays.toString(input),Arrays.toString(inputCopy));
      fail(msg);
    }
  }

  // Tests on integers
  @Test(timeout=2000) public void integer_mode_1(){
    test_mode(new Integer[]{30,10,10,20},
              10,2);
  }
  @Test(timeout=2000) public void integer_mode_2(){
    test_mode(new Integer[]{10,10,20,10,20,30,10,20,30,40,50,10,20,30,40,50,60},
              10,5);
  }
  @Test(timeout=2000) public void integer_mode_3(){
    test_mode(new Integer[]{20,50,10,20,50,30,10,30,50,20,60,10,50,20,30,50,50,40,60,30},
              50,6);
  }

  // Test specific cases of String inputs
  @Test(timeout=2000) public void string_mode_1(){
    test_mode(new String[]{"a","b","a"},
              "a",2);
  }
  @Test(timeout=2000) public void string_mode_2(){
    test_mode(new String[]{"a","b","a","b","c","b","b"},
              "b",4);
  }
  @Test(timeout=2000) public void string_mode_3(){
    test_mode(new String[]{"b","a","b","a","b","c","b"},
              "b",4);
  }
  @Test(timeout=2000) public void string_mode_4(){
    test_mode(new String[]{"c","hi","r","hi","hi","c","hi","r","b","hi","a"},
              "hi",5);
  }


  // Tests on Pairs
  @Test(timeout=2000) public void pair_mode_1(){
    test_mode(new Pair[]{new Pair<String,Integer>("Hi",1),
                         new Pair<String,Integer>("Bye",1),
                         new Pair<String,Integer>("Hi",1), },
      new Pair<String,Integer>("Hi",1),2);
  }
  @Test(timeout=2000) public void pair_mode_2(){
    test_mode(new Pair[]{new Pair<String,Integer>("Hi",1),
                         new Pair<String,Integer>("Bye",2),
                         new Pair<String,Integer>("Bye",1),
                         new Pair<String,Integer>("Hi",1),
                         new Pair<String,Integer>("Hi",0),
                         new Pair<String,Integer>("Bye",2),
                         new Pair<String,Integer>("Bye",1),
                         new Pair<String,Integer>("Bye",2),
                         new Pair<String,Integer>("Bye",1),
                         new Pair<String,Integer>("Bye",1),
                         new Pair<String,Integer>("Bye",2),},
      new Pair<String,Integer>("Bye",2),4);
  }
  @Test(timeout=2000) public void pair_mode_3(){
    test_mode(new Pair[]{new Pair<String,String>("CS 211","A"),
                         new Pair<String,String>("CS 112","C"),
                         new Pair<String,String>("CS 112","B"),
                         new Pair<String,String>("CS 211","B"),
                         new Pair<String,String>("CS 310","D"),
                         new Pair<String,String>("CS 310","A"),
                         new Pair<String,String>("CS 310","A"),
                         new Pair<String,String>("CS 211","F"),
                         new Pair<String,String>("CS 211","A"),
                         new Pair<String,String>("CS 310","B"),
                         new Pair<String,String>("CS 310","D"),
                         new Pair<String,String>("CS 211","A"),
                         new Pair<String,String>("CS 112","C"),
                         new Pair<String,String>("CS 211","A"),
                         new Pair<String,String>("CS 112","F"),
                         new Pair<String,String>("CS 112","B"),
                         new Pair<String,String>("CS 211","A"),
                         new Pair<String,String>("CS 112","B"), },
      new Pair<String,String>("CS 211","A"),5);
  }


}
