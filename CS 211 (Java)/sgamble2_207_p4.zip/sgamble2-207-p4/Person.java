import java.io.*;
//parent of the people classes, zoolander and follower, calls their do action, death, and returns what their status is
public abstract class Person extends Thing{
  protected Direction facing;
  protected Status status;
  public Person (Coord loc, String repr, Map map, PrintStream log){
    super(loc, repr,map, log);
    this.facing=Direction.N;
    this.status=Status.Escaping;
    //Via the parent constructor, initializes all fields. Persons always start facing North.
  }
  public abstract Coord chooseMove();
    //Child classes must provide their own implementation of how to choose the next move (what adjacent spot to go to next). 
    //This will be immediately used by this class's doAction method (see below).
  @Override public void doAction(){
    if(this.isEscaping()){
      Coord d=this.chooseMove();
      if(d.equals(this.getLoc())==false){
        this.setLoc(d);
    }
    }
    //Child classes will provide a way to choose where to move next via chooseMove(), so we can use 
    //that implementation to get the desired move, and then if it's adjacent to our current position 
    //and we are allowed to move to that part of the map, we will setLoc(..) to the new position.
  }
  public boolean isEscaping(){
    if(this.status.equals(Status.Escaping)){
      return true;
    }
    else return false;
  }
  public boolean isDead(){
    if(this.status.equals(Status.Dead)){
      return true;
    }
    else return false;
  }
  public boolean isSafe(){
    if(this.status.equals(Status.Safe)){
      return true;//Is this person's status Safe?
    }
    else return false;
  }
  public void die(){
    this.status=Status.Dead;
    //Change the status of the person to dead.
  }
  @Override public void setLoc(Coord newLoc){
    super.setLoc(newLoc);
    if(this.map.spotAt(newLoc)==Spot.Exit){
      this.status=Status.Safe;
      this.log.println(this.toString()+" "+"safe");
    }
  }
  @Override public boolean canLookThrough(){
    return true;  //People can look past other people.
  }
  @Override public boolean canPassThrough(){
    return true;
  }
}