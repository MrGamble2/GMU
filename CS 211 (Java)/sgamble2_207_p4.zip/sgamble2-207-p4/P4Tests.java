// CHANGELOG
// March 26, 6pm: 
//  - Fixed issues related to choosing correct character for Map's toString() definition.
//  - removed some Avoiders from a non-honors section test. (replaced with Zoolanders). 
//  - regenerated *.expect files to match these new outputs.

/** Example of using unit tests for programming assignment 4.  This is
  * partially how your code will be graded.  Later in the class we will
  * write our own unit tests.  To run them on the command line, make
  * sure that the junit-cs211.jar is in the project directory.
  * 
  *  demo$ javac -cp .:junit-cs211.jar *.java     # compile everything
  *  demo$ java  -cp .:junit-cs211.jar P4Tests    # run tests
  * 
  * On windows replace : with ; (colon with semicolon)
  *  demo$ javac -cp .;junit-cs211.jar *.java     # compile everything
  *  demo$ java  -cp .;junit-cs211.jar P4Tests    # run tests
  */

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
import java.io.*;

public class P4Tests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("P4Tests");
  }
  
  /////////////////////////////////////////////////////////
  
  // interface tests - make our own implementation, and as
  // long as they compile the tests are successful.
  Passable truePassable  = new Passable(){@Override public boolean canLookThrough(){return true; } @Override public boolean canPassThrough(){return true; }};
  Passable falsePassable = new Passable(){@Override public boolean canLookThrough(){return false;} @Override public boolean canPassThrough(){return false;}};
  Representable reprObj   = new Representable(){@Override public String repr(){return "test";}};
  @Test (timeout=2000) public void repr1(){assertEquals("test",reprObj.repr()); }
  @Test (timeout=2000) public void pass1(){assertEquals(true,  truePassable.canLookThrough()); }
  @Test (timeout=2000) public void pass2(){assertEquals(true,  truePassable.canPassThrough()); }
  @Test (timeout=2000) public void pass3(){assertEquals(false, falsePassable.canLookThrough()); }
  @Test (timeout=2000) public void pass4(){assertEquals(false, falsePassable.canPassThrough()); }
  /////////////////////////////////////////////////////////
  
  // enumeration tests
  
  @Test (timeout=2000) public void enum_status(){ 
    // check all values are present.
    assertEquals(Status.Escaping, Status.Escaping);
    assertEquals(Status.Dead, Status.Dead);
    assertEquals(Status.Safe, Status.Safe);
  }
  
  @Test (timeout=2000) public void enum_dir1() {
    // check all values are present.
    assertEquals(Direction.N, Direction.N);
    assertEquals(Direction.E, Direction.E);
    assertEquals(Direction.S, Direction.S);
    assertEquals(Direction.W, Direction.W);
    assertEquals(Direction.none, Direction.none);
  }
  @Test (timeout=2000) public void enum_dir2() {
    // check all cycles. Implicitly assures no wrong value is returned.
    assertEquals(Direction.N, Direction.W.cycle());
    assertEquals(Direction.E, Direction.N.cycle());
    assertEquals(Direction.S, Direction.E.cycle());
    assertEquals(Direction.W, Direction.S.cycle());
    assertEquals(Direction.none, Direction.none.cycle());
  }
  
  
  @Test (timeout=2000) public void enum_dir3() {
    // request the opposite directions.
    assertEquals(Direction.N,Direction.S.getOpposite());
    assertEquals(Direction.E,Direction.W.getOpposite());
    assertEquals(Direction.S,Direction.N.getOpposite());
    assertEquals(Direction.W,Direction.E.getOpposite());
    assertEquals(Direction.none,Direction.none.getOpposite());
  }
  
  @Test (timeout=2000) public void enum_dir4() {
    // inspect all expected opposites.
    assertTrue(Direction.N.isOpposite(Direction.S));
    assertTrue(Direction.E.isOpposite(Direction.W));
    assertTrue(Direction.S.isOpposite(Direction.N));
    assertTrue(Direction.W.isOpposite(Direction.E));
    assertTrue(Direction.none.isOpposite(Direction.none));
  }
  
  @Test (timeout=2000) public void enum_dir5() {
    // all expected non-opposites
    assertFalse(Direction.N.isOpposite(Direction.E));
    assertFalse(Direction.N.isOpposite(Direction.W));
    assertFalse(Direction.N.isOpposite(Direction.N));
    assertFalse(Direction.N.isOpposite(Direction.none));
    
    assertFalse(Direction.S.isOpposite(Direction.E));
    assertFalse(Direction.S.isOpposite(Direction.S));
    assertFalse(Direction.S.isOpposite(Direction.W));
    assertFalse(Direction.S.isOpposite(Direction.none));
    
    assertFalse(Direction.E.isOpposite(Direction.N));
    assertFalse(Direction.E.isOpposite(Direction.E));
    assertFalse(Direction.E.isOpposite(Direction.S));
    assertFalse(Direction.E.isOpposite(Direction.none));
    
    assertFalse(Direction.W.isOpposite(Direction.N));
    assertFalse(Direction.W.isOpposite(Direction.W));
    assertFalse(Direction.W.isOpposite(Direction.S));
    assertFalse(Direction.W.isOpposite(Direction.none));
    
    assertFalse(Direction.none.isOpposite(Direction.N));
    assertFalse(Direction.none.isOpposite(Direction.E));
    assertFalse(Direction.none.isOpposite(Direction.S));
    assertFalse(Direction.none.isOpposite(Direction.W));
  }
  
  @Test (timeout=2000) public void enum_spot1() {
    // check all values are present.
    assertEquals(Spot.Open, Spot.Open);
    assertEquals(Spot.Wall, Spot.Wall);
    assertEquals(Spot.Exit, Spot.Exit);
    assertEquals(Spot.SignN, Spot.SignN);
    assertEquals(Spot.SignE, Spot.SignE);
    assertEquals(Spot.SignS, Spot.SignS);
    assertEquals(Spot.SignW, Spot.SignW);
  }
  @Test (timeout=2000) public void enum_spot2() {
    // check repr field.
    assertEquals(".", Spot.Open.repr);
    assertEquals("e", Spot.Exit.repr);
    assertEquals("|", Spot.Wall.repr);
    assertEquals("^", Spot.SignN.repr);
    assertEquals(">", Spot.SignE.repr);
    assertEquals("v", Spot.SignS.repr);
    assertEquals("<", Spot.SignW.repr);
  }
  
  @Test (timeout=2000) public void enum_spot3() {
    // check repr method.
    assertEquals(".", Spot.Open.repr());
    assertEquals("e", Spot.Exit.repr());
    assertEquals("|", Spot.Wall.repr());
    assertEquals("^", Spot.SignN.repr());
    assertEquals(">", Spot.SignE.repr());
    assertEquals("v", Spot.SignS.repr());
    assertEquals("<", Spot.SignW.repr());
  }
  
  @Test (timeout=2000) public void enum_spot4() {
    // check toString.
    assertEquals(".", Spot.Open.toString());
    assertEquals("e", Spot.Exit.toString());
    assertEquals("|", Spot.Wall.toString());
    assertEquals("^", Spot.SignN.toString());
    assertEquals(">", Spot.SignE.toString());
    assertEquals("v", Spot.SignS.toString());
    assertEquals("<", Spot.SignW.toString());
  }
  
  @Test (timeout=2000) public void enum_spot5() {
    // check all isSign() results.
    assertTrue(Spot.SignN.isSign());
    assertTrue(Spot.SignE.isSign());
    assertTrue(Spot.SignS.isSign());
    assertTrue(Spot.SignW.isSign());
    assertFalse(Spot.Open.isSign());
    assertFalse(Spot.Wall.isSign());
    assertFalse(Spot.Exit.isSign());
  }
  
  @Test (timeout=2000) public void enum_spot6() {
    // canLookThrough results
    assertEquals(true,Spot.SignN.canLookThrough());
    assertEquals(true,Spot.SignE.canLookThrough());
    assertEquals(true,Spot.SignS.canLookThrough());
    assertEquals(true,Spot.SignW.canLookThrough());
    assertEquals(true,Spot.Open.canLookThrough());
    assertEquals(true,Spot.Exit.canLookThrough());
    assertEquals(false,Spot.Wall.canLookThrough());
  } 
  
  @Test (timeout=2000) public void enum_spot7() {
    // canPassThrough results
    assertEquals(true,Spot.SignN.canPassThrough());
    assertEquals(true,Spot.SignE.canPassThrough());
    assertEquals(true,Spot.SignS.canPassThrough());
    assertEquals(true,Spot.SignW.canPassThrough());
    assertEquals(true,Spot.Open.canPassThrough());
    assertEquals(true,Spot.Exit.canPassThrough());
    assertEquals(false,Spot.Wall.canPassThrough());
  } 
  /////////////////////////////////////////////////////////
  
  // Coord class
  @Test (timeout=2000) public void coord1() { assertEquals(3, new Coord(3,4).r); }
  @Test (timeout=2000) public void coord2() { assertEquals(4, new Coord(3,4).c); }
  
  Coord c = new Coord (5,10);
  
  // check each step direction.
  @Test (timeout=2000) public void coord3() {
    assertEquals( 4, c.step(Direction.N).r);
    assertEquals(10, c.step(Direction.N).c);
  }
  @Test (timeout=2000) public void coord4() {
    assertEquals( 5, c.step(Direction.E).r);
    assertEquals(11, c.step(Direction.E).c);
  }
  @Test (timeout=2000) public void coord5() {
    assertEquals( 6, c.step(Direction.S).r);
    assertEquals(10, c.step(Direction.S).c);
  }
  @Test (timeout=2000) public void coord6() {
    assertEquals( 5, c.step(Direction.W).r);
    assertEquals( 9, c.step(Direction.W).c);
  }
  
  @Test (timeout=2000) public void coord7() {
    // check all manner of copying:
    // same fields
    assertEquals(c.r, c.copy().r);
    assertEquals(c.c, c.copy().c);
    // not an alias
    assertFalse(c==c.copy());
  }  
  
  @Test (timeout=2000) public void coord8() {
    // equals()
    assertEquals(c, c.copy());
    assertEquals(c, c);
    assertFalse(c.equals(new Coord (2,3))); // @(5,10) != @(2,3).
    assertFalse(c.equals("hello")); // must work for non-Coords.
  }
  
  @Test (timeout=2000) public void coord9() {
    // we are adjacent in cardinal directions.
    assertTrue(c.adjacent(new Coord(4,10)));
    assertTrue(c.adjacent(new Coord(6,10)));
    assertTrue(c.adjacent(new Coord(5,11)));
    assertTrue(c.adjacent(new Coord(5, 9)));    
  }  
  @Test (timeout=2000) public void coord() {
    // we are not adjacent diagonally.
    assertFalse(c.adjacent(new Coord(4, 9)));
    assertFalse(c.adjacent(new Coord(6, 9)));
    assertFalse(c.adjacent(new Coord(4,11)));
    assertFalse(c.adjacent(new Coord(6,11)));
  }
  @Test (timeout=2000) public void coord10(){
    // we are not adjacent to ones further away.
    assertFalse(c.adjacent(new Coord(3,10)));
    assertFalse(c.adjacent(new Coord(7,10)));
    assertFalse(c.adjacent(new Coord(5, 8)));
    assertFalse(c.adjacent(new Coord(5,12)));
    
    assertFalse(c.adjacent(new Coord(30,50)));
    assertFalse(c.adjacent(new Coord( 0, 0)));
    assertFalse(c.adjacent(new Coord(10,10)));
    assertFalse(c.adjacent(new Coord( 5, 5)));
  }
  
  /////////////////////////////////////////////////////////
  
  // Map test helpers.
  
  // we should have had equals methods for all the classes....
  // we'll involve all the definitions here, in a brittle fashion:
  // if we added any further classes, we'd have to update this.
  // overriding equals() would be far better.
  
  public static void assertEqThings(Thing[] t1, Thing[] t2){
    if (t1.length != t2.length){ fail("uneven Thing[] lengths: expected "+t1.length+", found +"+t2.length);}
    for (int i=0; i<t1.length; i++){ assertEqThing(t1[i], t2[i]); }
  }
  
  public static void assertEqThing(Thing t1, Thing t2){
    if (! t1.getClass().equals(t2.getClass())) {
      fail("different types: expected "+t1.getClass()+", found "+t2.getClass()+".");
    }
    
    // all Things share these five parts; if they don't match, answer false.
    if ( ! t1.getLoc().equals(t2.getLoc()) ) { fail("different locations: expected "+t1.getLoc()+", found "+t2.getLoc()+"."); }
    if ( ! t1.getPrevLoc().equals(t2.getPrevLoc())){ fail("different prevlocations: expected "+t1.getPrevLoc()+", found "+t2.getPrevLoc()+"."); }
    if ( ! t1.repr().equals(t2.repr())) { fail("different reprs: expected "+t1.repr()+", found "+t2.repr()+"."); }      
    if ( ! t1.map.equals(t2.map)) { fail("different maps: expected "+t1.map+", found "+t2.map+"."); } // should be aliases
    if ( ! t1.log.equals(t2.log)) { fail("different logs: expected "+t1.log+", found "+t2.log+"."); } // should be aliases
    
    // Person details
    if (t1 instanceof Person && t2 instanceof Person ) { // both are Persons
      Person p1 = (Person) t1;
      Person p2 = (Person) t2;
      if ( ! (p1.facing.equals(p2.facing))) { fail("different facings: expected " +p1.facing+", found "+p2.facing+"."); }
      if ( ! (p1.status.equals(p2.status))) { fail("different statuses: expected "+p1.status+", found "+p2.status+"."); }
    }
    
    // Threat details
    if (t1 instanceof Threat && t2 instanceof Threat) { // both are Threats
      Threat th1 = (Threat)t1;
      Threat th2 = (Threat)t2;
      if ( th1.charge!=th2.charge)       {fail("different charge: expected "+th1.charge+", found "+th2.charge+"."); }
      if (th1.fullCharge!=th2.fullCharge){fail("different fullCharge: expected "+th1.fullCharge+", found "+th2.fullCharge+"."); }
    }
    
    // Followers, Avoiders, Zoolanders, GreenSlimes, and Hazes don't have to add
    // any further instance variables. If they've passed all above tests, they 
    // should be considered equal.
    return;
  }
  
  public static final String inFileName  = "TEST_FILES/ephemeral_testing_file.txt";
  public final static String outFileName = "TEST_FILES/ephemeral_testing_output_file.txt";
  
  public static Map stringToMap(String s) {
    
    try {
      // write the string to the file.
      File f = new File(inFileName);
      PrintWriter pw = new PrintWriter(f); 
      pw.print(s);
      pw.close();
      
      // create the Map.
      Map m = new Map(inFileName, new PrintStream(new File(outFileName)));
      
      // delete the file.
      f.delete();
      
      return m;
    }
    // convert a checked exception (IOException+) to unchecked exception.
    catch (IOException e){
      throw new RuntimeException("issues with stringToMap. " +e); 
    }
  }
  
  
  public static void assertThingsMatch(Thing[] ts1, Thing[] ts2) {
    if (ts1.length != ts2.length) { throw new RuntimeException("mismatched lengths: expected "+ts1.length+", found "+ts2.length); }
    for (int i=0; i<ts1.length;i++){
      assertEqThing(ts1[i], ts2[i]);
    }
  }
  
  public static void assertFloorplansMatch(Spot[][] f1, Spot[][] f2){
    if (f1.length != f2.length) { throw new RuntimeException("mismatched lengths: expected "+f1.length+", found "+f2.length); }
    for (int i=0; i<f1.length; i++){
      if (f1[i].length!=f2[i].length){
        throw new RuntimeException("mismatched inner lengths, row "+i+": expected "+f1.length+", found "+f2.length);
      }
      assertTrue(Arrays.equals(f1[i], f2[i]));
    }
  }
  
  //  hmmm... only one way to make maps, so this can't really be used...
  public static void assertMapsMatch(Map expected, Map found){
    assertThingsMatch(expected.things, found.things);
    assertFloorplansMatch(expected.floorplan, found.floorplan);
    assertEquals(expected.log, found.log);
  }
  
  
  
  
  
  /////////////////////////////////////////////////////////
  
  //check the floorplan.
  @Test (timeout=2000) public void map_floorplan1(){
    String s = "|||\n|z|\n|e|\n";
    Map m = stringToMap(s);
    Spot[][] expected = {
      {Spot.Wall,Spot.Wall,Spot.Wall},
      {Spot.Wall,Spot.Open,Spot.Wall},
      {Spot.Wall,Spot.Exit,Spot.Wall}
    };
    assertFloorplansMatch(expected, m.floorplan);
  }
  
  // include every kind of spot, in two different rows (avoid wrong row/col orderings).
  @Test (timeout=2000) public void map_floorplan2(){
    String s = "|.e|\n<>^v\n";
    Map m = stringToMap(s);
    Spot[][] expected = {
      {Spot.Wall,Spot.Open,Spot.Exit,Spot.Wall},
      {Spot.SignW,Spot.SignE,Spot.SignN,Spot.SignS}
    };
    assertFloorplansMatch(expected, m.floorplan); // slightly better error messages than just Arrays.deepEquals().
  }
  
  @Test (timeout=2000) public void map_things(){
    String s = "ffz\nzzf\n";
    Map m = stringToMap(s);
    Thing[] expected = {
      new Follower  (new Coord(0,0),m,m.log),
      new Follower  (new Coord(0,1),m,m.log), 
      new Zoolander (new Coord(0,2),m,m.log), 
      new Zoolander (new Coord(1,0),m,m.log), 
      new Zoolander (new Coord(1,1),m,m.log), 
      new Follower  (new Coord(1,2),m,m.log), 
    };
    assertThingsMatch(expected, m.things);
  }
  
  @Test (timeout=2000) public void map_onMap1(){
    Map m = stringToMap("|||\n...\n"); // 2x3
    assertTrue(m.onMap(new Coord(0,0)));
    assertTrue(m.onMap(new Coord(0,1)));
    assertTrue(m.onMap(new Coord(0,2)));
    assertTrue(m.onMap(new Coord(1,0)));
    assertTrue(m.onMap(new Coord(1,1)));
    assertTrue(m.onMap(new Coord(1,2)));
  }
  
  @Test (timeout=2000) public void map_onMap2(){
    Map m = stringToMap("|||\n...\n"); // 2x3
    assertFalse(m.onMap(new Coord(-1,-1)));
    assertFalse(m.onMap(new Coord(0,4)));
    assertFalse(m.onMap(new Coord(4,0)));
    assertFalse(m.onMap(new Coord(10,10)));
    assertFalse(m.onMap(new Coord(-1,0)));
    assertFalse(m.onMap(new Coord(0,-1)));
    assertFalse(m.onMap(new Coord(2,3)));
    assertFalse(m.onMap(new Coord(3,2)));
    assertFalse(m.onMap(new Coord(Integer.MAX_VALUE,Integer.MIN_VALUE)));
  }
  
  
  // slightly larger grid
  @Test (timeout=2000) public void map_onMap3(){
    Map m = stringToMap("..........\n..........\n..........\n..........\n"); // 4x10
    assertTrue(m.onMap(new Coord(3,7)));
    assertTrue(m.onMap(new Coord(2,1)));
    assertTrue(m.onMap(new Coord(1,5)));
    assertTrue(m.onMap(new Coord(0,0)));
    assertTrue(m.onMap(new Coord(3,9)));
    
    assertFalse(m.onMap(new Coord(4,10)));
    assertFalse(m.onMap(new Coord(0,40)));
    assertFalse(m.onMap(new Coord(40,0)));
    assertFalse(m.onMap(new Coord(100,100)));
  }
  
  @Test (timeout=2000) public void map_spotAt1(){
    Map m = stringToMap("|.e<>v^\n");
    assertEquals(Spot.Wall, m.spotAt(new Coord(0,0)));
    assertEquals(Spot.Open, m.spotAt(new Coord(0,1)));
    assertEquals(Spot.Exit, m.spotAt(new Coord(0,2)));
    assertEquals(Spot.SignW,m.spotAt(new Coord(0,3)));
    assertEquals(Spot.SignE,m.spotAt(new Coord(0,4)));
    assertEquals(Spot.SignS,m.spotAt(new Coord(0,5)));
    assertEquals(Spot.SignN,m.spotAt(new Coord(0,6)));
  }
  
  // off-map locations must return null.
  @Test (timeout=2000) public void map_spotAt2(){
    Map m = stringToMap("|.e.\n<>v^\n"); // 2x4
    assertNull(m.spotAt(new Coord( 2, 4)));
    assertNull(m.spotAt(new Coord(10,10)));
    assertNull(m.spotAt(new Coord(-1,-1))); 
  }
  
  @Test (timeout=2000) public void map_peopleRemaining1(){
    Map m = stringToMap("zzz\n.|e\n"); // 2x4
    assertEquals(3,m.peopleRemaining());
  }
  
  @Test (timeout=2000) public void map_peopleRemaining2(){
    Map m = stringToMap("zzz\n.|e\n"); // 2x4
    assertEquals(3,m.peopleRemaining());
    ((Person)m.things[0]).status = Status.Safe;
    assertEquals(2,m.peopleRemaining());
    ((Person)m.things[1]).status = Status.Safe;
    assertEquals(1,m.peopleRemaining());
    ((Person)m.things[2]).status = Status.Safe;
    assertEquals(0,m.peopleRemaining());
  }
  
  @Test (timeout=2000) public void map_peopleRemaining3(){
    Map m = stringToMap("f.f\n.f.\n"); // 2x4
    assertEquals(3,m.peopleRemaining());
    ((Follower)m.things[0]).status = Status.Safe;
    assertEquals(2,m.peopleRemaining());
    ((Person)m.things[1]).status = Status.Safe;
    assertEquals(1,m.peopleRemaining());
    ((Person)m.things[2]).status = Status.Safe;
    assertEquals(0,m.peopleRemaining());
  }
  
  @Test (timeout=2000) public void map_peopleRemaining4(){
    Map m = stringToMap("f.f\n.f.\n"); // 2x4
    assertEquals(3,m.peopleRemaining());
    ((Follower)m.things[0]).status = Status.Safe;
    assertEquals(2,m.peopleRemaining());
    ((Person)m.things[1]).status = Status.Dead;
    assertEquals(1,m.peopleRemaining());
    ((Person)m.things[2]).status = Status.Escaping; // still present...
    assertEquals(1,m.peopleRemaining());
  }
  
  @Test (timeout=2000) public void map_addThing1(){
    Map m = stringToMap(".....\n.....\n.....\n");
    assertThingsMatch(m.things, new Thing[]{});
    
    Zoolander z1 = new Zoolander(new Coord(0,0),m, m.log);
    Zoolander z2 = new Zoolander(new Coord(1,2),m, m.log);
    Zoolander z3 = new Zoolander(new Coord(2,1),m, m.log);
    Zoolander z4 = new Zoolander(new Coord(1,3),m, m.log);
    Zoolander z5 = new Zoolander(new Coord(2,0),m, m.log);
    
    Follower f1 = new Follower  (new Coord(1,2),m, m.log);
    Follower f2 = new Follower  (new Coord(1,0),m, m.log);
    Follower f3 = new Follower  (new Coord(0,2),m, m.log);
    Follower f4 = new Follower  (new Coord(2,4),m, m.log);
    
    m.addThing(z1);
    assertThingsMatch(m.things, new Thing[]{z1});
    
    m.addThing(z2);
    assertThingsMatch(m.things, new Thing[]{z1,z2});
    
    m.addThing(f1);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1});
    m.addThing(z3);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1,z3});
    
    
    m.addThing(f2);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1,z3,f2});
    m.addThing(z4);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1,z3,f2,z4});
    m.addThing(z5);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1,z3,f2,z4,z5});
  }
  
  @Test (timeout=2000) public void map_addThing2(){
    Map m = stringToMap(".....\n.....\n.....\n");
    assertThingsMatch(m.things, new Thing[]{});
    
    GreenSlime g1 = new GreenSlime(new Coord(2,3),m, m.log);
    GreenSlime g2 = new GreenSlime(new Coord(2,3),m, m.log);
    Haze       h1 = new Haze      (new Coord(2,3),m, m.log);
    Haze       h2 = new Haze      (new Coord(2,3),m, m.log);
    
    Zoolander z1 = new Zoolander(new Coord(0,0),m, m.log);
    Zoolander z2 = new Zoolander(new Coord(1,2),m, m.log);
    Zoolander z3 = new Zoolander(new Coord(2,1),m, m.log);
    Zoolander z4 = new Zoolander(new Coord(1,3),m, m.log);
    Zoolander z5 = new Zoolander(new Coord(2,0),m, m.log);
    
    Follower f1 = new Follower  (new Coord(1,2),m, m.log);
    Follower f2 = new Follower  (new Coord(1,0),m, m.log);
    Follower f3 = new Follower  (new Coord(0,2),m, m.log);
    Follower f4 = new Follower  (new Coord(2,4),m, m.log);
    
    m.addThing(g1);
    m.addThing(g2);
    m.addThing(h1);
    m.addThing(h2);
    m.addThing(z1);
    m.addThing(z2);
    m.addThing(z3);
    m.addThing(z4);
    m.addThing(z5);
    m.addThing(f1);
    m.addThing(f2);
    m.addThing(f3);
    m.addThing(f4);
    assertThingsMatch(m.things, new Thing[]{g1,g2,h1,h2,z1,z2,z3,z4,z5,f1,f2,f3,f4});
  }
  
  @Test (timeout=2000) public void map_addThing3(){
    Map m = stringToMap(".....\n.....\n.....\n");
    Zoolander z1 = new Zoolander(new Coord(1,2),m, m.log);
    Zoolander z2 = new Zoolander(new Coord(1,2),m, m.log);
    Follower  f1 = new Follower (new Coord(1,2),m, m.log);
    Follower  f2 = new Follower (new Coord(1,2),m, m.log);
    Follower  f3 = new Follower (new Coord(1,2),m, m.log);
    
    m.addThing(z1);
    assertThingsMatch(m.things, new Thing[]{z1});
    m.addThing(z2);
    assertThingsMatch(m.things, new Thing[]{z1,z2});
    m.addThing(f1);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1});
    m.addThing(f2);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1,f2});
    m.addThing(f3);
    assertThingsMatch(m.things, new Thing[]{z1,z2,f1,f2,f3});
  }
  
  @Test (timeout=2000) public void map_thingsAt1(){
    Map m = stringToMap(".....\n...f.\n..z..\n");
    Follower  f = new Follower (new Coord(1,3), m, m.log);
    Zoolander z = new Zoolander(new Coord(2,2), m, m.log);
    
    assertThingsMatch(m.thingsAt(new Coord(1,3)), new Thing[]{f});
    assertThingsMatch(m.thingsAt(new Coord(2,2)), new Thing[]{z});
  }
  
  // empty spots on the map return an empty array, not null.
  @Test (timeout=2000) public void map_thingsAt2(){
    Map m = stringToMap(".....\n.....\n.....\n");
    assertThingsMatch(m.thingsAt(new Coord(1,1)), new Thing[]{});
  }
  
  // spots not on the map return an empty array, not null.
  @Test (timeout=2000) public void map_thingsAt3(){
    Map m = stringToMap(".....\n.....\n.....\n");
    assertThingsMatch(m.thingsAt(new Coord(10,10)), new Thing[]{});
  }
  
  // we might add more things to a spot somehow and we must find them all together.
  // this is hard to orchestrate in a live map, but is easy in a test case.
  @Test (timeout=2000) public void map_thingsAt4(){
    Map m = stringToMap(".....\n..z..\n.....\n");
    Coord c12 = new Coord (1,2);
    Thing[] adds = { // z z z f f f
      new Zoolander(c12,m, m.log), 
      new Zoolander(c12,m, m.log), 
      new Zoolander(c12,m, m.log),
      new Follower (c12,m, m.log),
      new Follower (c12,m, m.log),
      new Follower (c12,m, m.log)
    };
    
    // add them all except the first one, which was on the map.
    for (int i=1;i<adds.length;i++){ m.addThing(adds[i]); }
    
    // check that all five of them showed up at the correct location (in order, too)
    assertThingsMatch(m.thingsAt(new Coord(1,2)), adds);
  }
  
  // check with no things on the map.
  @Test (timeout=2000) public void map_through1(){
    Map m = stringToMap(".e><^v|\n");
    assertTrue (m.canLookThroughLocation(new Coord(0,0)));
    assertTrue (m.canLookThroughLocation(new Coord(0,1)));
    assertTrue (m.canLookThroughLocation(new Coord(0,2)));
    assertTrue (m.canLookThroughLocation(new Coord(0,3)));
    assertTrue (m.canLookThroughLocation(new Coord(0,4)));
    assertTrue (m.canLookThroughLocation(new Coord(0,5)));
    assertFalse(m.canLookThroughLocation(new Coord(0,6))); // wall
  }
  
  // check with no things on the map.
  @Test (timeout=2000) public void map_through2(){
    Map m = stringToMap(".e><^v|\n");
    assertTrue (m.canPassThroughLocation(new Coord(0,0)));
    assertTrue (m.canPassThroughLocation(new Coord(0,1)));
    assertTrue (m.canPassThroughLocation(new Coord(0,2)));
    assertTrue (m.canPassThroughLocation(new Coord(0,3)));
    assertTrue (m.canPassThroughLocation(new Coord(0,4)));
    assertTrue (m.canPassThroughLocation(new Coord(0,5)));
    assertFalse(m.canPassThroughLocation(new Coord(0,6))); // wall
  }
  
  // check with one of each kind of thing on a spot.
  // we can see through all the locations except haze.
  @Test (timeout=2000) public void map_through3(){
    Map m = stringToMap("fzg~\n");
    assertTrue (m.canLookThroughLocation(new Coord(0,0)));
    assertTrue (m.canLookThroughLocation(new Coord(0,1)));
    assertTrue (m.canLookThroughLocation(new Coord(0,2)));
    assertFalse(m.canLookThroughLocation(new Coord(0,3))); // haze
  }
  
  // check with one of each kind of thing on a spot.
  // we can pass through all the locations.
  @Test (timeout=2000) public void map_through4(){
    Map m = stringToMap("fzg~\n");
    assertTrue(m.canPassThroughLocation(new Coord(0,0)));
    assertTrue(m.canPassThroughLocation(new Coord(0,1)));
    assertTrue(m.canPassThroughLocation(new Coord(0,2)));
    assertTrue(m.canPassThroughLocation(new Coord(0,3)));
  }
  
  // a spot with a person and haze can't be seen through.
  @Test (timeout=2000) public void map_through5(){
    Map m = stringToMap("|||\n"
                          +"|f|\n"
                          +"|||\n");
    m.addThing(new Haze(new Coord(1,1),m, m.log));
    assertFalse(m.canLookThroughLocation(new Coord(1,1)));
    m = stringToMap("|||\n"
                      +"|z|\n"
                      +"|||\n");
    m.addThing(new Haze(new Coord(1,1),m, m.log));
    assertFalse(m.canLookThroughLocation(new Coord(1,1)));
  }
  
  String mapStr1 = "....\neeee\n||||\n<>v^\n";
  String mapStr2 = "||||\negf|\n||||\n|z.e\n";
  
  @Test (timeout=2000) public void map_toString1() { assertEquals(mapStr1, stringToMap(mapStr1).toString()); }
  @Test (timeout=2000) public void map_toString2() { assertEquals(mapStr2, stringToMap(mapStr2).toString()); }
  
  String mapStr3 =
    "|e|\n"
    +"|.|\n"
    +"|.|\n"
    +"|z|\n"
    +"|||\n";
  @Test (timeout=2000) public  void map_iterate1(){
    Map m = stringToMap(mapStr3);
    m.iterate();
    
    // simulate the correct movement.
    Zoolander z  = new Zoolander(new Coord(3,1),m, m.log);
    z.setLoc(new Coord(2,1));
    
    // check actual vs. expected movement.
    assertEqThing( m.thingsAt(new Coord(2,1))[0], z);
  }
  
  String mapStr4 =
    "|||||||\n"
    + "|.....|\n"
    + "|..~..|\n"
    + "|.....|\n"
    + "|||||||\n" ;
  
  @Test (timeout=2000) public  void map_iterate2(){
    Map m = stringToMap(mapStr4);
    assertEqThings(new Thing[]{}, m.thingsAt(new Coord(2,2))); // left of ~
    m.iterate();
    assertEqThings(new Thing[]{}, m.thingsAt(new Coord(2,2))); // left of ~
    m.iterate();
    // eventually, haze spreads to here.
    Haze h = new Haze(new Coord(2,2),m,m.log);
    assertEqThing(h, m.thingsAt(new Coord(2,2))[0]); // left of ~
  }
  
  @Test (timeout=2000) public  void map_iterate3(){
    Map m = stringToMap(mapStr4);
    assertEqThings(new Thing[]{}, m.thingsAt(new Coord(2,2))); // left of ~
    m.iterate();
    assertEqThings(new Thing[]{}, m.thingsAt(new Coord(2,2))); // left of ~
    m.iterate();
    // eventually, haze spreads to here.
    Haze h = new Haze(new Coord(2,2),m,m.log);
    assertEqThing(h, m.thingsAt(new Coord(2,2))[0]); // left of ~
    m.iterate();
    h.doAction();
    assertEqThing(h, m.thingsAt(new Coord(2,2))[0]); // left of ~
    m.iterate();
    h.doAction();
    // but we never get duplicates.
    assertEqThing(new Haze(new Coord(2,2),m,m.log), m.thingsAt(new Coord(2,2))[0]); // left of ~
  }
  
  /////////////////////////////////////////////////////////
  
  // Panic tests - full maps.
  
  /////////////////////////////////////////////////////////
  
  // Thing tests - it is abstract, so we will use a Zoolander object
  // rather than display a valid child class to students...
  
  // constructor is used by subclasses, will implicitly be tested here.
  
  static String mapStrDefault = "...\n...\n...\n...\n";
  static Map defaultMap = stringToMap(mapStrDefault);
  
  @Test (timeout=2000) public void thing1(){
    Zoolander z = new Zoolander(new Coord(3,4),defaultMap,defaultMap.log);
    // check initial locations of loc/prevLoc.
    assertEquals(new Coord(3,4),z.getLoc());
    assertEquals(new Coord(3,4),z.getPrevLoc());
  }
  
  @Test (timeout=2000) public void thing2(){
    Zoolander z = new Zoolander(new Coord(3,4),defaultMap,defaultMap.log);
    z.setLoc(new Coord(3,5));
    // check after one move.
    assertEquals(new Coord(3,5),z.getLoc());
    assertEquals(new Coord(3,4),z.getPrevLoc());
  }
  
  @Test (timeout=2000) public void thing3(){
    Zoolander z = new Zoolander(new Coord(3,4),defaultMap,defaultMap.log);
    z.setLoc(new Coord(3,5));
    z.setLoc(new Coord(3,6));
    // check after two moves.
    assertEquals(new Coord(3,6),z.getLoc());
    assertEquals(new Coord(3,5),z.getPrevLoc());
  }
  
  // doAction will be tested in subclasses.
  // repr/toString will be tested in subclasses.
  
  /////////////////////////////////////////////////////////
  
  // Threat tests. class is abstract, will test via child classes.
  
  /////////////////////////////////////////////////////////
  
  // Haze tests
  
  @Test (timeout=2000) public void haze1(){
    Haze h = new Haze(new Coord(4,2), defaultMap, defaultMap.log);
    assertEquals(2, h.fullCharge);
  }
  
  @Test (timeout=2000) public void haze2(){
    Haze h = new Haze(new Coord(4,2), defaultMap, defaultMap.log);
    assertEquals(0, h.charge);
  }
  
  @Test (timeout=2000) public void haze3(){
    Haze h = new Haze(new Coord(4,2), defaultMap, defaultMap.log);
    assertEquals(0, h.charge);
    h.doAction();
    assertEquals(1, h.charge);
    h.doAction();
    assertEquals(0,h.charge);
  }
  
  // spawn
  String mapStr5 = "...\n.~.\n...\n";
  // check that spawn works.
  @Test (timeout=2000) public void haze4(){
    Map m = stringToMap(mapStr5);
    Haze h = new Haze(new Coord(1,0), m,m.log);
    h.spawn(new Coord(1,0));
    assertEqThing(new Haze(new Coord(1,0),m,m.log),m.thingsAt(new Coord(1,0))[0]);
  }
  
  // doAction
  // with fullCharge==2, we need two iterations (0, 1) to cause spawning.
  @Test (timeout=2000) public void haze5(){
    Map m = stringToMap(mapStr5);
    Haze h = new Haze(new Coord(0,1), m,m.log);
    m.things[0].doAction();
    m.things[0].doAction();
    assertEqThing(new Haze(new Coord(0,1),m,m.log),m.thingsAt(new Coord(0,1))[0]);
  }  
  
  @Test (timeout=2000) public void haze6(){ assertEquals("~",new Haze(new Coord (2,3), defaultMap, defaultMap.log).repr()); }
  @Test (timeout=2000) public void haze7(){ assertEquals("~@(2,3)",new Haze(new Coord (2,3), defaultMap, defaultMap.log).toString()); }
  @Test (timeout=2000) public void haze8(){ assertFalse(new Haze(new Coord (2,3), defaultMap, defaultMap.log).canLookThrough()); }
  @Test (timeout=2000) public void haze9(){ assertTrue(new Haze(new Coord (2,3), defaultMap, defaultMap.log).canPassThrough()); }
  
  
  /////////////////////////////////////////////////////////
  
  // GreenSlime tests
  
  @Test (timeout=2000) public void slime1(){
    GreenSlime g = new GreenSlime(new Coord(4,2), defaultMap, defaultMap.log);
    assertEquals(4, g.fullCharge);
  }
  
  @Test (timeout=2000) public void slime2(){
    GreenSlime g = new GreenSlime(new Coord(4,2), defaultMap, defaultMap.log);
    assertEquals(0, g.charge);
  }
  
  @Test (timeout=2000) public void slime3(){
    GreenSlime g = new GreenSlime(new Coord(4,2), defaultMap, defaultMap.log);
    assertEquals(0, g.charge);
    g.doAction();
    assertEquals(1, g.charge);
    g.doAction();
    assertEquals(2,g.charge);
    g.doAction();
    assertEquals(3,g.charge);
    g.doAction();
    assertEquals(0,g.charge);
  }
  
  // spawn
  String mapStr6 = "...\n.g.\n...\n";
  // check that spawn works.
  @Test (timeout=2000) public void slime4(){
    Map m = stringToMap(mapStr6);
    GreenSlime g = new GreenSlime(new Coord(1,0), m,m.log);
    g.spawn(new Coord(1,0));
    assertEqThing(new GreenSlime(new Coord(1,0),m,m.log),m.thingsAt(new Coord(1,0))[0]);
  }
  
  // doAction
  // with fullCharge==4, we need four iterations (0, 1, 2, 3) to cause spawning.
  @Test (timeout=2000) public void slime5(){
    Map m = stringToMap(mapStr6);
    GreenSlime g = new GreenSlime(new Coord(0,1), m,m.log);
    m.things[0].doAction();
    m.things[0].doAction();
    m.things[0].doAction();
    m.things[0].doAction();
    assertEqThing(new GreenSlime(new Coord(0,1),m,m.log),m.thingsAt(new Coord(0,1))[0]);
  }  
  
  
  @Test (timeout=2000) public void slime6(){ assertEquals("g",new GreenSlime(new Coord (2,3), defaultMap, defaultMap.log).repr()); }
  @Test (timeout=2000) public void slime7(){ assertEquals("g@(2,3)",new GreenSlime(new Coord (2,3), defaultMap, defaultMap.log).toString()); }
  @Test (timeout=2000) public void sliem8(){ assertTrue(new GreenSlime(new Coord (2,3), defaultMap, defaultMap.log).canLookThrough()); }
  @Test (timeout=2000) public void slime9(){ assertTrue(new GreenSlime(new Coord (2,3), defaultMap, defaultMap.log).canPassThrough()); }
  
  /////////////////////////////////////////////////////////
  
  // Person tests. class is abstract, will check via subclasses.
  
  /////////////////////////////////////////////////////////
  
  // Zoolander tests.
  
  // facing, status.
  @Test (timeout=2000) public void zoo1(){ assertEquals(Direction.N, new Zoolander(new Coord(1,2), defaultMap, defaultMap.log).facing); }
  @Test (timeout=2000) public void zoo2(){ assertEquals(Status.Escaping, new Zoolander(new Coord(1,2), defaultMap, defaultMap.log).status); }
  
  // chooseMove. will be far more exhaustively tested in full maps.
  @Test (timeout=2000) public void zoo3(){ assertEquals(new Coord(2,1), new Zoolander(new Coord(3,1), defaultMap, defaultMap.log).chooseMove()); }
  
  // doAction. will be far more exhaustively tested in full maps.
  @Test (timeout=2000) public void zoo4(){
    Map m = stringToMap ("|e|\n|.|\n|.|\n|z|\n|||\n");
    Zoolander z = new Zoolander(new Coord(2,1), m, m.log);
    m.addThing(z);
    z.doAction();
    assertEqThing(z,m.thingsAt(new Coord(1,1))[0]);
  }
  // isSafe
  @Test (timeout=2000) public void zoo5(){
    Zoolander z = new Zoolander(new Coord(1,2), defaultMap, defaultMap.log);
    assertEquals(Status.Escaping, z.status);
    assertFalse(z.isSafe()); // they're not there yet.
  }
  
  @Test (timeout=2000) public void zoo6(){
    Map m = stringToMap ("|e|\n|.|\n|z|\n|||\n");
    Zoolander z = new Zoolander(new Coord(1,1), m, m.log);
    z.doAction(); // go up to safe spot.
    assertTrue(z.isSafe()); // they're not there yet.
    assertEquals(Status.Safe, z.status);
  }
  
  // die
  @Test (timeout=2000) public void zoo7(){
    Map m = stringToMap ("|e|\n|.|\n|z|\n|||\n");
    Zoolander z = new Zoolander(new Coord(1,1), m, m.log);
    z.die();
    assertFalse(z.isSafe()); // they're not there yet.
    assertEquals(Status.Dead, z.status);
  }
  
  // setLoc (also changes safety).
  @Test (timeout=2000) public void zoo8(){
    Map m = stringToMap ("|e|\n|.|\n|z|\n|||\n");
    Zoolander z = new Zoolander(new Coord(1,1), m, m.log);
    z.setLoc(new Coord(0,1)); // go to an exit and become free.
    assertTrue(z.isSafe()); // they're not there yet.
    assertEquals(Status.Safe, z.status);
  }
  
  // canLookThrough
  @Test (timeout=2000) public void zoo9(){
    Map m = stringToMap ("|e|\n|.|\n|z|\n|||\n");
    Zoolander z = new Zoolander(new Coord(1,1), m, m.log);
    assertTrue(z.canLookThrough());
  }  
  // canPassThrough
  @Test (timeout=2000) public void zoo10(){
    Map m = stringToMap ("|e|\n|.|\n|z|\n|||\n");
    Zoolander z = new Zoolander(new Coord(1,1), m, m.log);
    assertTrue(z.canPassThrough());
  }  
  
  /////////////////////////////////////////////////////////
  
  // Follower tests.
  // facing, status.
  @Test (timeout=2000) public void follow1(){ assertEquals(Direction.N, new Follower(new Coord(1,2), defaultMap, defaultMap.log).facing); }
  @Test (timeout=2000) public void follow2(){ assertEquals(Status.Escaping, new Follower(new Coord(1,2), defaultMap, defaultMap.log).status); }
  
  // chooseMove. will be far more exhaustively tested in full maps.
  @Test (timeout=2000) public void follow3(){ assertEquals(new Coord(2,1), new Follower(new Coord(3,1), defaultMap, defaultMap.log).chooseMove()); }
  
  // doAction. will be far more exhaustively tested in full maps.
  @Test (timeout=2000) public void follow4(){
    Map m = stringToMap ("|e|\n|.|\n|.|\n|f|\n|||\n");
    Follower f = new Follower(new Coord(2,1), m, m.log);
    m.addThing(f);
    f.doAction();
    assertEqThing(f,m.thingsAt(new Coord(1,1))[0]);
  }
  // isSafe
  @Test (timeout=2000) public void follow5(){
    Follower f = new Follower(new Coord(1,2), defaultMap, defaultMap.log);
    assertEquals(Status.Escaping, f.status);
    assertFalse(f.isSafe()); // they're not there yet.
  }
  
  @Test (timeout=2000) public void follow6(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Follower f = new Follower(new Coord(1,1), m, m.log);
    f.doAction(); // go up to safe spot.
    assertTrue(f.isSafe()); // they're not there yet.
    assertEquals(Status.Safe, f.status);
  }
  
  // die
  @Test (timeout=2000) public void follow7(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Follower f = new Follower(new Coord(1,1), m, m.log);
    f.die();
    assertFalse(f.isSafe()); // they're not there yet.
    assertEquals(Status.Dead, f.status);
  }
  
  // setLoc (also changes safety).
  @Test (timeout=2000) public void follow8(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Follower f = new Follower(new Coord(1,1), m, m.log);
    f.setLoc(new Coord(0,1)); // go to an exit and become free.
    assertTrue(f.isSafe()); // they're not there yet.
    assertEquals(Status.Safe, f.status);
  }
  
  // canLookThrough
  @Test (timeout=2000) public void follow9(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Follower z = new Follower(new Coord(1,1), m, m.log);
    assertTrue(z.canLookThrough());
  }  
  // canPassThrough
  @Test (timeout=2000) public void follow10(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Follower z = new Follower(new Coord(1,1), m, m.log);
    assertTrue(z.canPassThrough());
  }  
  
  /////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  // Tests for the the sample maps
  
  // the missing numbers had Avoiders, which are only in the honors sections' tests.
  @Test(timeout=2000) public void test_complex3() throws Exception{ test_simulation("complex3"); }
  @Test(timeout=2000) public void test_complex4() throws Exception{ test_simulation("complex4"); }
  @Test(timeout=2000) public void test_complex5() throws Exception{ test_simulation("complex5"); }
  @Test(timeout=2000) public void test_complex6() throws Exception{ test_simulation("complex6"); }
  @Test(timeout=2000) public void test_f01() throws Exception{ test_simulation("f01"); }
  @Test(timeout=2000) public void test_f02() throws Exception{ test_simulation("f02"); }
  @Test(timeout=2000) public void test_f03() throws Exception{ test_simulation("f03"); }
  @Test(timeout=2000) public void test_f04() throws Exception{ test_simulation("f04"); }
  @Test(timeout=2000) public void test_f05() throws Exception{ test_simulation("f05"); }
  @Test(timeout=2000) public void test_f06() throws Exception{ test_simulation("f06"); }
  @Test(timeout=2000) public void test_f07() throws Exception{ test_simulation("f07"); }
  @Test(timeout=2000) public void test_f08() throws Exception{ test_simulation("f08"); }
  @Test(timeout=2000) public void test_f09() throws Exception{ test_simulation("f09"); }
  @Test(timeout=2000) public void test_f10() throws Exception{ test_simulation("f10"); }
  @Test(timeout=2000) public void test_f11() throws Exception{ test_simulation("f11"); }
  @Test(timeout=2000) public void test_f12() throws Exception{ test_simulation("f12"); }
  @Test(timeout=2000) public void test_f13() throws Exception{ test_simulation("f13"); }
  @Test(timeout=2000) public void test_f14() throws Exception{ test_simulation("f14"); }
  @Test(timeout=2000) public void test_fg01() throws Exception{ test_simulation("fg01"); }
  @Test(timeout=2000) public void test_fg02() throws Exception{ test_simulation("fg02"); }
  @Test(timeout=2000) public void test_fg03() throws Exception{ test_simulation("fg03"); }
  @Test(timeout=2000) public void test_fg04() throws Exception{ test_simulation("fg04"); }
  @Test(timeout=2000) public void test_fg05() throws Exception{ test_simulation("fg05"); }
  @Test(timeout=2000) public void test_fg06() throws Exception{ test_simulation("fg06"); }
  @Test(timeout=2000) public void test_fh01() throws Exception{ test_simulation("fh01"); }
  @Test(timeout=2000) public void test_fh02() throws Exception{ test_simulation("fh02"); }
  @Test(timeout=2000) public void test_map1() throws Exception{ test_simulation("map1"); }
  @Test(timeout=2000) public void test_map2() throws Exception{ test_simulation("map2"); }
  @Test(timeout=2000) public void test_z01() throws Exception{ test_simulation("z01"); }
  @Test(timeout=2000) public void test_z02() throws Exception{ test_simulation("z02"); }
  @Test(timeout=2000) public void test_z03() throws Exception{ test_simulation("z03"); }
  @Test(timeout=2000) public void test_z04() throws Exception{ test_simulation("z04"); }
  @Test(timeout=2000) public void test_z05() throws Exception{ test_simulation("z05"); }
  @Test(timeout=2000) public void test_z06() throws Exception{ test_simulation("z06"); }
  @Test(timeout=2000) public void test_z07() throws Exception{ test_simulation("z07"); }
  @Test(timeout=2000) public void test_z08() throws Exception{ test_simulation("z08"); }
  @Test(timeout=2000) public void test_z09() throws Exception{ test_simulation("z09"); }
  @Test(timeout=2000) public void test_z10() throws Exception{ test_simulation("z10"); }
  @Test(timeout=2000) public void test_z11() throws Exception{ test_simulation("z11"); }
  @Test(timeout=2000) public void test_z12() throws Exception{ test_simulation("z12"); }
  @Test(timeout=2000) public void test_z13() throws Exception{ test_simulation("z13"); }
  @Test(timeout=2000) public void test_z14() throws Exception{ test_simulation("z14"); }
  @Test(timeout=2000) public void test_zg01() throws Exception{ test_simulation("zg01"); }
  @Test(timeout=2000) public void test_zg02() throws Exception{ test_simulation("zg02"); }
  @Test(timeout=2000) public void test_zg03() throws Exception{ test_simulation("zg03"); }
  @Test(timeout=2000) public void test_zg04() throws Exception{ test_simulation("zg04"); }
  @Test(timeout=2000) public void test_zg05() throws Exception{ test_simulation("zg05"); }
  @Test(timeout=2000) public void test_zg06() throws Exception{ test_simulation("zg06"); }
  @Test(timeout=2000) public void test_zh01() throws Exception{ test_simulation("zh01"); }
  @Test(timeout=2000) public void test_zh02() throws Exception{ test_simulation("zh02"); }
  
  // Where do the test files live
  public static final String testingDirectory = "TEST_FILES";
  public File testDir = null;
  
  // Ensure the test directory exists and is properly initiliazed
  public void ensureTestDirExists(){
    this.testDir = new File(testingDirectory);
    if(testDir.exists()){
      return;
    }
    String msg =
      String.format("Could not locate the testing directory %s (%s)",
                    testingDirectory,testDir.getAbsolutePath());
    throw new RuntimeException(msg);
  }
  
  // Read a whole file
  private static String slurp(String fname) throws Exception{
    return new Scanner(new File(fname), "UTF-8").useDelimiter("\\Z").next();
  }
  
  // Test whether simulation output to a named file is what is expected. 
  public void test_simulation(String mapFileBase) throws Exception{
    ensureTestDirExists();
    File mapFile = new File(testDir,mapFileBase+".txt");
    File actualFile = new File(testDir,mapFileBase+".actual");
    File expectFile = new File(testDir,mapFileBase+".expect");
    
    String mapFileS = mapFile.toString();
    String expectFileS = expectFile.toString();
    String actualFileS = actualFile.toString();
    
    // Run the simulation
    Panic.main(new String[]{mapFileS, actualFileS});
    
    String map = slurp(mapFileS);
    String expect = slurp(expectFileS);
    String actual = slurp(actualFileS);
    actual = actual.replaceAll("\r\n","\n");
    
    String outputComparison = simpleDiff2("EXPECT\n------\n"+expect,
                                          "ACTUAL\n------\n"+actual);
    String msg =
      String.format("Test: %s\nActual output does not match expected output\n"+
                    "Map File:\n%s\nOutput:\n%s\n",
                    mapFileBase,map,outputComparison);
    assertEquals(msg,expect,actual);
    
  }    
  
  
  
  ////////////////////////////////////////////////////////////////////////////////
  // Utilities to append columns of strings
  ////////////////////////////////////////////////////////////////////////////////
  
  // Append strings as columns using space as the divider
  public static String appendColumns2(String all[]){
    return appendColumns2(all, " ");
  }
  
  // Create a side-by-side diff of two strings compared line by line
  public static String simpleDiff2(String x, String y){
    String xs[] = x.split("\n");
    String ys[] = y.split("\n");
    String sep = "      ";
    String dif = " **** ";
    StringBuilder sb = new StringBuilder();
    
    int maxWidth = 0;
    for(String s : xs){
      maxWidth = s.length() > maxWidth ? s.length() : maxWidth;
    }
    for(String s : ys){
      maxWidth = s.length() > maxWidth ? s.length() : maxWidth;
    }
    // Max width format
    String fmt = String.format("%%-%ds",maxWidth);
    
    // Construct the side-by-side diff
    for(int i = 0; i<xs.length || i<ys.length; i++){
      if(i<xs.length && i<ys.length){ // both exist, compare
        sb.append(String.format(fmt,xs[i]));
        String mid = xs[i].equals(ys[i]) ? sep : dif;
        sb.append(mid);
        sb.append(String.format(fmt,ys[i]));
        sb.append("\n");
      }
      else if(i<xs.length){     // only x left
        sb.append(String.format(fmt,xs[i]));
        sb.append(dif);
        sb.append(String.format(fmt,""));
        sb.append("\n");
      }
      else if(i<ys.length){     // only y left
        sb.append(String.format(fmt,""));
        sb.append(dif);
        sb.append(String.format(fmt,ys[i]));
        sb.append("\n");
      }
      else{
        throw new RuntimeException("Something fishy's going on here...");
      }
    }
    return sb.toString();
  }
  
  
  
  // Append string as columns using the provided divider between lines
  public static String appendColumns2(String all[], String divider){
    String allCols[][] = new String[all.length][];
    int widths[] = new int[all.length];
    int rowCounts[] = new int[all.length];
    for(int col=0; col<all.length; col++){
      widths[col]=1;            // Can't have %0s formats
      allCols[col] = all[col].split("\n");
      for(int row=0; row<allCols[col].length; row++){
        int len = allCols[col][row].length();
        widths[col] = len > widths[col] ? len : widths[col];
      }
    }
    String formats[] = new String[all.length];
    int maxRow = 0;
    for(int col=0; col<all.length; col++){
      String div = col < all.length-1 ? divider : "\n";
      formats[col] = String.format("%%-%ds%s",widths[col],div);
      maxRow = maxRow < allCols[col].length ? allCols[col].length : maxRow;
    }
    StringBuilder sb = new StringBuilder();
    for(int row=0; row<maxRow; row++){
      for(int col=0; col<all.length; col++){
        String fill = "";
        if(row < allCols[col].length){
          fill = allCols[col][row];
        }
        sb.append(String.format(formats[col],fill));
      }
    }
    return sb.toString();
  }
  
  
  /*
  /////////////////////////////////////////////////////////
  //  HONORS SECTION tests
  /////////////////////////////////////////////////////////
  
  // Avoider tests.
  
  // facing, status.
  @Test (timeout=2000) public void avoid1(){ assertEquals(Direction.N, new Avoider(new Coord(1,2), defaultMap, defaultMap.log).facing); }
  @Test (timeout=2000) public void avoid2(){ assertEquals(Status.Escaping, new Avoider(new Coord(1,2), defaultMap, defaultMap.log).status); }
  
  // chooseMove. will be far more exhaustively tested in full maps.
  @Test (timeout=2000) public void avoid3(){
    Map m = stringToMap("|e|\n|.|\n|a|\n|||\n");
    assertEquals(new Coord(1,1), new Avoider(new Coord(2,1), m, m.log).chooseMove());
  }
  
  // doAction. will be far more exhaustively tested in full maps.
  @Test (timeout=2000) public void avoid4(){
    Map m = stringToMap ("|e|\n|.|\n|.|\n|f|\n|||\n");
    Avoider a = new Avoider(new Coord(2,1), m, m.log);
    m.addThing(a);
    a.doAction();
    assertEqThing(a,m.thingsAt(new Coord(1,1))[0]);
  }
  // isSafe
  @Test (timeout=2000) public void avoid5(){
    Avoider a = new Avoider(new Coord(1,2), defaultMap, defaultMap.log);
    assertEquals(Status.Escaping, a.status);
    assertFalse(a.isSafe()); // they're not there yet.
  }
  
  @Test (timeout=2000) public void avoid6(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Avoider a = new Avoider(new Coord(1,1), m, m.log);
    a.doAction(); // go up to safe spot.
    assertTrue(a.isSafe()); // they're not there yet.
    assertEquals(Status.Safe, a.status);
  }
  
  // die
  @Test (timeout=2000) public void avoid7(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Avoider a = new Avoider(new Coord(1,1), m, m.log);
    a.die();
    assertFalse(a.isSafe()); // they're not there yet.
    assertEquals(Status.Dead, a.status);
  }
  
  // setLoc (also changes safety).
  @Test (timeout=2000) public void avoid8(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Avoider a = new Avoider(new Coord(1,1), m, m.log);
    a.setLoc(new Coord(0,1)); // go to an exit and become free.
    assertTrue(a.isSafe()); // they're not there yet.
    assertEquals(Status.Safe, a.status);
  }
  
  // canLookThrough
  @Test (timeout=2000) public void avoid9(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Avoider z = new Avoider(new Coord(1,1), m, m.log);
    assertTrue(z.canLookThrough());
  }  
  // canPassThrough
  @Test (timeout=2000) public void avoid10(){
    Map m = stringToMap ("|e|\n|.|\n|f|\n|||\n");
    Avoider z = new Avoider(new Coord(1,1), m, m.log);
    assertTrue(z.canPassThrough());
  }  

  @Test(timeout=2000) public void test_complex1() throws Exception{ test_simulation("complex1"); }
  @Test(timeout=2000) public void test_complex2() throws Exception{ test_simulation("complex2"); }
  @Test(timeout=2000) public void test_complex7() throws Exception{ test_simulation("complex7"); }
  @Test(timeout=2000) public void test_complex8() throws Exception{ test_simulation("complex8"); }
  @Test(timeout=2000) public void test_complex9() throws Exception{ test_simulation("complex9"); }
  
  @Test(timeout=2000) public void test_a01() throws Exception{ test_simulation("a01"); }
  @Test(timeout=2000) public void test_a02() throws Exception{ test_simulation("a02"); }
  @Test(timeout=2000) public void test_a03() throws Exception{ test_simulation("a03"); }
  @Test(timeout=2000) public void test_a04() throws Exception{ test_simulation("a04"); }
  @Test(timeout=2000) public void test_a05() throws Exception{ test_simulation("a05"); }
  @Test(timeout=2000) public void test_a06() throws Exception{ test_simulation("a06"); }
  @Test(timeout=2000) public void test_a07() throws Exception{ test_simulation("a07"); }
  @Test(timeout=2000) public void test_a08() throws Exception{ test_simulation("a08"); }
  @Test(timeout=2000) public void test_a09() throws Exception{ test_simulation("a09"); }
  @Test(timeout=2000) public void test_a10() throws Exception{ test_simulation("a10"); }
  @Test(timeout=2000) public void test_a11() throws Exception{ test_simulation("a11"); }
  @Test(timeout=2000) public void test_a12() throws Exception{ test_simulation("a12"); }
  @Test(timeout=2000) public void test_a13() throws Exception{ test_simulation("a13"); }
  @Test(timeout=2000) public void test_a14() throws Exception{ test_simulation("a14"); }
  @Test(timeout=2000) public void test_a15() throws Exception{ test_simulation("a15"); }
  @Test(timeout=2000) public void test_a16() throws Exception{ test_simulation("a16"); }
  @Test(timeout=2000) public void test_a17() throws Exception{ test_simulation("a17"); }
  
   */
  /////////////////////////////////////////////////////////
  
  // once after the entire class's tests have been run, remove that temporary output file.
  @AfterClass public static void cleanup(){
    new File(outFileName).delete();
  }
}
