//over arching mapclass which holds all info about spots and things on map
import java.io.*;
import java.util.*;
class Map{
  Spot[][] floorplan;
  Thing[] things;
  java.io.PrintStream log;
  public int xLen;
  public int yLen;
  Map(String filename, PrintStream log)throws IOException{
    this.log = log;
    int locThing = 0;
    int countThing = 0;
    int x = 0;
    int y = 0;
    Scanner sc = new Scanner(new File(filename));
    while(sc.hasNext()){
      String nxtLine = sc.nextLine();
      y += 1;
      x = nxtLine.length();
      for (int xCoor=0; xCoor < x; xCoor += 1){
        char nxt = nxtLine.charAt(xCoor);
        String temp = Character.toString(nxt);
        if(temp.equals("~")||temp.equals("g")||temp.equals("z")||temp.equals("f")){
          countThing+=1;
        }
      }
    }
    this.xLen=x;
    this.yLen=y;
    sc.close();
    things = new Thing[countThing];
    this.floorplan = new Spot[y][x];
    Scanner cs = new Scanner(new File(filename));
    for (int yCoor=0; yCoor < y; yCoor++){
      String nxtLine = cs.nextLine();
      for (int xCoor=0; xCoor < x; xCoor++){
        char nxt = nxtLine.charAt(xCoor);
        String temp = Character.toString(nxt);
        Coord newCoor = new Coord(yCoor, xCoor);
        if (temp.equals(".")){
          floorplan[yCoor][xCoor] = Spot.Open;
        }
        else if (temp.equals("|")){
          floorplan[yCoor][xCoor] = Spot.Wall;
        }
        else if (temp.equals("e")){
          floorplan[yCoor][xCoor] = Spot.Exit;
        }
        else if (temp.equals("^")){
          floorplan[yCoor][xCoor] = Spot.SignN;
        }
        else if (temp.equals(">")){
          floorplan[yCoor][xCoor] = Spot.SignE;
        }
        else if (temp.equals("v")){
          floorplan[yCoor][xCoor] = Spot.SignS;
        }
        else if (temp.equals("<")){
          floorplan[yCoor][xCoor] = Spot.SignW;
        }
        else if (temp.equals("z")){
          things[locThing] = new Zoolander(newCoor, this, this.log);
          floorplan[yCoor][xCoor] = Spot.Open;
          locThing += 1;
        }
        else if (temp.equals("f")){
          things[locThing] = new Follower(newCoor, this, this.log);
          floorplan[yCoor][xCoor] = Spot.Open;
          locThing += 1;
        }
        else if (temp.equals("g")){
          things[locThing] = new GreenSlime(newCoor, this, this.log);
          floorplan[yCoor][xCoor] = Spot.Open;
          locThing += 1;
        }
        else if (temp.equals("~")){
          things[locThing] = new Haze(newCoor, this, this.log);
          floorplan[yCoor][xCoor] = Spot.Open;
          locThing += 1;
        }
      }
    }
  }
 public boolean onMap(Coord c){
   //Answers if the given Coord is on this Map.  
   int rows=this.yLen-1;
   int cols=this.xLen-1;
   if(c.r>rows||c.c>cols||c.c<0||c.r<0){
     return false;
   }
   else return true;
 }
 public Spot spotAt(Coord c){
   if(this.onMap(c)==false){
     return null;
   }
   return this.floorplan[c.r][c.c];//Returns the Spot at the given Coord, if present. If the Coord isn't on the map, this method will return null.
   
 }
 public int peopleRemaining(){
   //Returns how many people are still trying to escape. Status.Safe and Status.Dead people don't count, but Status.
   //Escaping people do get counted. Threats don't count either, of course.
   int remaining=0;
   for(int i=0; i<this.things.length;i++){
     if(this.things[i] instanceof Person){
       Person x=(Person) this.things[i];
       if(x.isEscaping()){
         remaining+=1;
       }
     }
   }
   return remaining;
 }
 //replaces the array with an array one longer and adds the new item in
 public void addThing(Thing a){
   int x=((this.things.length)+1);
   Thing[] tempThings=new Thing[x];
   for(int i=0; i<this.things.length; i++){
     tempThings[i]=this.things[i];
   }
   tempThings[x-1]=a;
   this.things=tempThings;
   //Occasionally new things should be added (usually these are threats that have spawned more spots of slime or haze). 
   //Accept a new Thing (assumed to be on the map), and cause the things field to be one spot longer, with this new one at the end. 
   //Remember, arrays can't change length. How will you get around this?
 }
 public Thing[] thingsAt(Coord c){
   if(this.onMap(c)==false){
     Thing[] stuffs= new Thing[]{};
     return stuffs;
   }
   int arCount=0;
   for(int i=0; i<this.things.length;i++){
     if(this.things[i].getLoc().equals(c)){
       arCount+=1;
     }
   }
   int counter=0;
   Thing[] stuffs=new Thing[arCount];
   for(int d=0; d<this.things.length;d++){
     if(this.things[d].getLoc().equals(c)){
       stuffs[counter]=this.things[d];
       counter++;
     }
   }
   return stuffs;
   //Return an array of all Thing values found at the given coordinate. Preserve the order of original appearance. 
   //If c isn't on the map, an empty array is returned.
   
 }
 public boolean canLookThroughLocation(Coord c){
   if(this.onMap(c)==false){
     return false;
   }
   //Considering the spot and all things on that spot, can a person look through this location? If c isn't on the map, false is returned.
   Thing[] stuffs=this.thingsAt(c);
   for(int i=0; i<stuffs.length;i++){
     if(stuffs[i] instanceof Haze){
       return false;
     }
   }
   if(this.floorplan[c.r][c.c].canLookThrough()==false){
     return false;
   }
   return true;
 }
 
 public boolean canPassThroughLocation(Coord c){
   if(this.onMap(c)==false){
     return false;
   }
   if(this.floorplan[c.r][c.c].canPassThrough()==false){
     return false;
   }
   return true;
   //Considering the spots and all things on that spot, can a person pass through this location? If c isn't on the map, false is returned.
 
 }
 
 public void iterate(){
   Thing[]xs=this.things;
   for(int i=0;i<xs.length;i++){
     xs[i].doAction();
   }
   this.log.println("map:");
   this.log.println(this.toString());
   //For all Thing's we saw in their original order of discovery (or spawning), allow them to 
   //perform an action by calling their doAction() method. This may alter the map and by changing thing positions or adding new things.
   //after allowing all things to make their moves, the message "map:" must be sent to log, and then this map's toString() 
   //representation must also be sent to the log. if a GreenSlime is spawned into a spot containing people, it immediately kills them; 
   //it doesn't need to wait for the next iteration. Note, this doesn't count as taking an action (do not call doAction on the spawned threat).
   
 }
 @Override public String toString(){
   String finalStr="";
   for(int r=0;r<this.floorplan.length;r++){
     for(int c=0; c<this.floorplan[0].length; c++){
       Coord x=new Coord(r,c);
       Thing[] lst=this.thingsAt(x);
       boolean gs=false;
       boolean hz=false;
       boolean fol=false;
       boolean zoo=false;
       for(int i=0; i<lst.length; i++){
         if(lst[i] instanceof GreenSlime){
           gs=true;
         }
         if(lst[i] instanceof Haze){
           hz=true;
         }
         if(lst[i] instanceof Follower){
           fol=true;
           zoo=false;
         }
         if(lst[i] instanceof Zoolander){
           zoo=true;
           fol=false;
         }
       }
       if(hz==true){
         finalStr=finalStr+"~";
         continue;
       }
       if(gs==true){
         finalStr=finalStr+"g";
         continue;
       }
       if(fol==true){
         finalStr=finalStr+"f";
         continue;
       }
       if(zoo==true){
         finalStr=finalStr+"z";
         continue;
       }
       finalStr=finalStr+this.spotAt(x).repr();
     }
     finalStr=finalStr+"\n";
   }
  return finalStr;
 }
}