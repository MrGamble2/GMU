//inherited by all things, people and threats
import java.io.*;
public abstract class Thing implements Representable,Passable{
  private Coord loc, prevLoc;
  public final String repr;
  protected java.io.PrintStream log;
  protected Map map;

  public Thing(Coord c, String repr, Map map, PrintStream log){
    //Initializes the fields. Both loc and prevLoc are set to the given coordinate c. (This is the only time they'll match).
    this.prevLoc=c;
    this.loc=c;
    this.repr=repr;
    this.map=map;
    this.log=log;
  }
  public abstract void doAction();
  public Coord getLoc(){
    //Returns the loc.
    return this.loc;
  }
  public Coord getPrevLoc(){
    //Returns the prevLoc.
    return this.prevLoc;
  }
  public void setLoc(Coord c){
    //Updates both prevLoc and loc appropriately.
    this.prevLoc=this.loc;
    this.loc=c;
  }
  @Override public String repr(){
    //Returns the field.
    return this.repr;
  }
  @Override public String toString(){
    //Returns the concatenation of repr() and getLoc(). For instance, an Avoider at location (2,3) would return "a@(2,3)".
    return String.format("%s%s",this.repr(),this.getLoc().toString());
  }
}
