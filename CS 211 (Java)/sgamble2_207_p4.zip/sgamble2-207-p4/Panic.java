//main class
import java.io.*;
public class Panic{
  public static void main(String[] args)throws IOException{
    PrintStream x;
    Map a;
    if(args.length>1){
      File f=new File(args[1]);
      x=new PrintStream(f);
      a=new Map(args[0], x);
    }
    else{
       x=new PrintStream(System.out);
       a=new Map(args[0], x);
    }
    x.println("begin simulation");
    Thing[] xs=a.things;
    for(int i=0; i<xs.length;i++){
      x.println(xs[i]);
    }
    x.println(a);
    int count=0;
    while(a.peopleRemaining()>0){
      String fgh="iteration"+" "+count;
      x.println(fgh);
      a.iterate();
      count++;
    }
    x.println("end simulation");
  
  }
}
  
    