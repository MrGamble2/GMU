//repr interface inherited by most stuff
public interface Representable{
  public abstract String repr();
}