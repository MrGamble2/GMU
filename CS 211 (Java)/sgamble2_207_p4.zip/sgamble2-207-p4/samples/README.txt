This directory contains samples of running the Panic! simulation.
- Each map file is named with a .txt extension such as
- The expected output of running the simulation has the same base file
  name as the map but with a .out extension
- The basename of maps/outputs correspond somewhat to their contents

|--------------+-----------------+-----------------------------|
| Map File     | Expected Output | Description                 |
|--------------+-----------------+-----------------------------|
| map1.txt     | map1.out        | Sample map from spec        |
| map2.txt     | map2.out        | Another sample map          |
|--------------+-----------------+-----------------------------|
| z01.txt      | z01.out         | Zoolander maps, increase    |
| z02.txt      | z02.out         | in complexity as index      |
| z03.txt      | z03.out         | grows                       |
| z04.txt      | z04.out         |                             |
| z05.txt      | z05.out         |                             |
| z06.txt      | z06.out         |                             |
| z07.txt      | z07.out         |                             |
| z08.txt      | z08.out         |                             |
| z09.txt      | z09.out         |                             |
| z10.txt      | z10.out         |                             |
| z11.txt      | z11.out         |                             |
| z12.txt      | z12.out         |                             |
| z13.txt      | z13.out         |                             |
| z14.txt      | z14.out         |                             |
|--------------+-----------------+-----------------------------|
| f01.txt      | f01.out         | Follower maps               |
| f02.txt      | f02.out         | Identical to Zoolander maps |
| f03.txt      | f03.out         | but have Followers instead  |
| f04.txt      | f04.out         |                             |
| f05.txt      | f05.out         |                             |
| f06.txt      | f06.out         |                             |
| f07.txt      | f07.out         |                             |
| f08.txt      | f08.out         |                             |
| f09.txt      | f09.out         |                             |
| f10.txt      | f10.out         |                             |
| f11.txt      | f11.out         |                             |
| f12.txt      | f12.out         |                             |
| f13.txt      | f13.out         |                             |
| f14.txt      | f14.out         |                             |
|--------------+-----------------+-----------------------------|
| zg01.txt     | zg01.out        | Zoolander plus GreenSlimes  |
| zg02.txt     | zg02.out        |                             |
| zg03.txt     | zg03.out        |                             |
| zg04.txt     | zg04.out        |                             |
| zg05.txt     | zg05.out        |                             |
|--------------+-----------------+-----------------------------|
| fg01.txt     | fg01.out        | Followers plus GreenSlimes  |
| fg02.txt     | fg02.out        |                             |
| fg03.txt     | fg03.out        |                             |
| fg04.txt     | fg04.out        |                             |
| fg05.txt     | fg05.out        |                             |
| fg06.txt     | fg06.out        |                             |
|--------------+-----------------+-----------------------------|
| zh01.txt     | zh01.out        | Zoolander plus haze         |
| zh02.txt     | zh02.out        |                             |
| fh01.txt     | fh01.out        | Follower plus haze          |
| fh02.txt     | fh02.out        |                             |
|--------------+-----------------+-----------------------------|
| complex1.txt | complex1.out    | Complex layouts             |
| complex2.txt | complex2.out    |                             |
| complex3.txt | complex3.out    |                             |
| complex4.txt | complex4.out    |                             |
| complex5.txt | complex5.out    |                             |
| complex6.txt | complex6.out    |                             |
| complex7.txt | complex7.out    |                             |
| complex8.txt | complex8.out    |                             |
| complex9.txt | complex9.out    |                             |
|--------------+-----------------+-----------------------------|
