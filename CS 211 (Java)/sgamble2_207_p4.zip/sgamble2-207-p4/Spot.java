//what could be in a place, a sign, exit, wall, or open
enum Spot implements Representable, Passable{
  Open("."), Wall("|"), Exit("e"), SignN("^"), SignE(">"), SignS("v"), SignW("<");
  public final String repr;
  private boolean lookThrough, passThrough;
  private Direction dir;
  private String item;
  private Spot(String item){
    this.item=item;
    this.repr=item;
  }
  public boolean isSign(){
    //Determines if the spot is one of our four SignX spot values.
    if(this.item==">"||this.item=="v"||this.item=="^"||this.item=="<"){
      return true;
    }
    else return false;
  }
  public boolean isExit(){
    if(this.item=="e"){
      return true;
    }
    else return false;
  }
  @Override public String toString(){
    return this.item;
  // Uses the repr value as its result. probably the wrong thing if fails
  }
  @Override public String repr(){
    return this.repr;
  }
  @Override public boolean canLookThrough(){
    //Answers if a person is able to look beyond this spot. It is true for all spots except Wall.
    if(this.item=="|"){
      return false;
    }
    else{
      return true;
    }
  }
  @Override public boolean canPassThrough(){
    //Answers if a person is able to walk into/through this spot. It is true for all spots except Wall.
    if(this.item=="|"){
      return false;
    }
    else{
      return true;
    }
  }
}
