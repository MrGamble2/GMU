//the status thats inherited by people
public enum Status{
  Escaping, Safe, Dead;
}