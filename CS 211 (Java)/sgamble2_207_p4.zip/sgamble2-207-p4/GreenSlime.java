import java.io.*;
//slime that is fire..... it spread and kills people when counter is full
public class GreenSlime extends Threat{
  public GreenSlime(Coord loc, Map map, PrintStream log){
    //Via the parent constructor, sets all fields. fullcharge must always be 4, and the starting value for charge is 0.
    super(loc, "g", 4, map, log);
      this.charge=0;
    
  }
  @Override public void spawn(Coord c){
    GreenSlime x= new GreenSlime(c, this.map,this.log);
    this.map.addThing(x);
    this.log.println(String.format("%s spawned", x.toString()));
    Thing[] stuffs=this.map.thingsAt(c);
    for(int i=0; i<stuffs.length;i++){
      if(stuffs[i] instanceof Person){
        Person g=(Person)stuffs[i];
        if(g.isDead()==false && g.isSafe()==false){
        g.die();
        this.log.println(String.format("%s killed %s", x.toString(),g.toString()));
        }
      }
    }
  }
  @Override public void doAction(){
    super.doAction();
    Thing[] stuffs=this.map.thingsAt(this.getLoc());
    for(int i=0; i<stuffs.length;i++){
      if(stuffs[i] instanceof Person){
        Person g=(Person)stuffs[i];
        if(g.isDead()==false && g.isSafe()==false){
        g.die();
        this.log.println(String.format("%s killed %s", this.toString(),g.toString()));
        }
      }
    }
    
      
  }
  @Override public boolean canLookThrough(){
    //People can actually look through a spot containing a GreenSlime; it doesn't obscure the whole view like a Wall does.
    return true;
  }
  @Override public boolean canPassThrough(){
   return true;
  }
}