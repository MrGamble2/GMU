import java.io.*;
//misread what exactly follower does and pulled an alnighter, so just kept adding stuff in where i found errors....
//and now its this monstrosity. 
public class Follower extends Person{
  public Follower (Coord c, Map map, PrintStream log){
    super(c, "f", map,log);
  }
  //checks for exits in range
  @Override public Coord chooseMove(){
    Direction j=this.facing;
    if(checkExit(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
        }
      }
    }
    j=j.cycle();
    if(checkExit(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
        }
      }
    }
    j=j.cycle();
    if(checkExit(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
        }
      }
    }
    j=j.cycle();
    if(checkExit(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
        }
      }
    }
    //done checking exits, now for signs
    int seenPointer=-1;
    //back at start direction, seenPointer means how many turns to take to see a sign that pointed at him, if theres
    //nothing else to see
    j=j.cycle();
    checkSpot(this.getLoc());
    j=this.facing;
    //facing makes you face the way of an arrow if your standing on it
    if(check(j)){
      //checks in a direction and if its a sign not pointed at you go to it
      //if its pointed at you, remeber it with seenPointer
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          if(checkSigns(j)){
            seenPointer=0;
          }
          else{
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
          }
        }
      }
    }
    j=j.cycle();
    if(check(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          if(checkSigns(j)){
            if(seenPointer!=0){
              seenPointer=1;
            }
          }
          else{
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
          }
        }
      }
    }
    j=j.cycle();
    if(check(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          if(checkSigns(j)){
            seenPointer=2;
          }
          else{
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
          }
        }
      }
    }
    j=j.cycle();
    if(check(j)){
      if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
        if(this.map.canPassThroughLocation(this.getLoc().step(j))){
          if(checkSigns(j)){
            seenPointer=3;
          }
          else{
          this.facing=j;
          this.log.println(this.toString()+" moving "+j.toString());
          return this.getLoc().step(j);
          }
        }
      }
    }
    j=j.cycle();
    //goes back to see if anyPointers where seen, if so go that way
    if(seenPointer>-1){
      for(int gj=0;gj<seenPointer;gj++){
        j=j.cycle();
      }
      this.facing=j.getOpposite();
      this.log.println(this.toString()+" moving "+j.getOpposite().toString());
      return this.getLoc().step(j.getOpposite());
    }
   //if not go direction ur facing, or rotate till you can.
    if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
      if(this.map.canPassThroughLocation(this.getLoc().step(j))){
        this.facing=j;
        this.log.println(this.toString()+" moving "+j.toString());
        return this.getLoc().step(j);
      }
    }
    j=j.cycle();
    if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
      if(this.map.canPassThroughLocation(this.getLoc().step(j))){
        this.facing=j;
        this.log.println(this.toString()+" moving "+j.toString());
        return this.getLoc().step(j);
      }
    }
    j=j.cycle();
    if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
      if(this.map.canPassThroughLocation(this.getLoc().step(j))){
        this.facing=j;
        this.log.println(this.toString()+" moving "+j.toString());
        return this.getLoc().step(j);
      }
    }
    j=j.cycle();
    if(this.getLoc().step(j).equals(this.getPrevLoc())==false){
      if(this.map.canPassThroughLocation(this.getLoc().step(j))){
        this.facing=j;
        this.log.println(this.toString()+" moving "+j.toString());
        return this.getLoc().step(j);
      }
    }
    this.log.println(this.toString()+" staying here");
    return(this.getLoc());
    //if stand on sign turn direction, check in circle
  }
  public Boolean check(Direction x){
    Coord c=this.getLoc();
    int f=0;
    //
    while(f==0){
      c=c.step(x);
      if(this.map.onMap(c)==false){
        return false;
      }
      if(this.map.canLookThroughLocation(c)==false){
        return false;
      }
      if(this.map.spotAt(c).isSign()){
        return true;
      }
      if(this.map.spotAt(c).isExit()){
        return true;
      }
    }
    return true;
  }
  public Boolean checkExit(Direction x){
    Coord c=this.getLoc();
    int f=0;
    //
    while(f==0){
      c=c.step(x);
      if(this.map.onMap(c)==false){
        return false;
      }
      if(this.map.canLookThroughLocation(c)==false){
        return false;
      }
      if(this.map.spotAt(c).isExit()){
        return true;
      }
    }
    return true;
  }
    
  public void checkSpot(Coord x){
    Spot f=this.map.spotAt(x);
    if(f.equals(Spot.SignN)){
      this.facing=Direction.N;
    }
    if(f.equals(Spot.SignS)){
      this.facing=Direction.S;
    }
    if(f.equals(Spot.SignE)){
      this.facing=Direction.E;
    }
    if(f.equals(Spot.SignW)){
      this.facing=Direction.W;
    }
  }
  public boolean checkSigns(Direction d){
    Coord c=this.getLoc();
    int f=0;
    while(f==0){
      c=c.step(d);
      if(this.map.onMap(c)==false){
        return false;
      }
      if(this.map.spotAt(c).isSign()){
        Direction sig=Direction.N;
        if(this.map.spotAt(c)==Spot.SignN){
          sig=Direction.N;
        }
        if(this.map.spotAt(c)==Spot.SignW){
          sig=Direction.W;
        }
        if(this.map.spotAt(c)==Spot.SignE){
          sig=Direction.E;
        }
        if(this.map.spotAt(c)==Spot.SignS){
          sig=Direction.S;
        }
        if(sig.isOpposite(d)){
          return true;
        }
      }
      if(this.map.canLookThroughLocation(c)==false){
        return false;
      }
    }
    return true;
  }
  }
  
                                       