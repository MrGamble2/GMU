//haze that spreads and cant be seen through but can be passed through. 
import java.io.*;
public class Haze extends Threat{
  public Haze(Coord c, Map map, PrintStream log){
    //Via the parent constructor, initializes all fields. fullCharge must be set to 2, and again charge starts at 0.
    super(c, "~", 2, map, log);
      this.charge=0;
  }
  @Override public void spawn(Coord c){
    Haze x=new Haze(c, this.map, this.log);
    this.log.println(String.format("%s spawned", x.toString()));
    this.map.addThing(x);
    //Creates a new Haze object and adds it to the map at location c. No log messages need to be generated.
  }
    //Note: hazes can't directly kill anyone, so there is nothing extra to add to doAction; rely upon the inherited version.
  @Override public boolean canLookThrough(){
    return false;//People can't look through haze.
  }
  @Override public boolean canPassThrough(){
    return true;
  }
}