//sets up fields for if passable or see through
public interface Passable{
  public abstract boolean canLookThrough();
  public abstract boolean canPassThrough();
}