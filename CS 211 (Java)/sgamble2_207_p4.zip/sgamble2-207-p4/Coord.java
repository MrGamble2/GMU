public class Coord{
  public final int r, c;
  public Coord (int r, int c){
    this.r=r;
    this.c=c;
  //Constructor, assigns both fields.
  }
  public Coord step(Direction d){
    //What is the Coordinate one step in the given direction? Creates and returns this new Coord value. 
    //Note, it may or may not be on a particular Map. No error checking is performed here (we don't have access to the Map to check its dimensions).
    if(d==Direction.N){
      return new Coord(this.r-1,this.c);
    }
    if(d==Direction.S){
      return new Coord(this.r+1,this.c);
    }
    if(d==Direction.E){
      return new Coord(this.r,this.c+1);
    }
    if(d==Direction.W){
      return new Coord(this.r,this.c-1);
    }
    if(d==Direction.none){
      return new Coord(this.r,this.c);
    }
    return new Coord(this.r,this.c);
  }
  public Coord copy(){
    //Creates and returns a new Coord value with the same row/column representation as the current object.
    return new Coord(this.r,this.c);
  }
  public boolean equals(Object o){
    //Given another object, is it also a Coord with the same row and column values?
    if(o instanceof Coord){
      Coord dog=(Coord) o;
      if(this.toString().equals(dog.toString())){
        return true;
      }
    }
    return false;
  }
  public boolean adjacent(Coord other){
    //Is the given other Coord exactly one spot away (N, E, S, W)? Only four locations can return true;
    //all others (including the same location) would return false.
    if(new Coord((this.r+1),this.c).equals(other)){
      return true;
    }
    if(new Coord(this.r-1,this.c).equals(other)){
      return true;
    }
    if(new Coord(this.r,this.c+1).equals(other)){
      return true;
    }
    if(new Coord(this.r,this.c-1).equals(other)){
      return true;
    }
    return false;
  }
  public String toString(){
    return String.format("@(%d,%d)",this.r, this.c);
    //Representation of an @ symbol and the row/column values in parentheses, like this example in row 2, column 3: "@(2,3)"
  }
}