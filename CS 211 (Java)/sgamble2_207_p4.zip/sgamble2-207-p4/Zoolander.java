import java.io.*;
//zoolander that keeps mowing one space till it cant or runs into trouble
public class Zoolander extends Person{
  public Zoolander(Coord c, Map map, PrintStream log){
    super(c,"z", map, log);
    //Via the parent constructor, insantiates all fields. The repr for Zoolander is "z".
  }
  @Override public Coord chooseMove(){
    //checks foward
    Direction temp=this.facing;
    int fgh=0;
    while(fgh<4){
      if(this.checkDir(temp)==false){
        temp=temp.cycle();
      }
      if(this.checkDir(temp)==true){
        if(this.getLoc().step(temp).equals(this.getPrevLoc())==false){
          this.facing=temp;
          this.log.println(this.toString()+" moving "+temp.toString());
          return this.getLoc().step(temp);
        }
        temp=temp.cycle();
      }
      fgh+=1;
    }
    this.log.println(this.toString()+" staying here");
    return this.getLoc();
    //if slime or wall,turn right
    //
  }
  public Boolean checkDir(Direction x){
    Coord c=this.getLoc().step(x);
    Thing[] fg=this.map.thingsAt(c);
    if(this.map.canPassThroughLocation(c)==false){
      return false;
    }
    for(int i=0;i<fg.length; i++){
      if(fg[i] instanceof Haze){
        return true;
      }
    }
    for(int i=0;i<fg.length; i++){
      if(fg[i] instanceof GreenSlime){
        return false;
      }
    }
    return true;
  }
  
}