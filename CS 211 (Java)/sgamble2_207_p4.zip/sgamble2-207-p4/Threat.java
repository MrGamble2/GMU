//haze and slimes parents, calls their spawn and do action
import java.io.*;
public abstract class Threat extends Thing{
 protected int charge;
 protected final int fullCharge; 
 
 public Threat(Coord c, String repr, int fullCharge, Map map, PrintStream log){
   //Initializes the fields. charge starts at 0.
   super(c, repr, map, log);
   this.fullCharge=fullCharge;
     
 }
 public abstract void spawn(Coord c);
 @Override public void doAction(){
   //First action is to increment charge. If it reaches fullCharge, it's time to spawn! When at full charge, take the following actions.
   this.charge=this.charge+1;
   if(this.charge==this.fullCharge){
     this.log.println(String.format("%s spreading", this.toString()));
     this.charge=0;
     for(int i=0; i<4; i++){
       Direction x=Direction.N;
       if(i==0){
         x=Direction.N;
       }
       if(i==1){
         x=Direction.E;
       }
       if(i==2){
         x=Direction.S;
       }
       if(i==3){
         x=Direction.W;
       }
       if(this.map.onMap(this.getLoc().step(x))){
         if(this.map.spotAt(this.getLoc().step(x)).canPassThrough()==true){
           Thing[] stuff=this.map.thingsAt(this.getLoc().step(x));
           boolean canSpawn=true;
           if(stuff.length>0){
             for(int g=0;g<stuff.length;g++){
               if(this instanceof GreenSlime){
                 if(stuff[g] instanceof GreenSlime){
                   canSpawn=false;
                 }
               }
               if(this instanceof Haze){
                 if(stuff[g] instanceof Haze){
                   canSpawn=false;
                 }
               }
             }
           }
           if(canSpawn==true){
             this.spawn(this.getLoc().step(x));
           }
         }
       }
     }
     }
   }
   
}
