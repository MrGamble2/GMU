//blah blah makes directions, used for way people facing, spawning, and checking areas.
public enum Direction{
  N("N"), E("E"), S("S"), W("W"), none("none");
  private String direct;
  private Direction(String direct){
    this.direct=direct;
  }
  public Direction cycle(){
  //Given a Direction, cycle around to the next direction in clockwise fashion: N ? E, E ? S, S ? W, W ? N, none ? none.
    if(this.direct=="N"){
      return Direction.E;
    }
    if(this.direct=="E"){
      return Direction.S;
    }
    if(this.direct=="S"){
      return Direction.W;
    }
    if(this.direct=="W"){
      return Direction.N;
    }
    if(this.direct=="none"){
      return Direction.none;
    }
    else return Direction.none;
  }
  public Direction getOpposite(){
  //Given a Direction, report back the opposite direction. N / S report each other, E / W report each other, and none reports itself.
    if(this.direct=="N"){
      return Direction.S;
    }
    if(this.direct=="E"){
      return Direction.W;
    }
    if(this.direct=="S"){
      return Direction.N;
    }
    if(this.direct=="W"){
      return Direction.E;
    }
    if(this.direct=="none"){
      return Direction.none;
    }
    else return Direction.none;
  }
  public boolean isOpposite(Direction other){
    if(this.direct=="N"){
      if(other==Direction.S){
        return true;
      }
      else{
        return false;
      }
    }
    if(this.direct=="E"){
      if(other==Direction.W){
        return true;
      }
      else{
        return false;
      }
    }
    if(this.direct=="S"){
      if(other==Direction.N){
        return true;
      }
      else{
        return false;
      }
    }
    if(this.direct=="W"){
      if(other==Direction.E){
        return true;
      }
      else{
        return false;
      }
    }
    if(this.direct=="none"){
      if(other==Direction.none){
        return true;
      }
      else{
        return false;
      }
    }
    return true;
   //reports if the given direction is opposite of the other. none is never opposite anything else, but N / S are opposites and E / W are opposites.
  }
}