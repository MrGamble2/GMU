public class CSWisdom {

 public static void main (String[] args) { 
  System.out.println("If in physics there's something you don't understand, you can always");
  System.out.println("hide behind the uncharted depths of nature. You can always blame");
  System.out.println("God. You didn't make it so complex yourself. But if your program");
  System.out.println("doesn't work, there is no one to hide behind. You cannot hide behind");
  System.out.println("an obstinate nature. If it doesn't work, you've messed up.");
  System.out.println("");
  System.out.println("- Edsger Dijkstra");
  //more code to go here!
 }
}
