public class HelloLab {

 public static void main (String[] args) { 
  System.out.println("Hello, Lab!");
  //more code to go here!
 }
}
