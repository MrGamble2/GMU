public class Contact{
  private Wire in, out;
  private boolean inbound; //(true when this is a circuit's input, false otherwise.)
  public Contact(Wire in, Wire out, boolean inbound){
    //the obvious constructor.
    this.in=in;
    this.out=out;
    this.inbound=inbound;
  }
  @Override public String toString(){
    if(this.in.equals(this.out)){
      return in.getName()+":"+in.getSignal();
    }
    if(inbound==false){
       return "("+in.getName()+")"+out.getName()+":"+in.getSignal();
    }
    if(inbound){
       return in.getName()+"("+out.getName()+"):"+in.getSignal();
    }
    return "iks";
    //When the two wires (in, out) have different names, you must show the two wire names, and parenthesize the 
    //one that is inside the circuit; then, include a colon and the current signal value. For the fulladder sample file above, 
    //we would see "Cin(A):X" for the second halfadder, because the fulladder attached its Cin wire to the halfadder, and on the inside that 
    //halfadder thinks of that spot as being named A. Similarly for the output side, we'd see "(carry)C2:X", because internally, the halfadder 
    //had a carry wire, and we've hooked it up to the fulladder's C2 wire (which itself is also connected to an OR gate). In both instances, we've
    //assumed the X signal value was present, which is how wires begin.
  }
  @Override public boolean equals(Object o){
    //equality check that the in and out wires, as well as inbound, are all equal between the two objects.
    if(o instanceof Contact){
      Contact u=(Contact) o;
      if(u.getIn().equals(this.getIn())){
        if(u.getOut().equals(this.getOut())){
          if(u.getInbound()==this.getInbound()){
            return true;
          }
        }
      }
    }
    return false;
  }
  public void setIn(Wire in){
    this.in=in;
  }
  public void setOut(Wire out){
    this.out=out;
  }
  public void setInbound(boolean inbound){
    this.inbound=inbound;
  }
  public Wire getIn(){
    return this.in;
  }
  public Wire getOut(){
    return this.out;
  }
  public boolean getInbound(){
    return this.inbound;
  }
}