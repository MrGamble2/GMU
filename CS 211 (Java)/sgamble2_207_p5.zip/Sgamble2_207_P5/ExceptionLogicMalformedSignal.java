class ExceptionLogicMalformedSignal extends RuntimeException{
  private char bad;// : the offending character
  private String msg;// the entire message you want to convey (you choose the content).
  public ExceptionLogicMalformedSignal(char bad, String msg){
    //the obvious constructor.
    this.bad=bad;
    this.msg=msg;
  }
    @Override public String toString(){
      //return your msg.
      return this.msg;
    }
    
    public char getBad(){
      return this.bad;
    }
    public String msg(){
      return this.msg;
    }
    public void setBad(char bad){
      this.bad=bad;
    }
    public void setMsg(String msg){
     this.msg=msg;
    }
    public String getMsg(){
      return this.msg;
    }
  
}