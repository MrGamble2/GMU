import java.util.*;
public class GateNand extends Gate{
  public GateNand(List<Wire> ins, Wire output){
    super("And",ins,output);
  }
  @Override public boolean equals(Object other){
    return super.equals(other);
  }
  @Override public List<Signal> inspect(List<Signal> inputs){
    this.feed(inputs);
    this.propagate();
    List<Signal>sigs=new ArrayList<Signal>();
    sigs=this.read();
    return sigs;
  }
  @Override public String inspect(String inputs){
     List<Signal>sigs=new ArrayList<Signal>();
     Signal y;
     for(int i=0; i<inputs.length();i++){
       y=Signal.fromString(inputs.charAt(i));
       sigs.add(y);
     }
     this.feed(sigs);
     this.propagate();
     List<Signal>out=new ArrayList<Signal>();
     out=this.read();
     return out.get(0).toString();
  }
  public boolean propagate(){
    //if everything high return low if any low return high
    List<Signal>sigs=new ArrayList<Signal>();
    for(int i=0;i<this.getInputs().size(); i++){
        sigs.add(this.getInputs().get(i).getSignal());
    }
     Signal x=this.getOutput().getSignal();
     int f=0;
     int d=0;
     for(int i=0; i<sigs.size();i++){
       Signal y=sigs.get(i);
       if(y.equals(Signal.LO)){
         f=3;
       }
       if(y.equals(Signal.X)){
         d=4;
       }
     }
     if(d==4){
       this.getOutput().setSignal(Signal.X);
     }
     if(f==3){
       this.getOutput().setSignal(Signal.HI);
     }
     if((f==0)&&(d==0)){
       this.getOutput().setSignal(Signal.LO);
     }
     if(this.getOutput().getSignal().equals(x)){
       return false;
     }
     else{
       return true;
     }
     
    }
  }