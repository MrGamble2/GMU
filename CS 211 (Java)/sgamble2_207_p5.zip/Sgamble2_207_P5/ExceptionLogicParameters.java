public class ExceptionLogicParameters extends RuntimeException{
  private boolean inputsRelated;// when true, indicates this parameters issue was for the inputs to some Logic structure (and not to the outputs).
  private int expected;// found How many were expected, and how many were found?
  private int found;
  public ExceptionLogicParameters(boolean inputsRelated, int expected, int found){
    //constructor that assigns to each field.
    this.inputsRelated=inputsRelated;
    this.expected=expected;
    this.found=found;
  }
  @Override public String toString(){
    return String.format("Expected %d, found %d",this.expected, this.found);
  }
  public boolean getInputsRelated(){
    return this.inputsRelated;
  }
  public int getExpected(){
    return this.expected;
  }
  public int getFound(){
    return this.found;
  }
  public void setInputsRelated(boolean inputsRelated){
    this.inputsRelated=inputsRelated;
  }
  public void setExpected(int expected){
    this.expected=expected;
  }
  public void setFound(int found){
    this.found=found;
  }
}