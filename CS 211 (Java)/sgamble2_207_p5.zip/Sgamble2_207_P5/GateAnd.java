import java.util.*;
public class GateAnd extends Gate{
  public GateAnd(List<Wire> ins, Wire output){
    super("And",ins,output);
  }
  @Override public boolean equals(Object other){
    if(other instanceof GateAnd){
      GateAnd x=(GateAnd) other;
      if(x.getName().equals(this.getName())){
        if(x.getOutput().equals(this.getOutput())){
          if(x.getInputs().equals(this.getInputs())){
            return true;
          }
        }
      }
    }
    return false;
  }
  @Override public List<Signal> inspect(List<Signal> inputs){
    this.feed(inputs);
    this.propagate();
    List<Signal>sigs=new ArrayList<Signal>();
    sigs=this.read();
    return sigs;
  }
  @Override public String inspect(String inputs){
     List<Signal>sigs=new ArrayList<Signal>();
     Signal y;
     for(int i=0; i<inputs.length();i++){
       y=Signal.fromString(inputs.charAt(i));
       sigs.add(y);
     }
     this.feed(sigs);
     this.propagate();
     List<Signal>out=new ArrayList<Signal>();
     out=this.read();
     return out.get(0).toString();
  }
  public boolean propagate(){
    /**/
    List<Signal>sigs=new ArrayList<Signal>();
    for(int i=0;i<this.getInputs().size(); i++){
        sigs.add(this.getInputs().get(i).getSignal());
    }
     Signal x=this.getOutput().getSignal();
     int f=0;
     int d=0;
     for(int i=0; i<sigs.size();i++){
       Signal y=sigs.get(i);
       if(y.equals(Signal.LO)){
         //this.getOutput().setSignal(Signal.LO);
         f=3;
       }
       if(y.equals(Signal.X)){
         //this.getOutput().setSignal(Signal.X);
         d=4;
       }
     }
     if(d==4){
       this.getOutput().setSignal(Signal.X);
     }
     if(f==3){
       this.getOutput().setSignal(Signal.LO);
     }
     if(!(f==3)&&!(d==4)){
       this.getOutput().setSignal(Signal.HI);
     }
     if(this.getOutput().getSignal().equals(x)){
       return false;
     }
     else{
       return true;
    }
     
    }
  }