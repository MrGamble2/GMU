import java.util.*;
public class GateOr extends Gate{
  public GateOr(List<Wire> ins, Wire output){
    super("And",ins,output);
  }
  @Override public boolean equals(Object other){
    if(other instanceof GateOr){
      GateOr x=(GateOr) other;
      if(x.getName().equals(this.getName())){
        if(x.getOutput().equals(this.getOutput())){
          if(x.getInputs().equals(this.getInputs())){
            return true;
          }
        }
      }
    }
    return false;
  }
  @Override public List<Signal> inspect(List<Signal> inputs){
    this.feed(inputs);
    this.propagate();
    List<Signal>sigs=new ArrayList<Signal>();
    sigs=this.read();
    return sigs;
  }
  @Override public String inspect(String inputs){
     List<Signal>sigs=new ArrayList<Signal>();
     Signal y;
     for(int i=0; i<inputs.length();i++){
       y=Signal.fromString(inputs.charAt(i));
       sigs.add(y);
     }
     this.feed(sigs);
     List<Signal>out=new ArrayList<Signal>();
     this.propagate();
     out=this.read();
     return out.get(0).toString();
  }
  public boolean propagate(){
    List<Signal>sigs=new ArrayList<Signal>();
    for(int i=0;i<this.getInputs().size(); i++){
        sigs.add(this.getInputs().get(i).getSignal());
    }
    Signal x=this.getOutput().getSignal();
    int f=0;
    int d=0;
    for(int i=0; i<sigs.size();i++){
      Signal y=sigs.get(i);
      if(y.equals(Signal.HI)){
        //this.getOutput().setSignal(Signal.HI);
        f=3;
      }
      if(y.equals(Signal.X)){
        d=4;
      }
    }
    if(d==4){
      this.getOutput().setSignal(Signal.X);
    }
    if(f==3){
      this.getOutput().setSignal(Signal.HI);
    }
    if(!(f==3)&&!(d==4)){
      this.getOutput().setSignal(Signal.LO);
    }
    if(this.getOutput().getSignal().equals(x)){
      return false;
    }
    else{
      return true;
    }
  }
}