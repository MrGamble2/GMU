import java.io.*;
import java.util.*;
public class Circuit implements Logic{
  private List<Logic> components; //The list of logical blocks that are wired together in this circuit.
    private List<Contact> inputs, outputs; //The connections to the outside world.
    private List<Wire> innerWires; //A convenient place to store all known wires while constructing a circuit.
    private List<String> importables; //the names of circuits that were announced on the IMPORT line, if any.
    private String name; //the circuit's name (part of the file name).
    public Circuit (String circuitName, List<Logic> components, List<Contact> inputs, List<Contact> outputs, List<Wire> innerWires, List<String> importables){
    //The obvious constructor that obediently plugs in all arguments to the fields.
      this.name=circuitName;
      this.components=components;
      this.inputs=inputs;
      this.outputs=outputs;
      this.innerWires=innerWires;
      this.importables=importables;
    }
    //Constructor. This shits so stupid
    public Circuit(String circuitName)throws IOException{
      this.name=circuitName;
      List<Logic> c = new ArrayList<Logic>();
      this.components=c;
      List<Contact> q = new ArrayList<Contact>();
      this.inputs=q;
      this.outputs=q;
      List<Wire> w = new ArrayList<Wire>();
      this.innerWires=w;
      List<String> e = new ArrayList<String>();
      this.importables=e;
      Scanner y=this.getCircuitScanner(circuitName);
      Scanner x=this.getCircuitScanner(circuitName);
      String t;
      t=x.next();
      System.out.println(t);
      if(t.equals("IMPORT")){
        this.parseImportLine("IMPORT "+y.nextLine());
        y.nextLine();
        t=y.nextLine();
        System.out.println(t);  
      }
      else{
        t=y.nextLine();
        System.out.println(t);  
      }
      this.parseContactsLine(t);
      y.nextLine();
      while(y.hasNext()){
        t=y.nextLine();
        System.out.println(t);
        this.parseComponentLine(t);
      }
    }
    
    public Scanner getCircuitScanner(String circuitName) throws IOException{
      String name="samples/"+circuitName+".txt";
      Scanner dog=new Scanner(new File(name));
      return dog;
    }
    public void parseImportLine(String line){
      List <String> xy=new ArrayList<String>();
      Scanner dog=new Scanner(line);
      String cat;
      dog.next();
      while(dog.hasNext()){
        cat=dog.next();
        xy.add(cat);
      }
      this.importables=xy;
    }
    public void parseContactsLine(String line){
      List <Contact> ins=new ArrayList<Contact>();
      List <Contact> outs=new ArrayList<Contact>();
      List <Wire> inner=new ArrayList<Wire>();
      Scanner dog=new Scanner(line);
      Scanner dog2=new Scanner(line);
      String cat,g;
      Wire mouse,mouse2;
      int i=0;
      Contact con,con2;
      while(dog2.hasNext()){
        g=dog2.next();
        if(g.equals("->")){
          while(dog2.hasNext()){
            g=dog2.next();
            mouse=new Wire(g);
            con=new Contact(mouse,mouse,false);
            outs.add(con);
            inner.add(mouse);
          }}
        else{
          mouse=new Wire(g);
          con=new Contact(mouse,mouse,true);
          ins.add(con);
          inner.add(mouse);
        }}
      this.outputs=outs;
      this.inputs=ins;
      this.innerWires=inner;
    }
    public Wire findWire(String name){
      int i=0;
      for(i=0;i<this.innerWires.size();i++){
        if(innerWires.get(i).getName().equals(name)){
          return innerWires.get(i);
        }
      }
      return null;
    }
    public void hookUp(List<Wire> inWires, List<Wire> outWires){
      if(!(inWires.size()==this.inputs.size())){
        throw new ExceptionLogicParameters(true, inputs.size(), inWires.size());
      }
      if(!(outWires.size()==this.outputs.size())){
        throw new ExceptionLogicParameters(true, outputs.size(), outWires.size());
      }
      for(int i=0; i<inWires.size();i++){
        this.inputs.get(i).setIn(inWires.get(i));
      }
      for(int i=0;i<outWires.size();i++){
        this.outputs.get(i).setOut(outWires.get(i));
      }
    }
    //absolute shit show of not understanding what the fuck im doing.....hardest part is to understand the garbage spec.
    public void parseComponentLine(String line) throws IOException{
      //open the file
      Wire mouse;
      List<Wire> xy=new ArrayList<Wire>();
      Wire g, temp;
      Wire out=new Wire("G");
      String gh;
      Scanner dog=new Scanner(line);
      Scanner dog2=new Scanner(line);
      Scanner dog4=new Scanner(line);
      Scanner dog3=new Scanner(line);
      dog2.next();
      String arrow=dog2.next();
      while(dog2.hasNext()&& !(arrow.equals("->"))){
        Wire fgh=new Wire(arrow);
       
        if(this.findWire(arrow)==null){
          Contact df=new Contact(fgh,fgh,true);
          this.inputs.add(df);
          this.innerWires.add(fgh);
        }
        arrow=dog2.next();
      }
      while(dog2.hasNext()){
        arrow=dog2.next();
        Wire fgh=new Wire(arrow);
        if(this.findWire(arrow)==null){
          
          Contact df=new Contact(fgh,fgh,false);
          this.outputs.add(df);
          this.innerWires.add(fgh);
        }
      }    
      
      //parseContactsLine(t);
      //first item will be gate type
      String gate=dog.next(); 
      if(gate.equals("AND")){
        //this.parseContactsLine(dog.nextLine());  
        while(dog.hasNext()){
          gh=dog.next();
          if(gh.equals("->")){
            gh=dog.next();
            out=new Wire(gh);
            temp=this.findWire(out.getName());
            if(!(temp==null)){
              out=temp;
            }
            }
          else{
            g=new Wire(gh);
            temp=this.findWire(g.getName());
            if(!(temp==null)){
              g=temp;
            }
            xy.add(g);
          }
        }
        
        GateAnd fin=new GateAnd(xy,out);
        this.components.add(fin);
      }
      if(gate.equals("NAND")){
        //this.parseContactsLine(dog.nextLine());  
        while(dog.hasNext()){
          gh=dog.next();
          if(gh.equals("->")){
            gh=dog.next();
            out=new Wire(gh);
            temp=this.findWire(out.getName());
            if(!(temp==null)){
              out=temp;
            }
            
          }
          else{
            g=new Wire(gh);
            temp=this.findWire(g.getName());
            if(!(temp==null)){
              g=temp;
            }
            xy.add(g);
          }
        }
        GateNand fin=new GateNand(xy,out);
        this.components.add(fin);
      }
      if(gate.equals("NOR")){
        //this.parseContactsLine(dog.nextLine());  
        while(dog.hasNext()){
          gh=dog.next();
          if(gh.equals("->")){
            gh=dog.next();
            out=new Wire(gh);
            temp=this.findWire(out.getName());
            if(!(temp==null)){
              out=temp;
            }
            
          }
          else{
            g=new Wire(gh);
            temp=this.findWire(g.getName());
            if(!(temp==null)){
              g=temp;
            }
            xy.add(g);
          }
        }
        
        GateNor fin=new GateNor(xy,out);
        this.components.add(fin);
      }
      if(gate.equals("NOT")){
        //this.parseContactsLine(dog.nextLine());  
        while(dog.hasNext()){
          gh=dog.next();
          if(gh.equals("->")){
            gh=dog.next();
            out=new Wire(gh);
            temp=this.findWire(out.getName());
            if(!(temp==null)){
              out=temp;
            }
            
          }
          else{
            g=new Wire(gh);
            temp=this.findWire(g.getName());
            if(!(temp==null)){
              g=temp;
            }
            xy.add(g);
          }
        }
        
        GateNot fin=new GateNot(xy.get(0),out);
        this.components.add(fin);
      }
      if(gate.equals("OR")){
        //this.parseContactsLine(dog.nextLine());  
        while(dog.hasNext()){
          gh=dog.next();
          if(gh.equals("->")){
            gh=dog.next();
            out=new Wire(gh);
            temp=this.findWire(out.getName());
            if(!(temp==null)){
              out=temp;
            }
            
          }
          else{
            g=new Wire(gh);
            temp=this.findWire(g.getName());
            if(!(temp==null)){
              g=temp;
            xy.add(g);
          }
        }
        }
        GateOr fin=new GateOr(xy,out);
        this.components.add(fin);
      
      }
      if(gate.equals("XOR")){
        //this.parseContactsLine(dog.nextLine());  
        while(dog.hasNext()){
          gh=dog.next();
          if(gh.equals("->")){
            gh=dog.next();
            out=new Wire(gh);
            temp=this.findWire(out.getName());
            if(!(temp==null)){
              out=temp;
            }
            
          }
          else{
            g=new Wire(gh);
            temp=this.findWire(g.getName());
            if(!(temp==null)){
              g=temp;
            }
            
            xy.add(g);
          }
        }
        GateXor fin=new GateXor(xy,out);
        this.components.add(fin);
      }
      if(!(gate.equals("AND"))&&!(gate.equals("NOR"))&&!(gate.equals("NOT"))&&!(gate.equals("NAND"))&&!(gate.equals("OR"))&&!(gate.equals("XOR"))){
        try{
          System.out.println(gate);
          Circuit n=new Circuit(gate);
        
          this.components.add(n);
          //this.hookUp(n.getInputs().getIns(),n.getOutputs().getOut());
        }
        catch(FileNotFoundException i){
          throw new FileNotFoundException("NO FILE FOUND");
        }
      }
    }
    public void setComponents(List<Logic> components){
      this.components=components;
    }
    public List<Logic> getComponents(){
      return this.components;
    }
    public void setInputs(List<Contact> inputs){
      this.inputs=inputs;
    }
    public List<Contact> getInputs(){
      return this.inputs;
    }
    public void setOutputs(List<Contact> outputs){
      this.outputs=outputs;
    }
    public List<Contact> getOutputs(){
      return this.outputs;
    }
    public void setInnerWires(List<Wire> innerWires){
      this.innerWires=innerWires;
    }
    public List<Wire> getInnerWires(){
      return this.innerWires;
    }
    public void setImportables(List<String> importables){
      this.importables=importables;
    }
    public List<String> getImportables(){
      return this.importables;
    }
    public void setName(String name){
      this.name=name;
    }
    public String getName(){
      return this.name;
    }
    public void feed(String inSignals){
    }
    //Same purpos as feed(List<Signal>). We accept a string that can be converted into a List<Signal> value with help from Signal.fromString.
    public boolean propagate(){ 
  //Using the current values of our input wires, let all inner components perform their logic and 
  //generate their outputs. Be sure that a single call to propagate will make the entire thing's outputs stabilize.
  //(The order in which you visit gates, or how often you (re)visit them might be significant).
  //returning a boolean : if any wires' signals were changed as a result of this propagation, return true. If no changes 
  //occurred (if the circuit/gate is stable), return false.
      return false;
    }
    public void feed(List<Signal> inSignals){
    }
    public List<Signal> read(){
      List<Signal> dogshit=new ArrayList<Signal>();
      return dogshit;
    }
    //Read the signal values on the output wires, and return them as a List<Signal> value.
    public List<Signal> inspect(List<Signal> inputs){
      List<Signal> dogshit=new ArrayList<Signal>();
      return dogshit;
    }
  //. A combination of feeding, propagating, and reading.
    public String inspect(String inputs){
      return "Fuck";
    }
    public static String indent(String s){
      return "MORE FUCK";
    }
    @Override public boolean equals(Object other){
    //Performs an equality check, ensuring that the inputs, output, and name are the same values.
    if(other instanceof Circuit){
      Circuit o=(Circuit) other;//, List<Logic> components,, List<Contact> outputs, List<Wire> innerWires, 
      if(o.getImportables().equals(this.getImportables())){
        if(o.getName().equals(this.getName())){
          if(o.getInputs().equals(this.getInputs())){
            if(o.getComponents().equals(this.getComponents())){
              if(o.getOutputs().equals(this.getOutputs())){
                if(o.getInnerWires().equals(this.getInnerWires())){
                  return true;
          }
        }
      }
    }
        }
      }
    }
    return false;
  }
}