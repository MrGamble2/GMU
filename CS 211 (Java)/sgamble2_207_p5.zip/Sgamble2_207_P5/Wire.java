
import java.util.*;
public class Wire{
  private Signal signal;
  private String name;
  public Wire(String name){ 
    //Uses X as the starting signal value, and also initializes the name.
    this.signal=Signal.X;
    this.name=name;
  }
  @Override public String toString(){
    //new Wire("sum").toString() ====> "sum:X"
    return String.format("%s:%s", this.name,this.signal.toString());
  }
  public Signal getSignal(){
    return this.signal;
  }
  public String getName (){
    return this.name;
  }
  public void setSignal(Signal signal){
    this.signal=signal;
  }
  public void setName (String name){
    this.name=name;
  }
  @Override public boolean equals(Object other){
    if(other instanceof Wire){
      Wire dog=(Wire) other;
      if(dog.getSignal()==this.signal){
        if(dog.getName().equals(this.name)){
          return true;
        }
      }
    }
    return false;
  }
      
  }
