
import java.util.*;
public enum Signal{
  HI("HI"), LO("LO"), X("X");
  private String item;
  private Signal(String item){
    this.item=item;
  }
  
  public Signal invert(){
    // returns the inversion of this signal. HI and LO return each other, and X returns itself.
    if(this.item.equals("HI")){
      return(Signal.LO);
    }
    if(this.item.equals("LO")){
      return(Signal.HI);
    }
    if(this.item.equals("X")){
      return(Signal.X);
    }
    return(Signal.X);
  }
  public static Signal fromString(char c){
    //Converts a single character into a Signal representation.
    if(c=='1'){
      return(Signal.HI);
    }
    if(c=='0'){
      return(Signal.LO);
    }
    if(c=='X'){
      return(Signal.X);
    }
    if(c=='x'){
      return(Signal.X);
    }
    else{
      throw new ExceptionLogicMalformedSignal(c,"Frak");
    }
  }
  
  public static List<Signal> fromString(String inps){
    //Create and return the List of Signal values found in the input string. Beyond the per-character 
    //functionality of fromString(char), we also skip any spaces and tabs. You can use an ArrayList as the
    //concrete structure when returning something of the interface type List.
    List<Signal> list = new ArrayList<Signal>();
    char c;
    Signal x;
    for(int i=0;i<inps.length();i++){
      c=inps.charAt(i);
      if(c=='1'){
        x=Signal.HI;
      }
      else if(c=='0'){
        x=Signal.LO;
      }
      else if(c=='X'){
        x=Signal.X;
      }
      else if(c=='x'){
        x=Signal.X;
      }
      else if(c==' '){
        continue;
      }
      else if(c=='\t'){
        continue;
      }
      else{
        throw new ExceptionLogicMalformedSignal(c,"Frak");
      }
      list.add(x);
    }
    return list;
  }
  
  @Override public String toString(){
    //HI returns "1". LO returns "0". X returns "X".
    if(this.item.equals("HI")){
      return("1");
    }
    if(this.item.equals("LO")){
      return("0");
    }
    if(this.item.equals("X")){
      return("X");
    }
    return("X");
  }
    public static String toString(List<Signal> sig){
      String dog="";
      for(int i=0;i<sig.size();i++){
        dog=dog+sig.get(i).toString();
      }
      return dog;
    }
}