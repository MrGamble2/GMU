
import java.util.*;
abstract class Gate implements Logic{
  private List<Wire> inputs;
    //inputs. The list of (one or more) input wires.
  private Wire output;
    //The solitary output wire.
  private String name;
  public Gate(String name, List<Wire> ins, Wire out){
    //the obvious constructor.if the ins is an empty list, you must raise an ExceptionLogicParameters value. 
    //(Complain that you expected one and found none).
    this.name=name;
    this.output=out;
    if(ins.size()<1){
      throw new ExceptionLogicParameters(true, 1, ins.size());
    }
    this.inputs=ins;
  }
  @Override public void feed(List<Signal> inSigs){
    if(!(this.inputs.size()==inSigs.size())){
      throw new ExceptionLogicParameters(true, this.inputs.size(),inSigs.size());
    }
    for(int i=0;i<inSigs.size();i++){
      this.inputs.get(i).setSignal(inSigs.get(i));
    }
  //feed these signals to the input wires.if the wrong number of signals has been provided, you must throw an ExceptionLogicParameters exception.
  }
  @Override public void feed(String x){
    if(!(x.length()==this.inputs.size())){
      throw new ExceptionLogicParameters(true, this.inputs.size(),x.length());
    }
    char g;
    Signal y;
    for(int i=0; i<x.length();i++){
      g=x.charAt(i);
      y=Signal.fromString(g);
      this.inputs.get(i).setSignal(y);
    }
  }
  //Same notion, but obtain the Signal values out of this string via Signal.fromString.(propagate is left abstract)
  @Override public List<Signal> read(){
    //read the single signal value from the output wire, and return it as a single value in a List.
    List<Signal> x=new ArrayList<Signal>();
    x.add(this.output.getSignal());
    return x;
  }
  @Override public String toString(){
    //Include the name and then use the List 
    //definition's own toString implementations to include the inputs and output values, such as this And example from halfadder's definition.
    //And( [A:X, B:X] | carry:X )
    String x=String.format("%s( %s | %s )",this.name, this.inputs.toString(), this.output.toString());
    return x;
  }
  @Override public boolean equals(Object other){
    //Performs an equality check, ensuring that the inputs, output, and name are the same values.
    if(other instanceof Gate){
      Gate o=(Gate) other;
      if(o.getOutput().equals(this.getOutput())){
        if(o.getName().equals(this.getName())){
          if(o.getInputs().equals(this.getInputs())){
            return true;
          }
 
        }
      }
    }
    return false;
  }
  public List<Wire> getInputs(){
    return this.inputs;
  }
  public Wire getOutput(){
    return this.output;
  }
  public String getName(){
    return this.name;
  }
  public void setInputs(List<Wire> inputs){
    this.inputs=inputs;
  }
  public void setOutput(Wire output){
    this.output=output;
  }
  public void setName(String name){
    this.name=name;
  }
}