public class GateSim{
  public static void main(String[] args){
  }
}