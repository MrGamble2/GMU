import java.util.*;
public class GateNot extends Gate{
  public static List<Wire> thanksMark(Wire input){
    List<Wire> list = new ArrayList<Wire>();
    list.add(input);
    return list;
  }
  public GateNot(Wire input, Wire output){ 
    super("Out",thanksMark(input),output);
  }
  @Override public boolean equals(Object other){
    if(other instanceof GateNot){
      GateNot x=(GateNot) other;
      if(x.getName().equals(this.getName())){
        if(x.getOutput().equals(this.getOutput())){
          if(x.getInputs().equals(this.getInputs())){
            return true;
          }
        }
      }
    }
    return false;
  }
  @Override public List<Signal> inspect(List<Signal> inputs){
    this.feed(inputs);
    this.propagate();
    return this.read();
  }
  @Override public String inspect(String inputs){
    this.feed(inputs);
    this.propagate();
    Signal y=Signal.fromString(inputs).get(0).invert();
    return y.toString();
  }
  public boolean propagate(){
    Signal y=this.getInputs().get(0).getSignal().invert();
    Signal x=this.getOutput().getSignal();
    this.getOutput().setSignal(y);
    if(x.equals(y)){
      return false;
    }
    return true;
}
}

