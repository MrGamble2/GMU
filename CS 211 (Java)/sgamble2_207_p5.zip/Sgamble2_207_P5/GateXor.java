import java.util.*;
public class GateXor extends Gate{
  public GateXor(List<Wire> ins, Wire output){
    super("And",ins,output);
  }
  @Override public boolean equals(Object other){
    return super.equals(other);
  }
  @Override public List<Signal> inspect(List<Signal> inputs){
    this.feed(inputs);
    this.propagate();
    List<Signal>sigs=new ArrayList<Signal>();
    sigs=this.read();
    return sigs;
  }
  @Override public String inspect(String inputs){
     List<Signal>sigs=new ArrayList<Signal>();
     Signal y;
     for(int i=0; i<inputs.length();i++){
       y=Signal.fromString(inputs.charAt(i));
       sigs.add(y);
     }
     this.feed(sigs);
     List<Signal>out=new ArrayList<Signal>();
     out=this.read();
     return out.get(0).toString();
  }
  public boolean propagate(){
    List<Signal>sigs=new ArrayList<Signal>();
    for(int i=0;i<this.getInputs().size(); i++){
      sigs.add(this.getInputs().get(i).getSignal());
    }
    Signal x=this.getOutput().getSignal();
    int f=0;
    int d=0;
    for(int i=0; i<sigs.size();i++){
      Signal y=sigs.get(i);
      if(y.equals(Signal.HI)){
        f+=1;
      }
      if(y.equals(Signal.X)){
        d+=1;
      }
    }
    if(f==1){
      if(d==0){
       this.getOutput().setSignal(Signal.HI);
      }
    }
    if(f==1){
      if(!(d==0)){
        this.getOutput().setSignal(Signal.X);
      }
    }
    if(!(f==1)){
      this.getOutput().setSignal(Signal.LO);
    }
    if(d>0){
       this.getOutput().setSignal(Signal.X);
      }
    if(this.getOutput().getSignal().equals(x)){
      return false;
    }
    else{
      return true;
    }
     
    }
  }